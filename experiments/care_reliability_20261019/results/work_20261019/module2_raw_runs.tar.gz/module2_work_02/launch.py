from pathlib import Path
import concurrent.futures,datetime,fcntl,hashlib,json,os,signal,subprocess,sys,time
ROOT=Path('/home/gcx/TRIAGE-worktrees/care-reliability-20261019')
OUT=Path('/home/gcx/care_reliability_runs/module2_work_02')
MODEL='/home/gcx/care_20261016/CARE_Codex_Pilot/models/Qwen3-4B-Base'
PREFIX=ROOT/'experiments/care_reliability_20261019'
now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def write(x): (OUT/'launch_manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
def fold_worker(fold):
 for mode in ['legacy384_regression','sealed_mechanism']:
  output=OUT/mode/f'fold{fold}'
  cmd=[sys.executable,'-u',str(PREFIX/'module2/run.py'),'--mode',mode,'--fold',str(fold),'--model',MODEL,'--output',str(output)]
  if mode=='sealed_mechanism':cmd+=['--data',str(PREFIX/'data/module2_sealed.jsonl'),'--data-manifest',str(PREFIX/'data/manifest.json')]
  with (OUT/'logs'/f'{mode}_fold{fold}.log').open('w') as log:
   result=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:return result.returncode
 return 0
def main():
 lock=(OUT/'launcher.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 locks=[]
 for gpu in [1,2,3]:
  f=open(f'/tmp/care-reliability-gpu{gpu}.lock','a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
 snapshot=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True)
 for line in snapshot.splitlines():
  gpu,used,util=map(int,line.split(','))
  if gpu in [1,2,3]:assert used<1000 and util<=10,(gpu,used,util)
 state=dict(status='launching',started_at=now(),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),physical_gpu_by_fold={'0':1,'1':2,'2':3},memory_budget_GiB_per_gpu=24,legacy_cases=384,sealed_cases=144,conditions=12,maximum_model_forwards=8076,initial_gpu_snapshot=snapshot,no_continuous_gpu_monitoring=True,launcher_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 write(state);jobs={}
 for fold,gpu in enumerate([1,2,3]):
  env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
  jobs[fold]=subprocess.Popen([sys.executable,'-u',__file__,'--worker',str(fold)],cwd=ROOT,env=env,start_new_session=True)
 state.update(status='running',worker_pids={str(f):p.pid for f,p in jobs.items()});write(state)
 codes={}
 with concurrent.futures.ThreadPoolExecutor(3) as pool:
  futures={pool.submit(p.wait):f for f,p in jobs.items()}
  for future in concurrent.futures.as_completed(futures):
   fold=futures[future];code=future.result();codes[str(fold)]=code
   if code and state["status"] != "stopping_after_failure":
    state.update(status='stopping_after_failure',failed_fold=fold,exit_codes=codes);write(state)
    for f,p in jobs.items():
     if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
 state.update(status='completed_real_inference' if all(c==0 for c in codes.values()) else 'failed_or_partial',finished_at=now(),exit_codes=codes);write(state)
 return 0 if all(c==0 for c in codes.values()) else 1
if __name__=='__main__':
 raise SystemExit(fold_worker(int(sys.argv[2])) if len(sys.argv)>1 and sys.argv[1]=='--worker' else main())
