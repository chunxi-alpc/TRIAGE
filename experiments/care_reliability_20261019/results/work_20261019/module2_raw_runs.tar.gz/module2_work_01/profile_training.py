from pathlib import Path
import argparse,sys,json,time,datetime,traceback
ROOT=Path('/home/gcx/TRIAGE-worktrees/care-reliability-20261019')
sys.path.insert(0,str(ROOT/'experiments/care_reliability_20261019/module2'))
import run
base=Path('/home/gcx/care_reliability_runs/module2_work_01')
out=base/'training_throughput';out.mkdir(exist_ok=False)
args=argparse.Namespace(mode='legacy384_regression',fold=0,model=Path('/home/gcx/care_20261016/CARE_Codex_Pilot/models/Qwen3-4B-Base'),device='cuda:0',data=None,data_manifest=None,artifacts=ROOT/'experiments/care_qwen3_4b_base_20261016',legacy_signed=ROOT/'experiments/care_module2_signed_20261019',output=out)
protocol=run.read(run.HERE/'protocol.json')
audit,legacy_data,test_data,split=run.preflight(args,protocol)
training=sorted([r for r in legacy_data if r['group_id'] in split['train']],key=lambda r:r['case_id'])[:8]
state=dict(status='training_throughput_started',purpose='Only frozen old training cases; not test performance',case_ids=[r['case_id'] for r in training],test_outcomes_used_for_selection=False,started_at=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),physical_gpu_visibility='1',source_fingerprints=run.source_fingerprints(args))
run.save(out/'profile_manifest.json',state);t=time.monotonic()
try:
 result=run.execute(args,protocol,legacy_data,training,split)
 state.update(status='completed_training_throughput_only',elapsed_seconds=time.monotonic()-t,forwards=result['actual_model_forwards'],peak_allocated_GiB=result['peak_allocated_GiB'],peak_reserved_GiB=result['peak_reserved_GiB'],zero_checks_passed=result['zero_checks_passed'],no_op_records=result['no_eligible_no_op_records'])
except Exception as e:
 state.update(status='failed_training_throughput',error=str(e));(out/'failure.txt').write_text(traceback.format_exc());raise
finally:run.save(out/'profile_manifest.json',state)
print(json.dumps({k:v for k,v in state.items() if k!='source_fingerprints'}))
