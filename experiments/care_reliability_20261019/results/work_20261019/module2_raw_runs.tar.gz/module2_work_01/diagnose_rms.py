from pathlib import Path
import argparse,json,sys,numpy as np,time
ROOT=Path('/home/gcx/TRIAGE-worktrees/care-reliability-20261019');sys.path.insert(0,str(ROOT/'experiments/care_reliability_20261019/module2'))
import run
from backend import load_python,InterventionGeometry
from geometry import scalar_search
import torch
base=Path('/home/gcx/care_reliability_runs/module2_work_01');out=base/'numerical_failure_diagnostic';out.mkdir(exist_ok=False)
args=argparse.Namespace(model=Path('/home/gcx/care_20261016/CARE_Codex_Pilot/models/Qwen3-4B-Base'),device='cuda:0',artifacts=ROOT/'experiments/care_qwen3_4b_base_20261016',output=out)
protocol=run.read(run.HERE/'protocol.json');model,tok,weights=run.setup_model(args,protocol)
legacy=load_python(ROOT/'experiments/care_module2_signed_20261019/diagnostic.py','old_signed')
case='mechanism_17_three_exclusions-p01-canonical-app';row=next(r for r in run.rows(ROOT/'experiments/care_reliability_20261019/data/module2_sealed.jsonl') if r['case_id']==case)
operators=dict(np.load(base/'legacy384_regression/fold0/operators.npz'))
with torch.inference_mode():
 capture,indices,_,_=legacy.collect(model,tok,row,[(9,0)])
 geometry=InterventionGeometry(model,capture,indices,(9,0),protocol)
 direction=geometry.unsigned_direction('random_projector',operators)
 normalized=direction/direction.norm()*geometry.key.float().norm()
 torch.save(dict(key=geometry.key.cpu(),normalized_direction=normalized.cpu(),q_rotated=geometry.q_rotated.cpu(),cosine=geometry.cosine.cpu(),sine=geometry.sine.cpu(),valid=geometry.valid.cpu(),indices=indices),out/'captured_geometry.pt')
 samples=[]
 def evaluate(alpha):
  changed=(geometry.key.float()+alpha*normalized).to(geometry.key.dtype)
  rms=float(geometry.full_score_delta(changed).square().mean().sqrt())
  samples.append(dict(alpha=float(alpha),actual_rms=rms,relative_error=abs(rms-.01)/.01,changed_coordinates=int((changed!=geometry.key).sum())))
  return changed,rms
 try:
  _,result=scalar_search(evaluate,.01,.15)
 except Exception as e:result=dict(status='frozen_search_failed',error=str(e))
 count=len(samples);pivot=min(samples,key=lambda r:r['relative_error'])['alpha']
 for a in np.linspace(0.,2*pivot,4001):evaluate(float(a))
 best=min(samples,key=lambda r:r['relative_error'])
 with (out/'score_curve.jsonl').open('w') as f:
  for i,r in enumerate(samples):f.write(json.dumps(dict(stage='frozen_search' if i<count else 'diagnostic_grid',**r))+chr(10))
 summary=dict(case_id=case,method='random_projector_raw',fold=0,target_rms=.01,maximum_relative_error=.15,frozen_search=result,frozen_search_evaluations=count,diagnostic_evaluations=len(samples)-count,best_diagnostic_point=best,diagnostic_only=True,model_answers_not_used=True,passed_frozen_budget_points=sum(r['relative_error']<=.15 for r in samples))
 run.save(out/'summary.json',summary);print(json.dumps(summary))
