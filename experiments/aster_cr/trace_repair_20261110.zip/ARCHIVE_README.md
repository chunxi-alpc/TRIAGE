# Trace-repair launch snapshot, 2026-11-10
This is a STARTUP SNAPSHOT of an experiment already running in another session. It is not a completed result archive.
Source code/configurations: /home/gcx/aster-trace-repair-followup-20261110/reports/aster_cancel_story_20261109/meeting/trace_repair_followup/.
Runtime output source: /home/gcx/aster_trace_repair_20261110/.
At capture, pipeline_status.json reported collecting_fit. Saved status files are historical observations and can become stale. No final performance is claimed. No experiment process was started, stopped or changed while creating this archive.
Includes collect/data/evaluate/pipeline/report/score_worker/train scripts, scoring configuration, reuse manifest, pipeline status and per-shard progress snapshots. Large active scoring/training caches and incomplete results stay at the runtime source and are not copied. CONTENTS.tsv provides source mapping without hashes.
Historical scripts retain original absolute paths; inspect and adjust paths before future replay. Recorded GPU fields describe the already-running experiment, not instructions to launch on those devices.
