import unittest
from grounding import ground
class GroundTests(unittest.TestCase):
 def check(self,field,value,ids,sents):return ground({'facts':{field:value},'evidence':{field:ids}},sents,[field])[0][field]
 def test_missing_is_not_negative(self):
  for field in ['pcr','margin','her2']:
   self.assertIsNone(self.check(field,'negative',[],['No result is available.']))
   self.assertIsNone(self.check(field,'negative',[1],['The relevant measurements and test results are not documented.']))
 def test_wrong_test_is_not_evidence(self):
  self.assertIsNone(self.check('her2','negative',[1],['HER2 is pending; the PCR result is negative.']))
  self.assertIsNone(self.check('pcr','negative',[1],['HER2-negative breast cancer.']))
 def test_known_categories_are_preserved(self):
  for value in ['positive','negative']:
   for field,s in [('pcr',f'Testing returned {value} for PCR.'),('margin',f'Pathology confirmed {value} surgical margins.'),('her2',f'The tumor is HER2-{value}.')]:
    self.assertEqual(self.check(field,value,[1],[s]),value)
 def test_invalid_ids_and_negation(self):
  self.assertIsNone(self.check('her2','positive',[0,9],['HER2-positive.']))
  self.assertIsNone(self.check('her2','positive',[1],['It is not HER2 positive.']))
 def test_numeric_and_conversion(self):
  self.assertEqual(self.check('lung_mm',8,[1],['The pulmonary nodule measures 0.8 cm.']),8)
  self.assertIsNone(self.check('lung_mm',10,[1],['The pulmonary nodule size is pending.']))
if __name__=='__main__':unittest.main()
