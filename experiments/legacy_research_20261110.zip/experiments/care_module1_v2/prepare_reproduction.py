"""Rebuild all source-derived inputs from licensed local data; verify frozen hashes.

Run only on the designated server. Creates a NEW directory; does not load a model.
"""
import argparse,hashlib,json,pathlib,shutil,subprocess,sys
base=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False)
def run(*args):subprocess.run([sys.executable,*map(str,args)],check=True)
run(base/'pilot_build_data.py','--source',a.source,'--out',a.out/'pilot')
for name,code,extra in [('round1',base,[]),('round2',base/'round2',['--exclude-labels',a.out/'round1/holdout/labels.jsonl'])]:
 dest=a.out/name;dest.mkdir()
 for file in ['logic.py','grounding.py','run_holdout.py','build_holdout.py','evaluate_holdout.py','test_grounding.py','PROTOCOL.zh.txt']:shutil.copy2(code/file,dest/file)
 run(dest/'build_holdout.py','--source',a.source,'--pilot',a.out/'pilot','--out',dest/'holdout',*extra)
 expected=json.loads((code/'holdout/frozen_data_hashes.json').read_text())
 for file,sha in expected.items():
  actual=hashlib.sha256((dest/'holdout'/file).read_bytes()).hexdigest()
  if sha!=actual:raise RuntimeError(f'Data mismatch: {name}/{file}; STOP, do not run inference.')
 shutil.copy2(code/'holdout/frozen_code_hashes.json',dest/'holdout/frozen_code_hashes.json')
 for file,sha in json.loads((dest/'holdout/frozen_code_hashes.json').read_text()).items():assert hashlib.sha256((dest/file).read_bytes()).hexdigest()==sha
print(json.dumps({'status':'all frozen input, label, pair and code hashes reproduced','output':str(a.out)}))
