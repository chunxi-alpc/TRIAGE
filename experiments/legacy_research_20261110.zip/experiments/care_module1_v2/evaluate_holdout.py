import argparse,collections,json,pathlib
import numpy as np
from sklearn.metrics import f1_score,confusion_matrix
def read(p):return [json.loads(s) for s in p.read_text().splitlines()]
def f1(g,p):
 scores=[]
 for c in ['T','F','U']:
  tp=np.sum((g==c)&(p==c));fp=np.sum((g!=c)&(p==c));fn=np.sum((g==c)&(p!=c));scores.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
 return float(np.mean(scores))
def main(root):
 labels=read(root/'labels.jsonl');pred=read(root/'model/predictions.jsonl');pairs=read(root/'pairs.jsonl');pb={x['sample_id']:x for x in pred};assert len(pb)==len(labels)==180
 methods=['direct','legacy_structured','fixed_prompt_only','structured_fixed'];g=np.array([x['label'] for x in labels]);metrics={'status':'executed_frozen_holdout','n':len(g),'methods':{}}
 rule_t=sum(x['seconds'] for x in json.loads((root/'model/rule_extraction_timing.json').read_text()))
 for method in methods:
  p=np.array([pb[x['sample_id']][method]['label'] for x in labels]);score=f1(g,p);assert abs(score-f1_score(g,p,labels=['T','F','U'],average='macro',zero_division=0))<1e-12
  correct=sum(all(pb[z[k]][method]['label']==next(x['label'] for x in labels if x['sample_id']==z[k]) for k in ['original_id','counterfactual_id']) for z in pairs)
  known=[x for x in labels if x['label']!='U'];unknown=[x for x in labels if x['label']=='U']
  def hit(x):
   ev=pb[x['sample_id']][method]['evidence_sentence_ids'];return isinstance(ev,list) and set(ev)==set(x['evidence_sentence_ids'])
  stage={'direct':'direct','legacy_structured':'legacy_facts','fixed_prompt_only':'fixed_facts','structured_fixed':'fixed_facts'}[method]
  seconds=sum(x['seconds'] for x in json.loads((root/f'model/{stage}_timing.json').read_text()))
  m={'macro_f1':score,'accuracy':float(np.mean(g==p)),'correct':int(np.sum(g==p)),'confusion_labels':['T','F','U','INVALID'],'confusion':confusion_matrix(g,p,labels=['T','F','U','INVALID']).tolist(),'pair_accuracy':correct/len(pairs),'pair_correct':correct,'pair_n':len(pairs),'evidence_known_accuracy':sum(hit(x) for x in known)/len(known),'evidence_known_correct':sum(hit(x) for x in known),'evidence_all_accuracy':sum(hit(x) for x in labels)/len(labels),'unknown_accuracy':sum(pb[x['sample_id']][method]['label']=='U' for x in unknown)/len(unknown),'unknown_correct':sum(pb[x['sample_id']][method]['label']=='U' for x in unknown),'known_to_unknown':sum(pb[x['sample_id']][method]['label']=='U' for x in known),'known_to_unknown_rate':sum(pb[x['sample_id']][method]['label']=='U' for x in known)/len(known),'invalid_count':sum(not pb[x['sample_id']][method]['valid'] for x in labels),'timing':{'generation_seconds':seconds,'one_time_rule_extraction_seconds':0 if method=='direct' else rule_t,'total_generation_seconds':seconds+(0 if method=='direct' else rule_t),'note':'CUDA synchronized batched prefill/decode; excludes loading/tokenization/IO; same fixed-fact outputs used by prompt-only and guarded variants'},'by_variant':{},'unknown_by_form':{}}
  for v in ['original','counterfactual','unknown']:
   xs=[x for x in labels if x['variant']==v];m['by_variant'][v]={'correct':sum(pb[x['sample_id']][method]['label']==x['label'] for x in xs),'n':len(xs)}
  for v in ['omitted','pending','unreported']:
   xs=[x for x in unknown if x['unknown_form']==v];m['unknown_by_form'][v]={'correct':sum(pb[x['sample_id']][method]['label']=='U' for x in xs),'n':len(xs)}
  metrics['methods'][method]=m
 # Paired cluster bootstrap keeps all three variants of each source case together.
 groups=collections.defaultdict(list)
 for i,x in enumerate(labels):groups[x['source_row']].append(i)
 clusters=list(groups.values());assert len(clusters)==60 and all(len(v)==3 for v in clusters)
 rng=np.random.default_rng(20261018);p0=np.array([pb[x['sample_id']]['direct']['label'] for x in labels]);p1=np.array([pb[x['sample_id']]['structured_fixed']['label'] for x in labels]);deltas=[]
 for _ in range(2000):
  indices=np.array([i for k in rng.integers(0,60,size=60) for i in clusters[k]]);deltas.append(f1(g[indices],p1[indices])-f1(g[indices],p0[indices]))
 ci=np.quantile(deltas,[.025,.975]).tolist();metrics['paired_cluster_bootstrap']={'unit':'source case; 3 variants kept together','clusters':60,'replications':2000,'seed':20261018,'delta_macro_f1_structured_minus_direct':f1(g,p1)-f1(g,p0),'percentile_95_interval':ci,'limitations':'small synthetic-vignette subset; no claim of population clinical effectiveness'}
 metrics['paired_disagreements']={'structured_correct_direct_wrong':int(np.sum((p1==g)&(p0!=g))),'direct_correct_structured_wrong':int(np.sum((p0==g)&(p1!=g))),'both_wrong':int(np.sum((p0!=g)&(p1!=g)))}
 errors=[]
 for x in labels:
  if any(pb[x['sample_id']][method]['label']!=x['label'] for method in methods):errors.append({k:x[k] for k in ['sample_id','source_row','rule_id','variant','label','gold_facts','unknown_form']}|{method:pb[x['sample_id']][method] for method in methods})
 (root/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');(root/'errors.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in errors))
 print(json.dumps({'methods':{k:{n:v[n] for n in ['macro_f1','correct','pair_correct','unknown_correct','known_to_unknown','evidence_known_accuracy','timing']} for k,v in metrics['methods'].items()},'bootstrap':metrics['paired_cluster_bootstrap'],'disagreements':metrics['paired_disagreements']}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('holdout'));main(p.parse_args().data)
