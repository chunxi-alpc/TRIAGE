CARE 模块一：6条未知误判修复与新病例验证

先读 REPORT.zh.txt。主要结论来自 round2/holdout/metrics.json；根目录 holdout 是第一批暴露接口错误的实验，不能把两批混为一次成功运行。round1_posthoc 仅为修复编号解析后的缓存重放，无新增模型推理。

关键文件
REPORT.zh.txt：中文报告、六条误判原因、主要比较、限制。
comparison.csv：各批次及全部对照的汇总指标。
development/：旧6条错误原始输出与回归检查；只用于开发。
grounding.py、run_holdout.py：第一批冻结版本，保留编号解析错误，供复核。
round2/grounding.py、run_holdout.py：最终修复版本。所有方法共用编号规范化。
round2/PROTOCOL.zh.txt：第二批推理前方案与数据检查说明。
round2/holdout/labels.jsonl：180条标签、来源行号、哈希、事实值、编辑和证据位置。
round2/holdout/pairs.jsonl：60对反事实关系。
round2/holdout/model/*_raw.jsonl：实际Qwen3-8B原始输出，未人工修正。
round2/holdout/model/predictions.jsonl：4种方法的逐条预测。
round2/holdout/model/evidence_checks.jsonl：证据接受或拒绝原因。
round2/holdout/errors.jsonl：任何一组对照出错的条目；包含正确的主方法结果供比较。
round2/holdout/model/*_timing.json、environment.json：真实批次时间与环境。
final_audit.json、SHA256SUMS.json：冻结文件核验、数据分离与交付文件哈希。
provenance/：原实验已采集的模型文件哈希、软件版本和来源访问记录；网络失败也保留。
详细运行日志保留在run.log和round2/run.log，不在聊天中展开。

执行位置
所有数据构建、模型推理、测试、评估和复现检查均在 gcx@10.29.128.115。
服务器原目录：/home/gcx/care_module1_20261017_v2。
环境：/home/gcx/gcx261014/bin/activate；模型：/home/gcx/n/models/Qwen3-8B。
第二批使用GPU 6，无训练或付费接口调用。

复现（登录指定服务器后执行）
source /home/gcx/gcx261014/bin/activate
cd /home/gcx/care_module1_20261017_v2
bash reproduce.sh /home/gcx/care_reproduction_NEW --data-only
上述命令只重建数据，并核对全部冻结哈希；目录必须不存在。已在本次工作中完成一次相同检查，全部通过。
需要重新推理时，省略 --data-only。脚本依次运行两批，预计约4分钟，默认GPU 6，启动前要求空闲显存大于24GB。按用户约定，正式启动前须先汇报资源、规模和时间；稳定后不持续监控。
可通过 CARE_SOURCE、CARE_MODEL、CARE_GPU 指定来源数据目录、模型目录及获准GPU。脚本拒绝0、1、2、3、6、7之外的卡，不覆盖原始结果。
仅重新计算已保存预测的指标：进入 round2 后运行 python evaluate_holdout.py --data holdout；不需要GPU。
单元测试：进入 round2 后运行 python -m unittest test_grounding；6项测试覆盖缺失、错误证据、阴阳性、单位转换及编号格式。
greedy解码仍可能因硬件、库版本及批处理变化产生差异；软件版本、模型文件哈希和参数均已记录。

数据与许可
MedGUIDE固定快照1460ec478280a7295040b92f7eb985327f77dcbe。已读取的来源数据卡许可证为TBD，不能据此认定允许公开再分发。
交付包不含MedGUIDE病例原文、原始路径全文、parquet、模型权重或private目录。包含来源索引、标注值、简短编辑记录、哈希、模型输出和重建代码。
服务器两批的 holdout/private/ 保留本次真实输入；拥有合法来源数据的使用者可以重建。重建脚本需要原数据，无联网下载步骤。pilot_build_data.py只用于重建规则来源及旧病例排除清单，不重新运行旧模型实验。
模型输入是从合成病例截取的片段，标签是构造标签，不是MedGUIDE原生适用性标注或独立医生结论。
