#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
source /home/gcx/gcx261014/bin/activate
CARE_REPRO_SOURCE="${CARE_SOURCE:-/home/gcx/TRIAGE/data/MedGUIDE}"
CARE_REPRO_MODEL="${CARE_MODEL:-/home/gcx/n/models/Qwen3-8B}"
CARE_REPRO_GPU="${CARE_GPU:-6}"
CARE_REPRO_OUT="${1:?Pass a NEW absolute server output directory}"
case "$CARE_REPRO_OUT" in /*) ;; *) echo 'Output must be an absolute server path'; exit 1;; esac
case "$CARE_REPRO_GPU" in 0|1|2|3|6|7) ;; *) echo 'GPU is outside the authorized set'; exit 1;; esac
python prepare_reproduction.py --source "$CARE_REPRO_SOURCE" --out "$CARE_REPRO_OUT"
if [ "${2:-}" = '--data-only' ]; then exit 0; fi
for CARE_REPRO_ROUND in round1 round2; do
  test "$(nvidia-smi --id="$CARE_REPRO_GPU" --query-gpu=memory.free --format=csv,noheader,nounits)" -gt 24000
  cd -- "$CARE_REPRO_OUT/$CARE_REPRO_ROUND"
  CUDA_VISIBLE_DEVICES="$CARE_REPRO_GPU" python run_holdout.py --data holdout --model "$CARE_REPRO_MODEL" >run.log 2>&1
  python evaluate_holdout.py --data holdout >evaluation.log
done
