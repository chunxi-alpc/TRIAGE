"""One frozen inference run on unseen source cases; labels are never read here."""
import argparse,hashlib,json,os,pathlib,platform,time
from grounding import FIELDS,canonical_map,ground
from logic import evaluate,valid_schema
def read(p):return [json.loads(s) for s in p.read_text().splitlines()]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def parse(s):
 try:return json.loads(s)
 except Exception:
  try:return json.loads(s[s.index('{'):s.rindex('}')+1])
  except Exception:return None
COMMON='You are performing a research benchmark on clinical rule predicates. Use ONLY explicitly reported evidence. Do not infer absent facts from treatment choices or staging codes. Missing facts are unknown. Return one JSON object without explanation.'
MISSING='An unmentioned, unavailable, unreported, not performed, or pending result is UNKNOWN, never negative and never zero. A negative finding requires an explicit negative result for that specific test. A result for a different test is not evidence.'

def main(a):
 import torch,transformers
 from transformers import AutoTokenizer,AutoModelForCausalLM
 root=a.data;out=root/'model';out.mkdir(exist_ok=True)
 if any(out.glob('*_raw.jsonl')):raise RuntimeError('Use a fresh output folder, never overwrite model results.')
 for rel,h in json.loads((root/'frozen_data_hashes.json').read_text()).items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h
 frozen_code=json.loads((root/'frozen_code_hashes.json').read_text())
 for rel,h in frozen_code.items():assert hashlib.sha256(pathlib.Path(rel).read_bytes()).hexdigest()==h
 inputs=read(root/'private/inputs.jsonl');rules=read(root/'private/rules.jsonl');rb={x['rule_id']:x for x in rules}
 torch.manual_seed(20261018);tk=AutoTokenizer.from_pretrained(a.model,local_files_only=True,padding_side='left');tk.pad_token_id=tk.eos_token_id
 t=time.perf_counter();model=AutoModelForCausalLM.from_pretrained(a.model,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda:0').eval();load=time.perf_counter()-t
 env={'python':platform.python_version(),'torch':torch.__version__,'transformers':transformers.__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'model_path':str(a.model),'model_load_seconds':load,'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'generation':{'do_sample':False,'enable_thinking':False,'dtype':'bfloat16','batch':8,'seed':20261018},'run_scope':'new source-case holdout; frozen before any prediction; no tuning on holdout outputs'}
 dump(out/'environment.json',env)
 def generate(jobs,stage,max_new):
  rec=[];timings=[]
  for start in range(0,len(jobs),a.batch):
   batch=jobs[start:start+a.batch];texts=[tk.apply_chat_template([{'role':'system','content':j.get('system',COMMON)},{'role':'user','content':j['prompt']}],tokenize=False,add_generation_prompt=True,enable_thinking=False) for j in batch]
   enc=tk(texts,padding=True,return_tensors='pt').to('cuda:0');torch.cuda.synchronize();t=time.perf_counter()
   with torch.inference_mode():seq=model.generate(**enc,max_new_tokens=max_new,do_sample=False,pad_token_id=tk.pad_token_id,eos_token_id=tk.eos_token_id)
   torch.cuda.synchronize();elapsed=time.perf_counter()-t
   timings.append({'batch_start':start,'n':len(batch),'seconds':elapsed,'input_padded_tokens':int(enc.input_ids.shape[1]),'new_padded_tokens':int(seq.shape[1]-enc.input_ids.shape[1])})
   with (out/(stage+'_raw.jsonl')).open('a') as f:
    for j,ids,prompt in zip(batch,seq,texts):
     raw=tk.decode(ids[enc.input_ids.shape[1]:],skip_special_tokens=True);r={'id':j['id'],'raw_output':raw,'parsed':parse(raw),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'batch_start':start,'amortized_seconds':elapsed/len(batch)};rec.append(r);f.write(json.dumps(r,ensure_ascii=False)+'\n')
   print(json.dumps({'stage':stage,'completed':start+len(batch),'total':len(jobs)}),flush=True)
  dump(out/(stage+'_timing.json'),timings);return {x['id']:x for x in rec}
 rule_prompt='Extract the rule into this exact JSON schema: {"mode":"all" or "any", "conditions":[{"field":FIELD,"op":"lt|le|gt|ge|eq","value":number or "positive" or "negative"}],"exceptions":[]}. Use only FIELD names from '+json.dumps(FIELDS)+'. Convert units to these canonical units. Use all for AND, any for OR. Inclusive bounds use le/ge. Return only the object. Rule: '
 rex=generate([{'id':r['rule_id'],'prompt':rule_prompt+r['text']} for r in rules],'rule_extraction',256)
 keys={}
 for rid,r in rex.items():
  er=r['parsed'] or {};atoms=(er.get('conditions') or [])+(er.get('exceptions') or []);keys[rid]=sorted({x.get('field') for x in atoms if isinstance(x,dict) and x.get('field') in FIELDS})
 jobs={k:[] for k in ['direct','legacy_facts','fixed_facts']}
 for x in inputs:
  sid=x['sample_id'];rid=x['rule_id'];ks=keys[rid];text='\n'.join(f'[{i+1}] {s}' for i,s in enumerate(x['sentences']))
  jobs['direct'].append({'id':sid,'system':COMMON+' '+MISSING,'prompt':'Decide whether the following condition is satisfied. T = satisfied, F = contradicted, U = insufficient information. Use strong three-valued logic: false AND unknown is false; true OR unknown is true. Report {"label":"T|F|U","evidence_sentence_ids":[IDs]}. Cite the sentence(s) establishing the result, and [] if unknown. Convert units when necessary.\nRule: '+rb[rid]['text']+'\nCase:\n'+text})
  old='Extract the patient facts for these fields: '+json.dumps({k:FIELDS[k] for k in ks})+'. Use canonical units; 1 cm = 10 mm. Report a number, "positive", "negative", or null if not explicitly known. Return {"facts":{FIELD:value},"evidence":{FIELD:[sentence IDs]}}. For null use an empty evidence list. Include no thresholds or applicability labels.\nCase:\n'+text
  jobs['legacy_facts'].append({'id':sid,'prompt':old})
  template={'facts':{k:None for k in ks},'evidence':{k:[] for k in ks}}
  fixed='Extract ONLY these patient fields: '+json.dumps({k:FIELDS[k] for k in ks})+'. Preserve the exact field keys. Fill this JSON template: '+json.dumps(template)+'. Replace null ONLY when a cited sentence explicitly reports that value for this field. For missing results leave null and []. A non-null value MUST have a nonempty list of supporting sentence IDs. The word negative in an unrelated finding does not establish a negative result for this field. Use the specified canonical units; 1 cm = 10 mm. Output no applicability label or thresholds.\nCase:\n'+text
  jobs['fixed_facts'].append({'id':sid,'system':COMMON+' '+MISSING,'prompt':fixed})
 # Fixed order is part of the protocol. Report cumulative batching time, not single-request latency.
 direct=generate(jobs['direct'],'direct',96)
 legacy=generate(jobs['legacy_facts'],'legacy_facts',192)
 fixed=generate(jobs['fixed_facts'],'fixed_facts',224)
 predictions=[];checks=[];cpu_start=time.perf_counter()
 def prediction(label,eids,valid=True):return {'label':label,'evidence_sentence_ids':eids,'valid':valid}
 for x in inputs:
  sid=x['sample_id'];rid=x['rule_id'];rule=rex[rid]['parsed'];ks=keys[rid];d=direct[sid]['parsed'] or {};dl=d.get('label');de=d.get('evidence_sentence_ids',[]);rec={'sample_id':sid,'anchor_id':x['anchor_id'],'rule_id':rid,'direct':prediction(dl if dl in ['T','F','U'] else 'INVALID',de,dl in ['T','F','U'])}
  for name,raw in [('legacy_structured',legacy[sid]),('fixed_prompt_only',fixed[sid])]:
   obj=raw['parsed'] or {};facts=canonical_map(obj.get('facts'));ev=canonical_map(obj.get('evidence'));valid=valid_schema(rule) and bool(ks) and all(k in facts and k in ev for k in ks) and isinstance(obj.get('facts'),dict) and isinstance(obj.get('evidence'),dict)
   eids=sorted({i for k,vs in ev.items() if facts.get(k) is not None and isinstance(vs,list) for i in vs if type(i) is int and 1<=i<=len(x['sentences'])})
   rec[name]=prediction(evaluate(rule,facts) if valid else 'INVALID',eids,valid)
  facts,ev,audit=ground(fixed[sid]['parsed'],x['sentences'],ks);valid=rec['fixed_prompt_only']['valid']
  rec['structured_fixed']=prediction(evaluate(rule,facts) if valid else 'INVALID',sorted(set(i for vs in ev.values() for i in vs)),valid)
  checks.append({'sample_id':sid,'checks':audit});predictions.append(rec)
 (out/'predictions.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in predictions))
 (out/'evidence_checks.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in checks))
 env.update({'postprocessing_seconds':time.perf_counter()-cpu_start,'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30,'end_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())});dump(out/'environment.json',env);print('COMPLETE',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('holdout'));p.add_argument('--model',type=pathlib.Path,required=True);p.add_argument('--batch',type=int,default=8);main(p.parse_args())
