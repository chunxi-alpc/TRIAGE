"""Post-hoc replay of cached round-1 JSON with corrected ID parsing; NO inference.

Never replaces the frozen first-round predictions. This is diagnostic, not a new test.
"""
import json,pathlib,shutil,sys
BASE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'round2'))
from grounding import canonical_map,ground,normalize_ids
from logic import evaluate,valid_schema
from evaluate_holdout import main as evaluate_metrics
def read(p):return [json.loads(s) for s in p.read_text().splitlines()]
root=BASE/'holdout';out=BASE/'round1_posthoc'
if out.exists():raise RuntimeError('Do not overwrite the diagnostic replay.')
(out/'model').mkdir(parents=True)
for name in ['labels.jsonl','pairs.jsonl']:shutil.copy2(root/name,out/name)
for p in (root/'model').glob('*_timing.json'):shutil.copy2(p,out/'model'/p.name)
raw={stage:{x['id']:x['parsed'] for x in read(root/f'model/{stage}_raw.jsonl')} for stage in ['rule_extraction','direct','legacy_facts','fixed_facts']}
rows=[];checks=[]
for x in read(root/'private/inputs.jsonl'):
 sid=x['sample_id'];n=len(x['sentences']);rule=raw['rule_extraction'][x['rule_id']];ks=sorted({c['field'] for c in rule['conditions']+rule['exceptions']});row={k:x[k] for k in ['sample_id','anchor_id','rule_id']};d=raw['direct'][sid]
 row['direct']={'label':d['label'],'evidence_sentence_ids':normalize_ids(d.get('evidence_sentence_ids'),n),'valid':d['label'] in ['T','F','U']}
 for method,stage in [('legacy_structured','legacy_facts'),('fixed_prompt_only','fixed_facts')]:
  obj=raw[stage][sid];facts=canonical_map(obj.get('facts'));ev=canonical_map(obj.get('evidence'));valid=valid_schema(rule) and bool(ks) and all(k in facts and k in ev for k in ks)
  ids=sorted({i for k,v in ev.items() if facts.get(k) is not None for i in normalize_ids(v,n)})
  row[method]={'label':evaluate(rule,facts) if valid else 'INVALID','evidence_sentence_ids':ids,'valid':valid}
 facts,ev,audit=ground(raw['fixed_facts'][sid],x['sentences'],ks);valid=row['fixed_prompt_only']['valid']
 row['structured_fixed']={'label':evaluate(rule,facts) if valid else 'INVALID','evidence_sentence_ids':sorted({i for v in ev.values() for i in v}),'valid':valid}
 rows.append(row);checks.append({'sample_id':sid,'checks':audit})
for name,data in [('predictions.jsonl',rows),('evidence_checks.jsonl',checks)]:
 (out/'model'/name).write_text(''.join(json.dumps(x)+'\n' for x in data))
evaluate_metrics(out)
p=out/'metrics.json';m=json.loads(p.read_text());m['status']='posthoc_cached_replay_NOT_independent_validation';m['scope']='Only ID serialization corrected after seeing round1 outputs; no new model calls. Original round1 kept untouched.';p.write_text(json.dumps(m,indent=2)+'\n')
