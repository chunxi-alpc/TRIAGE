import json,pathlib,sys
from grounding import ground,canonical_map
from logic import evaluate
old=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
read=lambda n:[json.loads(s) for s in (old/n).read_text().splitlines()]
lb={x['sample_id']:x for x in read('labels.jsonl')};inputs={x['sample_id']:x for x in read('private/inputs.jsonl')};rules={x['id']:x['parsed'] for x in read('model/rule_extraction_raw.jsonl')};ps={x['sample_id']:x for x in read('model/predictions.jsonl')}
records=[]
for row in read('model/fact_extraction_raw.jsonl'):
 sid=row['id'];x=inputs[sid];r=rules[x['rule_id']];fields=sorted({z['field'] for z in r['conditions']});facts,ev,audit=ground(row['parsed'],x['sentences'],fields);label=evaluate(r,facts)
 records.append({'sample_id':sid,'gold':lb[sid]['label'],'previous':ps[sid]['structured_normalized']['label'],'guarded':label,'audit':audit})
six=[x for x in records if x['gold']=='U' and x['previous']!='U']
assert len(six)==6 and all(x['guarded']=='U' for x in six)
out.joinpath('pilot_regression.json').write_text(json.dumps({'scope':'development only, cached pilot outputs, no new inference','six_errors':six,'all_150_accuracy_before':sum(x['gold']==x['previous'] for x in records)/150,'all_150_accuracy_after':sum(x['gold']==x['guarded'] for x in records)/150,'introduced_errors':[x for x in records if x['gold']==x['previous'] and x['gold']!=x['guarded']]},indent=2)+'\n')
print(json.dumps({'six_fixed':len(six),'introduced_errors':sum(x['gold']==x['previous'] and x['gold']!=x['guarded'] for x in records)}))
