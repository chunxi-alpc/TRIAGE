"""New source-case holdout, chosen and labeled without any model predictions.

Labels are construction-derived from literal source values, not clinician gold.
Annotation extraction is independent of the evaluated model and logical evaluator.
"""
import argparse,collections,hashlib,json,pathlib,random,re
import pandas as pd

NUM_WORD={w:i for i,w in enumerate(['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty'])}
N=r'(?:\d+(?:\.\d+)?|'+'|'.join(NUM_WORD)+r')'
def num(s):return NUM_WORD[s.lower()] if s.lower() in NUM_WORD else float(s)
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
def split(s):return re.split(r'(?<=[.!?])\s+(?=[A-Z])',s)
def ngrams(s):
 ws=re.findall(r'[a-z]+',s.lower());return set(zip(ws,ws[1:],ws[2:]))
def sim(a,b):return len(a&b)/len(a|b) if a|b else 1
FIELD_SEARCH={
 'age':r'year.old|\bage\b','tumor_cm':r'tumou?r|carcinoma|\bmass\b|\bpT\d',
 'nodes':r'nodes?|SLN|N[0-3]','psadt':r'doubling|PSADT',
 'relapse_months':r'relaps|recurr','response_months':r'response|remission',
 'anc':r'\bANC\b|neutrophil','platelets':r'platelet','kps':r'Karnofsky|\bKPS\b','ecog':r'ECOG',
 'lesion_mm':r'lesion|nodule|\bmass\b','esophageal_cm':r'lesion|nodule|\bmass\b','lung_mm':r'nodule',
 'pcr':r'PCR|polymerase','margin':r'margin','her2':r'HER.?2'
}

def extract(field,s):
 """Return one literal factual value and the exact replaceable token span."""
 if not re.search(FIELD_SEARCH[field],s,re.I):return None
 if '?' in s:return None
 if field not in ['pcr','margin','her2']:
  # Intervals and inequality bounds are NOT point observations.
  if re.search(r'[<>≥≤]|\b(?:below|above|exceed\w*|between|under|over|less than|more than|greater than|at least|at most|or higher|or lower)\b|\d\s*[-–]\s*\d',s,re.I):return None
 if field=='age':p=rf'(?P<v>\d+)-year-old';scale=1
 elif field in ['tumor_cm','esophageal_cm','lesion_mm','lung_mm']:
  if field=='tumor_cm' and re.search(r'\b[pcy]T\d',s):return None
  p=rf'(?P<v>\d+(?:\.\d+)?)\s*(?P<unit>cm|mm)\b';scale=None
 elif field=='nodes':
  if re.search(r'N[0-3]',s):return None
  p=rf'(?P<v>{N})\s+positive\s+(?:axillary|sentinel)(?:\s+lymph)?\s+nodes?';scale=1
  if not re.search(p,s,re.I):p=rf'(?P<v>{N})\s+(?:out\s+of|of)\s+(?:{N})\s+(?:(?:axillary|sentinel)\s+)?(?:lymph\s+)?nodes?(?:\s+were)?\s+positive'
 elif field=='anc':p=rf'(?:\bANC\b|absolute neutrophil count)[^.;\d]{{0,32}}(?P<v>\d+(?:\.\d+)?)\s*(?:[x×]\s*10|\b)';scale=1
 elif field=='platelets':p=rf'platelet(?:\s+count)?s?[^.;\d]{{0,32}}(?P<v>\d+(?:\.\d+)?)';scale=1
 elif field=='kps':p=rf'(?:Karnofsky(?:\s+performance)?(?:\s+score)?|\bKPS\b)[^.;\d]{{0,28}}(?P<v>\d+)';scale=1
 elif field=='ecog':
  p=rf'(?:ECOG(?:\s+performance)?(?:\s+(?:status|score))?[^.;\d]{{0,20}}(?P<v>\d+))';scale=1
  if not re.search(p,s,re.I):p=rf'(?:scores?|scored)\s+(?P<v>\d+)\s+(?:on\s+the\s+)?ECOG'
 elif field in ['relapse_months','response_months','psadt']:
  if re.search(r'\b(?:over|under|less than|more than|greater than|within|at least|at most)\b',s,re.I):return None
  if field=='relapse_months' and not re.search(r'(?:after|following)\s+(?:complet\w*|[^.;]{0,25}(?:treatment|therapy|regimen))|post.?treatment',s,re.I):return None
  if field=='response_months':
   if re.search(r'\bevery\b|\bago\b',s,re.I):return None
   if not re.search(r'(?:response|remission)[^.;]{0,30}'+N+r'\s+months?',s,re.I):return None
  p=rf'(?P<v>{N})\s+months?\b';scale=1
 else:
  # Restrict annotation to transparent category/result links.
  if field=='pcr':p=r'(?P<v>positive|negative)\s+(?:for\s+)?PCR|PCR\s*[-:]?\s*(?P<w>positive|negative)|PCR\s+(?:test\s+)?(?:was\s+|is\s+|remained\s+)?(?P<z>positive|negative)'
  elif field=='her2':p=r'HER[- ]?2\s*[-:]?\s*(?P<v>positive|negative)|(?P<w>positive|negative)\s+for\s+HER[- ]?2'
  else:p=r'(?P<v>positive|negative)\s+(?:(?:surgical|resection)\s+)?margins?|margins?\s+(?:were\s+|was\s+|are\s+|is\s+)?(?P<w>positive|negative)'
  ms=list(re.finditer(p,s,re.I))
  if len(ms)!=1:return None
  m=ms[0];k=next(k for k in ['v','w','z'] if k in m.groupdict() and m.group(k));return {'value':m.group(k).lower(),'start':m.start(k),'end':m.end(k),'token':m.group(k),'scale':1}
 ms=list(re.finditer(p,s,re.I))
 if len(ms)!=1:return None
 m=ms[0];v=num(m.group('v'))
 if scale is None:
  unit=m.group('unit').lower();scale=(10 if unit=='cm' else 1) if field.endswith('_mm') else (0.1 if unit=='mm' else 1)
 return {'value':v*scale,'start':m.start('v'),'end':m.end('v'),'token':m.group('v'),'scale':scale}

def gold_label(rule,facts):
 # A separate, annotation-only calculation; never imported by the predictor.
 def judge(c):
  v=facts[c['field']];t=c['value']
  if c['op']=='lt':return v<t
  if c['op']=='le':return v<=t
  if c['op']=='gt':return v>t
  if c['op']=='ge':return v>=t
  if c['op']=='eq':return v==t
  raise ValueError(c)
 vals=[judge(c) for c in rule['conditions']]
 return 'T' if (all(vals) if rule['mode']=='all' else any(vals)) else 'F'

def counterfactual(rule,facts):
 desired='F' if gold_label(rule,facts)=='T' else 'T';fields=sorted(facts)
 pools={}
 for f in fields:
  atoms=[c for c in rule['conditions'] if c['field']==f]
  pools[f]=['negative','positive'] if isinstance(facts[f],str) else sorted({c['value'] for c in atoms}|{c['value']-1 for c in atoms}|{c['value']+1 for c in atoms})
  if f in ['anc']:pools[f]=[0.4,0.5,0.6]
  if f=='kps':pools[f]=[50,60,70]
  if f=='ecog':pools[f]=[1,2,3,4]
  if f=='nodes':pools[f]=[v for v in pools[f] if v>0]
 import itertools
 candidates=[]
 for vs in itertools.product(*(pools[f] for f in fields)):
  cf=dict(zip(fields,vs))
  if any(isinstance(v,(float,int)) and v<0 for v in vs):continue
  if gold_label(rule,cf)!=desired:continue
  changes=sum(cf[f]!=facts[f] for f in fields)
  distance=sum(abs(cf[f]-facts[f]) if isinstance(cf[f],(int,float)) else cf[f]!=facts[f] for f in fields)
  # Prefer exact boundary values when they produce the requested flip.
  boundary=-sum(any(cf[f]==c['value'] for c in rule['conditions'] if c['field']==f) for f in fields)
  candidates.append(((changes,boundary,distance),cf))
 assert candidates
 return min(candidates,key=lambda x:x[0])[1]

def build(source,old,out):
 out.mkdir(parents=True,exist_ok=True);(out/'private').mkdir(exist_ok=True)
 read=lambda p:[json.loads(s) for s in p.read_text().splitlines()]
 old_labels=read(old/'labels.jsonl');used={x['source_row'] for x in old_labels};df=pd.read_parquet(source/'data/train-00000-of-00001.parquet');rules=read(old/'private/rules.jsonl')
 rng=random.Random(20261018);order=list(range(2500,len(df)));rng.shuffle(order)
 previous=[ngrams(df.iloc[i].profile) for i in used];accepted_grams=[];selected=set();records=[];labels=[];pairs=[];annotations=[];reasons=collections.Counter();coverage={}
 for rule in rules:
  rid=rule['rule_id'];rs=rule['schema_gold'];fields=sorted({c['field'] for c in rs['conditions']});source_node=df.iloc[rule['source_row']]['path'][rule['source_node_index']];got=0
  for i in order:
   row=df.iloc[i]
   relevant=source_node in row.path
   # Opposing branch cases are valid inputs for the same predicate and give real F examples.
   if rid in ['R09','R10']:relevant=any('positive axillary nodes' in z for z in row.path)
   if rid=='R25':relevant=any('Previous response with long duration' in z or 'No response or short duration' in z for z in row.path)
   if i in used or i in selected or not relevant:continue
   if any(f in fields for f in ['esophageal_cm','lesion_mm']) and not re.search(r'esopha|Barrett',row.profile,re.I):continue
   grams=ngrams(row.profile)
   if any(sim(grams,g)>=0.70 for g in previous) or any(sim(grams,g)>=0.80 for g in accepted_grams):reasons['near_duplicate']+=1;continue
   ss=split(row.profile);found={}
   for f in fields:
    matches=[(j,extract(f,s)) for j,s in enumerate(ss)];matches=[(j,v) for j,v in matches if v is not None]
    if not matches:break
    # Permit repeats only if they agree; use the first explicit value.
    if len({json.dumps(v['value']) for _,v in matches})>1:break
    found[f]=matches[0]
   if len(found)!=len(fields):reasons['no_unambiguous_literal_value']+=1;continue
   target_ids=sorted({j for j,_ in found.values()});targets=[ss[j] for j in target_ids]
   # Reject negated/hypothetical target sentences as annotation gold would be uncertain.
   if any(re.search(r'\b(?:if|whether|not positive|not negative)\b',s,re.I) for s in targets):reasons['conditional_sentence']+=1;continue
   if any(f in fields for f in ['pcr','margin','her2']) and any(re.search(r'no detectable|no residual|completely excised|molecular testing|confirmed via|persistent molecular evidence',s,re.I) for s in targets):reasons['redundant_result_assertion']+=1;continue
   facts={f:v['value'] for f,(_,v) in found.items()};cf=counterfactual(rs,facts)
   if 'nodes' in fields:
    totals=[num(m.group(1)) for s in targets for m in re.finditer(r'(?:out of|\bof)\s+('+N+r')\s+(?:(?:axillary|sentinel)\s+)?(?:(?:lymph\s+)?nodes|sampled|examined|removed)',s,re.I)]
    if totals and cf['nodes']>min(totals):reasons['counterfactual_exceeds_total_nodes']+=1;continue
   # Remove other mentions of required fields from context to prevent hidden labels after deletion.
   blockers='|'.join(FIELD_SEARCH[f] for f in fields)
   context=[s for j,s in enumerate(ss) if j not in target_ids and len(s)>35 and not re.search(blockers,s,re.I) and '?' not in s]
   if len(context)<3:reasons['insufficient_context']+=1;continue
   context=context[:3];edited=list(targets);edits=[]
   for local,j in enumerate(target_ids):
    replacements=[]
    for f,(idx,v) in found.items():
     if idx!=j or cf[f]==facts[f]:continue
     new=cf[f] if isinstance(cf[f],str) else format(cf[f]/v['scale'],'g')
     replacements.append((v['start'],v['end'],new,f))
    s=ss[j]
    for start,end,new,f in sorted(replacements,reverse=True):
     edits.append({'field':f,'original_token':s[start:end],'replacement':new,'source_sentence_index':j,'token_start':start,'token_end':end});s=s[:start]+new+s[end:]
    # Remove redundant interpretive adjectives in edited timing statements.
    s=re.sub(r'\bapproximately\s+','',s,flags=re.I)
    if any(f in fields for f in ['relapse_months','response_months']):
     s=re.sub(r'\brapid and\s+','',s,flags=re.I)
     s=re.sub(r'\b(?:early|late|short|brief|long|rapid|only)\s+','',s,flags=re.I)
    if any(f in fields for f in ['kps','ecog']):
     # Keep the explicit score clause; remove ancillary functional descriptions for CF coherence.
     score=re.search(r'Karnofsky|\bECOG\b',s,re.I)
     if score:
      s=s[score.start():]
      s=re.split(r',\s*(?:evidencing|indicating|suggesting)',s)[0].rstrip('.')+'.'
    if any(f in fields for f in ['pcr','margin','her2']):s=re.sub(r',\s*(?:indicating|suggesting|consistent with|confirming)\b.*[.]$', '.',s,flags=re.I)
    edited[local]=s
   aid=f'H{len(pairs)+1:02}';base_parts=[('context',s,None) for s in context]+[('target',s,j) for s,j in zip(targets,target_ids)];rng.shuffle(base_parts)
   indices={j:k+1 for k,(kind,s,j) in enumerate(base_parts) if kind=='target'}
   missing_kind=['omitted','pending','unreported'][len(pairs)%3]
   readable={'relapse_months':'the time from treatment to relapse','anc':'the absolute neutrophil count','platelets':'the platelet count','age':'the patient age','tumor_cm':'the tumor diameter','nodes':'the number of positive axillary lymph nodes','psadt':'the PSA doubling time','lesion_mm':'the lesion diameter','esophageal_cm':'the esophageal lesion diameter','kps':'the Karnofsky score','ecog':'the ECOG score','lung_mm':'the pulmonary nodule diameter','response_months':'the duration of treatment response','pcr':'the PCR result','margin':'the surgical margin result','her2':'the HER2 result'}
   pending=('The assessment is pending; '+', '.join(readable[f] for f in fields)+' is not yet available.') if missing_kind=='pending' else ('The available record does not report '+', '.join(readable[f] for f in fields)+'.')
   for variant in ['original','counterfactual','unknown']:
    sid=aid+'_'+variant;parts=[];eids=[]
    for kind,s,j in base_parts:
     if kind=='target':
      if variant=='unknown':continue
      s=edited[target_ids.index(j)] if variant=='counterfactual' else s;eids.append(len(parts)+1)
     parts.append(s)
    if variant=='unknown' and missing_kind!='omitted':parts.insert(rng.randrange(len(parts)+1),pending)
    label='U' if variant=='unknown' else gold_label(rs,cf if variant=='counterfactual' else facts)
    records.append({'sample_id':sid,'anchor_id':aid,'rule_id':rid,'sentences':parts})
    labels.append({'sample_id':sid,'anchor_id':aid,'rule_id':rid,'source_row':i,'source_profile_sha256':sha(row.profile),'variant':variant,'label':label,'evidence_sentence_ids':eids,'gold_facts':{f:None for f in fields} if variant=='unknown' else cf if variant=='counterfactual' else facts,'unknown_form':missing_kind if variant=='unknown' else None,'annotation_method':'literal source extraction, construction-derived labels; no model prediction used; no clinician review','source_targets':[{'sentence_index':j,'char_start':row.profile.index(ss[j]),'char_end':row.profile.index(ss[j])+len(ss[j]),'sha256':sha(ss[j])} for j in target_ids],'edits':edits if variant=='counterfactual' else []})
   pairs.append({'pair_id':aid,'original_id':aid+'_original','counterfactual_id':aid+'_counterfactual','expected_label_change':True,'source_row':i})
   annotations.append({'anchor_id':aid,'source_row':i,'rule_id':rid,'rule':rule['text'],'facts':facts,'counterfactual_facts':cf,'targets':targets,'edited':edited,'context':context})
   selected.add(i);accepted_grams.append(grams);got+=1
   if got==2:break
  coverage[rid]=got
 # Candidate text is server-private, used only for checking annotation before inference.
 (out/'private/annotation_review.json').write_text(json.dumps(annotations,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'coverage':coverage,'unique_cases':len(selected),'rejection_counts':reasons}))
 if len(selected)!=60:raise RuntimeError('Require exactly two new source cases per rule; inspect coverage before inference.')
 for path,data in [('private/inputs.jsonl',records),('private/rules.jsonl',rules),('labels.jsonl',labels),('pairs.jsonl',pairs)]:
  (out/path).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in data))
 audit={'source_revision':'1460ec478280a7295040b92f7eb985327f77dcbe','seed':20261018,'source_rows_minimum':2500,'previous_case_rows':sorted(used),'new_case_rows':sorted(selected),'case_overlap':len(used&selected),'rules':30,'unique_new_source_cases':60,'samples':180,'label_counts':dict(collections.Counter(x['label'] for x in labels)),'label_changing_pairs':60,'unknown_forms':dict(collections.Counter(x['unknown_form'] for x in labels if x['variant']=='unknown')),'near_duplicate_policy':'word trigram Jaccard <0.70 against pilot profiles; <0.80 within new source profiles','max_similarity_to_pilot':max(sim(a,b) for a in accepted_grams for b in previous),'rejection_counts':dict(reasons),'limitations':['same 30 rule predicates as pilot, not unseen rule evaluation','source synthetic vignettes; literal-value filtered subset','3 context sentences plus 1-2 evidence sentences; not whole guideline applicability','construction-derived annotations; no independent physician gold','no grouping by original patient identity exists in MedGUIDE; row/hash separation cannot rule out latent template relatedness'],'missing_result_fix_frozen_before_inference':True}
 (out/'dataset_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 files=['private/inputs.jsonl','private/rules.jsonl','labels.jsonl','pairs.jsonl','dataset_audit.json']
 (out/'frozen_data_hashes.json').write_text(json.dumps({f:hashlib.sha256((out/f).read_bytes()).hexdigest() for f in files},indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--pilot',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,default=pathlib.Path('holdout'));a=p.parse_args();build(a.source,a.pilot,a.out)
