"""Create the report and comparison table from executed server results."""
import csv,json,pathlib
base=pathlib.Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
r1=load(base/'holdout/metrics.json');post=load(base/'round1_posthoc/metrics.json');r2=load(base/'round2/holdout/metrics.json');audit=load(base/'round2/holdout/dataset_audit.json');env=load(base/'round2/holdout/model/environment.json')
names={'direct':'直接判定','legacy_structured':'旧版抽取（含字段名统一）','fixed_prompt_only':'新版抽取，不核对证据内容','structured_fixed':'新版抽取＋证据核对＋确定性判断'}
with (base/'comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['round','status','method','n','correct','macro_f1','evidence_known_correct','evidence_known_n','evidence_all_correct','pair_correct','pair_n','unknown_correct','unknown_n','known_to_unknown','generation_seconds_including_rule_extraction'])
 for rnd,m in [('round1_original',r1),('round1_posthoc_replay',post),('round2_confirmatory',r2)]:
  for k,v in m['methods'].items():w.writerow([rnd,m['status'],k,m['n'],v['correct'],v['macro_f1'],v['evidence_known_correct'],120,round(v['evidence_all_accuracy']*m['n']),v['pair_correct'],v['pair_n'],v['unknown_correct'],60,v['known_to_unknown'],v['timing']['total_generation_seconds']])
table=[]
for k in ['direct','legacy_structured','fixed_prompt_only','structured_fixed']:
 v=r2['methods'][k]
 table.append(f"{names[k]}：F1 {v['macro_f1']:.4f}；正确 {v['correct']}/180；证据 {v['evidence_known_correct']}/120；反事实 {v['pair_correct']}/60；未知 {v['unknown_correct']}/60；耗时 {v['timing']['total_generation_seconds']:.2f}秒。")
ci=r2['paired_cluster_bootstrap']['percentile_95_interval'];delta=r2['paired_cluster_bootstrap']['delta_macro_f1_structured_minus_direct']
report=f'''CARE模块一：未知样本误判分析、修复与独立新病例验证

结论
已在指定服务器真实运行Qwen3-8B。最终方案在第二批60个新源病例构造的180条样本上全部正确，直接判定正确167条；宏平均F1分别为1.0000和0.9277。结果支持结构化方案在本次“明确数值/类别条件＋缺失信息”受控任务中有效，尚不能推广为真实临床适用性验证。

一、原来6条未知为什么被误判
全部错误都发生在事实抽取阶段：未提供结果，却被抽成negative。确定性比较器随后把错误事实当成已知值；没有证据约束来阻止这个过程。

样本                字段    原输出→正确输出  可核查原因
A26_unknown        PCR     T→U            无PCR结果，却抽为阴性并引用缺失说明句。
A27_unknown        PCR     F→U            同上，阳性规则因此被错误判为不满足。
A28_unknown        切缘    T→U            抽为阴性，证据列表为空。
A29_unknown        切缘    F→U            抽为阴性，证据列表为空。
A30_unknown        HER2    T→U            无HER2结果，却抽为阴性并引用缺失说明句。
A49_unknown        PCR     F→U            与A26共用源病例，对另一条规则重复发生。

因此是6个“病例—规则”样本、5个源病例；不是6个独立患者。4条引用不支持结果的句子，2条无证据。原始JSON见development/six_error_details.json。缓存回归6/6修复，旧150条中未引入新错误；这是开发检查，不计作独立效果验证。

二、实际修复
1. 统一字段名，固定JSON字段；明确未提及、未检查、未记录、待回报均为null，不是阴性或零。直接判定也获得相同缺失语义说明。
2. 非空事实必须给出证据句。核对句子是否提及对应字段并支持该值；不同检测的阴性不能替代目标检测结果。失败的事实回到null，再执行强三值逻辑。
3. 对所有方法统一规范化句子编号，接受整数1与字符串"1"，拒绝越界、布尔值和自由文本。保留每次接受/拒绝的原因。
数值证据检查是字段词＋字面值/单位转换核对，不是完整医学语义推断；复杂否定、多个同类数值和时间关系仍有风险。

三、如何避免在旧样本上得到好看的结果
旧实验23个源病例仅用于开发。第一批另选60例；它暴露了接口错误：104条模型输出包含字符串证据编号，整数限定解析使94条已知样本被误拒绝。该批结构化主方案F1仅{r1['methods']['structured_fixed']['macro_f1']:.4f}，直接法{r1['methods']['direct']['macro_f1']:.4f}。失败原始结果保留在holdout/，未覆盖。
修正编号后，缓存重放达到180/180，但明确标为事后分析，见round1_posthoc/，不作为独立验证。
随后重新冻结代码与数据，第二批再选60个新源病例，排除旧23例和第一批60例。三批源行交集均为0；第二批对全部先前病例的最大词三元组Jaccard相似度为{audit['max_similarity_to_previous']:.3f}。不存在原始患者身份分组，仍不能排除潜在模板关联。
第二批每条原有规则2例，共30条规则、180条样本，满足/不满足/未知各60条；原始、反事实、缺失各60条，60对反事实均预设标签改变。未知含完全删去结果、待回报、未记录三种形式，各20条。每条输入为3句原文上下文加1–2句证据；不是完整病历。
推理前检查了事实值和编辑，排除把“几个月前复发”当成“治疗后几个月复发”、数值范围当点值，以及反事实与附带检测解释相冲突的情况。功能评分反事实同时去除不再匹配的功能描述，故不能把全部60对称为严格单事实编辑。
标签来自明确原文事实和预设编辑，未使用被测模型预测造标签；无独立医生标注。完整冻结哈希和重建检查均通过。第二批推理之后没有调整标签、提示或判断逻辑。

四、第二批主要结果
{chr(10).join(table)}

主要比较：直接判定 vs 最后一行完整修复方案。其余两行为推理前已列出的诊断对照。
证据指标是已知120条的证据句集合完全匹配。全部180条的证据匹配，直接法{round(r2['methods']['direct']['evidence_all_accuracy']*180)}/180，最终方案{round(r2['methods']['structured_fixed']['evidence_all_accuracy']*180)}/180；未知的正确证据是空列表。直接法有40条虽正确判未知，仍引用无关句子，故全部样本的证据成绩低于已知子集。成对正确要求原始和反事实两端都正确。
结构化F1提高{delta*100:.2f}个百分点。按60个源病例进行2000次配对重采样，差值95%百分位区间为[{ci[0]*100:.2f}, {ci[1]*100:.2f}]个百分点；每例三个变体一起抽样。该区间只描述这批受控病例，不代表真实临床人群。

五、差异来自哪里
直接法13条错误中，11条把已知事实判为未知，2条判断方向错误。可核查例子包括：5 cm不满足“>5 cm”、10个月不满足“>10个月”、8 mm不满足“>8 mm”，却被判未知；6 mm被判满足“<6 mm”。相关原始输出见round2/holdout/errors.jsonl。这里描述可观察错误，不推断模型内部原因。
只修改抽取提示仍漏了H19_unknown：没有淋巴结计数，却抽出nodes=1，并引用无淋巴结信息的句子。证据核对拒绝该值，将其恢复为未知。说明仅提示改写不足以完全消除无依据抽取。
最终方案120条已知样本没有被误拒绝，60条未知全部识别；直接法也识别全部60条未知。因此相对直接法的本轮优势主要是已知数值、边界及条件判断，不能声称未知识别率更高。
模型提取30条规则，28条JSON完全相同；另2条单条件规则写为any而参考为all，逻辑等价。因此本批规则语义比较为30/30。模型未使用参考结构或参考事实代替自身抽取。

六、运行、耗时与限制
服务器gcx@10.29.128.115；GPU 6，{env['gpu']}；Qwen3-8B本地权重，BF16、batch=8、greedy、关闭thinking、seed=20261018，无训练。
第二批模型记录UTC {env['start_utc']}至{env['end_utc']}（北京时间加8小时）；峰值已分配显存{env['peak_allocated_gib']:.2f} GiB、预留{env['peak_reserved_gib']:.2f} GiB。模型加载{env['model_load_seconds']:.2f}秒。
表中耗时为同步CUDA批量生成时间，结构化含一次性规则提取6.36秒；不含模型加载、分词、文件读写。完整结构化约为直接法的3.0倍，规则缓存后可省去提取成本；这不是单请求在线延迟比较。全部诊断对照的本轮模型阶段约83秒。
第一批最初误启动于已被占用的GPU 1，发现后立即停止了自己的进程，尚未产生评估预测；该次环境记录保留在attempts/。之后两批有效推理均在GPU 6。

这些是实际运行结果，但数据来自MedGUIDE合成病例的明确事实子集。30条规则沿用旧实验，字段词典固定；没有验证新规则、复杂病历、完整指南适用性、行动建议或例外条件。本次原始/反事实样本多为容易定位的数字和类别，未知由受控删除或模板构造，不能据100%外推真实场景。
下一步应冻结本版，在新规则和完整病例上做有独立人工复核的测试，重点加入部分缺失、多时间点、多个数值、明确否定和互相矛盾的记录；继续同时报告已知误拒绝率和耗时。

交付与来源
代码、标签/索引、原始输出、全部对照、失败轮次、日志及复现说明均已保存。6项针对性单元测试通过，两批数据重建后全部冻结哈希一致。源码和模型原始结果均没有用报告数字反向生成。
MedGUIDE本地数据卡许可证为TBD；交付包不分发病例原文、原始路径全文、parquet或模型权重。真实输入仅保留于服务器各holdout/private/，有合法来源数据后可用代码重建。详见README.zh.txt。
数据：https://huggingface.co/datasets/MedGUIDE/MedGUIDE-MCQA-8K
数据论文：https://arxiv.org/abs/2505.11613
方法参考：https://github.com/ncbi-nlp/TrialGPT/blob/main/trialgpt_matching/TrialGPT.py
模型：https://huggingface.co/Qwen/Qwen3-8B
本实验只参考TrialGPT-Matching的逐条件处理、编号证据和结构化输出，采用自定义缺失语义与确定性比较器，不是原论文复现。
'''
(base/'REPORT.zh.txt').write_text(report,encoding='utf-8')
print('Report and comparison table generated from actual metrics.')
