"""Evidence checks frozen using pilot errors, before new model predictions.

Conservative literal support checks, not a medical NLI model. A rejection becomes
missing/unknown, never a negative finding. Both accepted and rejected evidence is logged.
"""
import math,re
FIELDS = {
 'relapse_months':'Time from treatment completion to relapse, in months',
 'anc':'Absolute neutrophil count, in 10^9/L','platelets':'Platelet count, in 10^9/L',
 'age':'Patient age, in years','tumor_cm':'Breast tumor diameter, in cm',
 'nodes':'Number of positive axillary lymph nodes','psadt':'PSA doubling time, in months',
 'lesion_mm':'Esophageal lesion diameter, in mm','esophageal_cm':'Esophageal nodule/mass diameter, in cm',
 'kps':'Karnofsky performance score, percent','ecog':'ECOG performance score',
 'lung_mm':'Pulmonary nodule diameter, in mm','response_months':'Duration of previous treatment response/remission, in months',
 'pcr':'PCR result, positive or negative','margin':'Surgical margin result, positive or negative',
 'her2':'HER2 result, positive or negative'
}
ALIASES={
 'relapse_months':r'\b(relaps\w*|recurr\w*)\b','anc':r'\b(ANC|absolute neutrophil count)\b',
 'platelets':r'\bplatelet\w*\b','age':r'year.old|\baged?\b','tumor_cm':r'\b(tumou?r|carcinoma|mass)\b',
 'nodes':r'\b(nodes?|SLNs?)\b','psadt':r'\b(PSADT|doubling)\b',
 'lesion_mm':r'\b(lesion|nodule|mass)\b','esophageal_cm':r'\b(lesion|nodule|mass)\b',
 'kps':r'\b(Karnofsky|KPS)\b','ecog':r'\bECOG\b','lung_mm':r'\bnodule\w*\b',
 'response_months':r'\b(response|remission)\b','pcr':r'\bPCR\b','margin':r'\bmargins?\b','her2':r'\bHER[- ]?2\b'
}
WORD_NUM={w:i for i,w in enumerate(['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty'])}

def canonical_map(obj):
 if not isinstance(obj,dict):return {}
 reverse={v:k for k,v in FIELDS.items()};out={}
 for k,v in obj.items():
  key=reverse.get(k,k)
  if key not in FIELDS:continue
  if key in out and out[key]!=v:out[key]=None
  else:out[key]=v
 return out

def category_supported(field,value,text):
 """Require an explicit relation, not 'negative' elsewhere in a sentence."""
 if value not in ['positive','negative']:return False
 v=re.escape(value)
 patterns={
  'pcr':[rf'\b{v}\s+(?:for\s+)?PCR\b',rf'\bPCR\s*[-:]?\s*{v}\b',rf'\bPCR\s+(?:(?:test|testing|result|results|status|levels?)\s+)?(?:(?:was|were|is|are|returned|tested|remained|came\s+back)\s+)?{v}\b'],
  'her2':[rf'\bHER[- ]?2\s*[-:]?\s*{v}\b',rf'\bHER[- ]?2\s+(?:(?:test|testing|result|results|status|expression)\s+)?(?:(?:was|were|is|are|returned|tested|remained)\s+)?{v}\b',rf'\b{v}\s+(?:for\s+)?HER[- ]?2\b'],
  'margin':[rf'\b{v}\s+(?:(?:surgical|resection|tumou?r)\s+)?margins?\b',rf'\bmargins?\s+(?:(?:was|were|is|are|returned|tested|remained|showed|show)\s+)?(?:all\s+)?{v}\b']
 }
 for pat in patterns[field]:
  for m in re.finditer(pat,text,re.I):
   prefix=text[max(0,m.start()-20):m.start()]
   # Reject hypothetical/negated results (e.g. 'not HER2 positive').
   if re.search(r'\b(?:not|if|whether)\s*$',prefix,re.I):continue
   return True
 return False

def numeric_supported(field,value,text):
 if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):return False
 if not re.search(ALIASES[field],text,re.I):return False
 # Check literal value or a transparent cm/mm conversion. This is not relation extraction.
 values=[float(v) for v in re.findall(r'(?<![A-Za-z])\d+(?:\.\d+)?',text)]
 values += [float(WORD_NUM[w.lower()]) for w in re.findall(r'\b[a-z]+\b',text,re.I) if w.lower() in WORD_NUM]
 if field.endswith('_mm'):
  values += [float(v)*10 for v in re.findall(r'(\d+(?:\.\d+)?)\s*cm\b',text,re.I)]
 if field.endswith('_cm'):
  values += [float(v)/10 for v in re.findall(r'(\d+(?:\.\d+)?)\s*mm\b',text,re.I)]
 return any(abs(v-value)<1e-6 for v in values)

def normalize_ids(ids,n):
 """Lossless JSON interface normalization, shared by every comparison arm.

 Accept integer IDs and decimal strings such as '1'; never coerce booleans,
 floats, free text, negative numbers or out-of-range references.
 """
 if not isinstance(ids,list):return []
 out=[]
 for x in ids:
  if isinstance(x,str) and re.fullmatch(r'[1-9][0-9]*',x):x=int(x)
  if type(x) is int and 1<=x<=n:out.append(x)
 return sorted(set(out))

def ground(parsed,sentences,required_fields):
 parsed=parsed if isinstance(parsed,dict) else {}
 facts=canonical_map(parsed.get('facts'));ev=canonical_map(parsed.get('evidence'));out={};evidence={};audit=[]
 for field in required_fields:
  value=facts.get(field);ids=ev.get(field,[])
  ids=normalize_ids(ids,len(sentences))
  reason='accepted';supported=[]
  if value is None:reason='model_missing'
  elif not ids:reason='no_valid_evidence'
  else:
   for i in ids:
    s=sentences[i-1]
    ok=category_supported(field,value,s) if field in ['pcr','margin','her2'] else numeric_supported(field,value,s)
    if ok:supported.append(i)
   if not supported:reason='cited_sentence_does_not_support_value'
  out[field]=value if reason=='accepted' else None
  evidence[field]=supported if reason=='accepted' else []
  audit.append({'field':field,'proposed_value':value,'accepted_value':out[field],'proposed_ids':ids,'accepted_ids':evidence[field],'reason':reason})
 return out,evidence,audit
