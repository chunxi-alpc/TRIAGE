"""Read-only final consistency audit; run on the experiment server."""
import collections,hashlib,json,pathlib
base=pathlib.Path(__file__).resolve().parent
read=lambda p:[json.loads(s) for s in p.read_text().splitlines()]
out={}
for name,code in [('round1',base),('round2',base/'round2')]:
 root=code/'holdout';labels=read(root/'labels.jsonl');pred=read(root/'model/predictions.jsonl');pairs=read(root/'pairs.jsonl')
 for file,h in json.loads((root/'frozen_data_hashes.json').read_text()).items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==h
 for file,h in json.loads((root/'frozen_code_hashes.json').read_text()).items():assert hashlib.sha256((code/file).read_bytes()).hexdigest()==h
 assert len(labels)==len(pred)==180 and len({x['sample_id'] for x in pred})==180
 ids={x['sample_id'] for x in labels};assert ids=={x['sample_id'] for x in pred}
 assert len(pairs)==60 and all(p['original_id'] in ids and p['counterfactual_id'] in ids for p in pairs)
 rules={x['rule_id']:x['schema_gold'] for x in read(root/'private/rules.jsonl')}
 extracted={x['id']:x['parsed'] for x in read(root/'model/rule_extraction_raw.jsonl')}
 def normalized(r):
  r=dict(r)
  if len(r['conditions'])==1:r['mode']='all'
  r['conditions']=sorted(r['conditions'],key=lambda c:json.dumps(c,sort_keys=True))
  return r
 out[name]={'data_and_code_hashes_unchanged':True,'unique_source_cases':len({x['source_row'] for x in labels}),'literal_schema_match':sum(extracted[k]==rules[k] for k in rules),'schema_match_after_single_atom_all_any_equivalence':sum(normalized(extracted[k])==normalized(rules[k]) for k in rules),'rules':len(rules)}
old=read(pathlib.Path('/home/gcx/care_module1_20261017/results/labels.jsonl'));r1=read(base/'holdout/labels.jsonl');r2=read(base/'round2/holdout/labels.jsonl')
sets=[{x['source_row'] for x in xs} for xs in [old,r1,r2]]
assert not sets[0]&sets[1] and not sets[0]&sets[2] and not sets[1]&sets[2]
out['source_row_overlap']={'pilot_round1':0,'pilot_round2':0,'round1_round2':0}
f=read(base/'holdout/model/fixed_facts_raw.jsonl');checks=read(base/'holdout/model/evidence_checks.jsonl')
out['round1_interface_failure']={'samples_with_string_evidence_ids':sum(any(isinstance(i,str) for vs in x['parsed']['evidence'].values() for i in vs) for x in f),'known_samples_rejected_as_unknown':json.loads((base/'holdout/metrics.json').read_text())['methods']['structured_fixed']['known_to_unknown'],'raw_guard_reasons':dict(collections.Counter(a['reason'] for x in checks for a in x['checks']))}
out['reproduction']='Rebuilt both datasets from local source in reproduction_check; every frozen data and code hash matched.'
(base/'final_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
