#!/usr/bin/env bash
set -e
cd /home/gcx/TRIAGE-worktrees/care-module1-u-examples-dev
tail --pid=2978340 -f /dev/null
source /home/gcx/gcx261014/bin/activate
python experiments/care_module1_u_examples_dev/analyze.py
