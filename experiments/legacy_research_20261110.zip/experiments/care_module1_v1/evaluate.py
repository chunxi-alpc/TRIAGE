"""Score fixed predictions, preserving invalid responses and class support."""
import argparse,collections,json,pathlib,time
from logic import evaluate

def read(p):return [json.loads(s) for s in p.read_text().splitlines() if s]
def metric(gold,pred):
 details={}
 for c in ['T','F','U']:
  tp=sum(g==c and p==c for g,p in zip(gold,pred));fp=sum(g!=c and p==c for g,p in zip(gold,pred));fn=sum(g==c and p!=c for g,p in zip(gold,pred))
  details[c]={'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0,'support':sum(g==c for g in gold),'tp':tp,'fp':fp,'fn':fn}
 return {'macro_f1':sum(x['f1'] for x in details.values())/3,'accuracy':sum(g==p for g,p in zip(gold,pred))/len(gold) if gold else None,'n':len(gold),'class_metrics':details,'confusion':{g:{p:sum(a==g and b==p for a,b in zip(gold,pred)) for p in ['T','F','U','INVALID']} for g in ['T','F','U']}}

def main(root):
 labels=read(root/'labels.jsonl');lb={x['sample_id']:x for x in labels};pred=read(root/'model/predictions.jsonl');pb={x['sample_id']:x for x in pred};pairs=read(root/'pairs.jsonl')
 assert len(lb)==len(pb)==150 and set(lb)==set(pb)
 out={'status':'executed','evaluation_kind':'real Qwen3-8B inference on controlled source-derived synthetic-vignette excerpts; not clinical gold evaluation','methods':{}}
 methods=['direct','structured','oracle_rule_ablation']+(['structured_normalized'] if 'structured_normalized' in pred[0] else [])
 for method in methods:
  m=metric([x['label'] for x in labels],[pb[x['sample_id']][method]['label'] for x in labels])
  evidence_eligible=[x for x in labels if x['label']!='U']
  hit=lambda x: set(pb[x['sample_id']][method]['evidence_sentence_ids'] or [])==set(x['evidence_sentence_ids'])
  m['evidence_exact_sentence_accuracy_known']={'correct':sum(hit(x) for x in evidence_eligible),'n':len(evidence_eligible),'accuracy':sum(hit(x) for x in evidence_eligible)/len(evidence_eligible)}
  m['evidence_exact_sentence_accuracy_all']=sum(hit(x) for x in labels)/len(labels)
  m['joint_label_and_evidence_accuracy_known']=sum(hit(x) and pb[x['sample_id']][method]['label']==x['label'] for x in evidence_eligible)/len(evidence_eligible)
  for key,ps in [('all_pairs',pairs),('label_changing_pairs',[p for p in pairs if p['expected_label_change']]),('invariant_pairs',[p for p in pairs if not p['expected_label_change']])]:
   correct=sum(all(pb[p[k]][method]['label']==lb[p[k]]['label'] for k in ['original_id','counterfactual_id']) for p in ps)
   m[key]={'correct':correct,'n':len(ps),'accuracy':correct/len(ps) if ps else None}
  m['invalid_count']=sum(not pb[x['sample_id']][method]['valid'] for x in labels)
  m['by_variant']={v:metric([x['label'] for x in labels if x['variant']==v],[pb[x['sample_id']][method]['label'] for x in labels if x['variant']==v]) for v in ['original','counterfactual','unknown']}
  stage='direct' if method=='direct' else 'fact_extraction'
  timing=json.loads((root/f'model/{stage}_timing.json').read_text());total=sum(t['elapsed_seconds'] for t in timing)
  extra=sum(t['elapsed_seconds'] for t in json.loads((root/'model/rule_extraction_timing.json').read_text())) if method in ['structured','structured_normalized'] else 0
  m['timing']={'batch_inference_seconds':total,'one_time_rule_extraction_seconds':extra,'total_including_rule_extraction_seconds':total+extra,'amortized_seconds_per_sample':(total+extra)/150,'note':'CUDA synchronized generation incl. prefill/decode; excludes tokenization, model load and IO; batched throughput, not single request latency'}
  if method=='structured_normalized':m['status']='post_hoc_exact_field_name_mapping_on_same_test_set_not_independent_validation'
  out['methods'][method]=m
 rules=read(root/'private/rules.jsonl');ex=read(root/'model/rule_extraction_raw.jsonl')
 canon=lambda s:json.dumps(s,sort_keys=True)
 out['rule_schema_exact_match']={'correct':sum(canon(r['schema_gold'])==canon(e['parsed']) for r,e in zip(rules,ex)),'n':len(rules)}
 failures=[]
 for x in labels:
  p=pb[x['sample_id']]
  if any(p[m]['label']!=x['label'] for m in methods):failures.append({'sample_id':x['sample_id'],'rule_id':x['rule_id'],'gold':x['label'],'variant':x['variant'],'source_row':x['source_row'],**{m:p[m]['label'] for m in methods}})
 (root/'metrics.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(root/'errors.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in failures))
 print(json.dumps({'methods':{k:{q:v[q] for q in ['macro_f1','accuracy','all_pairs','label_changing_pairs','timing']} for k,v in out['methods'].items()},'rule_schema_exact_match':out['rule_schema_exact_match']}))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('results'));main(p.parse_args().data)
