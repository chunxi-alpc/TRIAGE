已完成真实服务器推理。先看REPORT.zh.txt；复现见REPRODUCE.zh.txt。结果在results/。MedGUIDE原文仅在服务器results/private/保留，不随包分发。
