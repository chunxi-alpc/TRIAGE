import unittest
from logic import k_all,k_any,k_not,evaluate
class LogicTests(unittest.TestCase):
 def test_kleene_truth_tables(self):
  cases=[('T','T','T','T'),('T','F','F','T'),('T','U','U','T'),('F','T','F','T'),('F','F','F','F'),('F','U','F','U'),('U','T','U','T'),('U','F','F','U'),('U','U','U','U')]
  for a,b,and_gold,or_gold in cases:
   self.assertEqual(k_all([a,b]),and_gold);self.assertEqual(k_any([a,b]),or_gold)
  self.assertEqual([k_not(v) for v in ['T','F','U']],['F','T','U'])
 def test_boundaries_unknown_and_exception(self):
  for op,expected in [('lt','F'),('le','T'),('gt','F'),('ge','T')]:
   r={'mode':'all','conditions':[{'field':'x','op':op,'value':6}],'exceptions':[]}
   self.assertEqual(evaluate(r,{'x':6}),expected);self.assertEqual(evaluate(r,{'x':None}),'U')
  r={'mode':'all','conditions':[{'field':'x','op':'ge','value':6}],'exceptions':[{'field':'y','op':'eq','value':'positive'}]}
  self.assertEqual(evaluate(r,{'x':7,'y':'positive'}),'F')
  self.assertEqual(evaluate(r,{'x':7,'y':None}),'U')
  self.assertEqual(evaluate(r,{'x':5,'y':None}),'F')
if __name__=='__main__':unittest.main()
