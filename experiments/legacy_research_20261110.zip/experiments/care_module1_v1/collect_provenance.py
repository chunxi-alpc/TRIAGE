"""Record exact local model weights, package versions, and reference URLs on server."""
import hashlib,importlib.metadata,json,pathlib,subprocess,sys,time,urllib.request
model=pathlib.Path(sys.argv[1]);root=pathlib.Path(sys.argv[2]);root.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(8*1024*1024):h.update(b)
 return h.hexdigest()
files=sorted(model.glob('*.safetensors'))+sorted(model.glob('*.json'))
manifest={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in files}
(root/'model_files.json').write_text(json.dumps(manifest,indent=2)+'\n')
versions={}
for name in ['torch','transformers','pandas','pyarrow','datasets','safetensors','accelerate','numpy','tokenizers']:
 try:versions[name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError:versions[name]=None
(root/'package_versions.json').write_text(json.dumps(versions,indent=2)+'\n')
sources=[('MedGUIDE','https://huggingface.co/datasets/MedGUIDE/MedGUIDE-MCQA-8K','1460ec478280a7295040b92f7eb985327f77dcbe'),('MedGUIDE paper','https://arxiv.org/abs/2505.11613',None),('TrialGPT matching','https://raw.githubusercontent.com/ncbi-nlp/TrialGPT/main/trialgpt_matching/TrialGPT.py',None),('Qwen3-8B','https://huggingface.co/Qwen/Qwen3-8B',None)]
refs=[]
for name,url,revision in sources:
 r={'name':name,'url':url,'revision':revision,'checked_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 try:
  with urllib.request.urlopen(url,timeout=15) as response: data=response.read();r.update({'http_status':response.status,'content_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 except Exception as e:r['access_error']=str(e)
 refs.append(r)
(root/'sources.json').write_text(json.dumps(refs,indent=2)+'\n')
print('PROVENANCE_COMPLETE')
