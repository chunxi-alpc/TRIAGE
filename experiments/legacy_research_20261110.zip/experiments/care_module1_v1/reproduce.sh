#!/usr/bin/env bash
set -euo pipefail
# Execute ONLY on gcx@10.29.128.115. No inference should run on the client computer.
source /home/gcx/gcx261014/bin/activate
cd "$(dirname "$0")"
result_dir="${1:-results_reproduction}"
if [ -e "$result_dir" ]; then
  echo 'Choose a fresh results directory to preserve the previous run.' >&2
  exit 1
fi
python build_data.py --source /home/gcx/TRIAGE/data/MedGUIDE --out "$result_dir"
python -m unittest test_logic
# Before starting, report GPU 0, approx. 24-36 GB VRAM, 30 rules / 150 samples,
# approx. 10-20 minutes (estimate; actual recorded run can be faster).
export CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=4 TOKENIZERS_PARALLELISM=false
python -u run_model.py --model /home/gcx/n/models/Qwen3-8B --data "$result_dir" --batch 8
python evaluate.py --data "$result_dir"
python normalize_interface.py --data "$result_dir"
python evaluate.py --data "$result_dir"
python collect_provenance.py /home/gcx/n/models/Qwen3-8B "$result_dir/provenance"
