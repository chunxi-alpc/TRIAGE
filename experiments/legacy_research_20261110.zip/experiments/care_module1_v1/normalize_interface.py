"""Post-hoc interface repair. No new inference, threshold change, or gold-label access.

Preserve structured v1 verbatim; add structured_normalized using exact display-name
to canonical-key mapping from the pre-existing field dictionary. Not a held-out result.
"""
import argparse,json,pathlib,time
from build_data import FIELDS
from logic import evaluate,valid_schema
def read(p):return [json.loads(x) for x in p.read_text().splitlines() if x]
def main(root):
 t=time.perf_counter();inverse={v:k for k,v in FIELDS.items()}
 pred=read(root/'model/predictions.jsonl');facts=read(root/'model/fact_extraction_raw.jsonl');rules=read(root/'model/rule_extraction_raw.jsonl');rb={x['id']:x['parsed'] for x in rules};fb={x['id']:x for x in facts};events=[]
 for x in pred:
  raw=fb[x['sample_id']]['parsed'] or {};values=raw.get('facts') or {};ev=raw.get('evidence') or {}
  norm={inverse.get(k,k):v for k,v in values.items()};ne={inverse.get(k,k):v for k,v in ev.items()}
  changed=values!=norm
  if changed:events.append({'sample_id':x['sample_id'],'original_keys':list(values),'normalized_keys':list(norm)})
  valid=isinstance(raw.get('facts'),dict) and isinstance(raw.get('evidence'),dict) and valid_schema(rb.get(x['rule_id']))
  eids=sorted({v for k,vs in ne.items() if norm.get(k) is not None and isinstance(vs,list) for v in vs if isinstance(v,int) and v in [1,2]})
  x['structured_normalized']={'label':evaluate(rb.get(x['rule_id']),norm) if valid else 'INVALID','evidence_sentence_ids':eids,'valid':valid,'amortized_seconds':x['structured']['amortized_seconds']}
 (root/'model/predictions.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in pred))
 (root/'model/normalization.json').write_text(json.dumps({'status':'post_hoc_same_test_set','operation':'exact inverse mapping of existing field descriptions to canonical keys; no clinical inference or label access','elapsed_seconds':time.perf_counter()-t,'affected_samples':events},indent=2)+'\n')
 print(json.dumps({'normalized_samples':len(events)}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('results'));main(p.parse_args().data)
