"""Deterministic numeric/categorical comparison and strong Kleene aggregation."""
import math

def k_not(v): return {'T':'F','F':'T','U':'U'}[v]
def k_all(xs):
 return 'F' if 'F' in xs else ('U' if 'U' in xs else 'T')
def k_any(xs):
 return 'T' if 'T' in xs else ('U' if 'U' in xs else 'F')

def compare(a, facts):
 if not isinstance(a,dict) or a.get('field') not in facts: return 'U'
 v=facts[a['field']]
 if v is None: return 'U'
 t=a.get('value');op=a.get('op')
 if op in ('lt','le','gt','ge'):
  if isinstance(v,bool) or isinstance(t,bool) or not isinstance(v,(int,float)) or not isinstance(t,(int,float)): return 'U'
  if not math.isfinite(v) or not math.isfinite(t): return 'U'
  z={'lt':v<t,'le':v<=t,'gt':v>t,'ge':v>=t}[op]
 elif op=='eq': z=v==t
 else: return 'U'
 return 'T' if z else 'F'

def valid_schema(rule):
 if not isinstance(rule,dict) or rule.get('mode') not in ('all','any'):return False
 cs=rule.get('conditions');es=rule.get('exceptions',[])
 if not isinstance(cs,list) or not cs or not isinstance(es,list):return False
 return all(isinstance(a,dict) and isinstance(a.get('field'),str) and a.get('op') in ['lt','le','gt','ge','eq'] and 'value' in a for a in cs+es)

def evaluate(rule, facts):
 if not valid_schema(rule): return 'U'
 cond=[compare(a,facts) for a in rule['conditions']]
 exc=[compare(a,facts) for a in rule.get('exceptions',[])]
 return k_all([(k_all(cond) if rule['mode']=='all' else k_any(cond)), k_not(k_any(exc))])
