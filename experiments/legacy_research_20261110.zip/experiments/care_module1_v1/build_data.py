"""Build source-derived controlled cases on the server; never infer gold from predictions."""
import argparse, collections, hashlib, json, pathlib, random, re
import pandas as pd

FIELDS = {
 'relapse_months':'Time from treatment completion to relapse, in months',
 'anc':'Absolute neutrophil count, in 10^9/L', 'platelets':'Platelet count, in 10^9/L',
 'age':'Patient age, in years', 'tumor_cm':'Breast tumor diameter, in cm',
 'nodes':'Number of positive axillary lymph nodes', 'psadt':'PSA doubling time, in months',
 'lesion_mm':'Esophageal lesion diameter, in mm', 'esophageal_cm':'Esophageal nodule/mass diameter, in cm',
 'kps':'Karnofsky performance score, percent', 'ecog':'ECOG performance score',
 'lung_mm':'Pulmonary nodule diameter, in mm', 'response_months':'Duration of previous treatment response/remission, in months',
 'pcr':'PCR result, positive or negative', 'margin':'Surgical margin result, positive or negative',
 'her2':'HER2 result, positive or negative'
}

# Curated BEFORE inference. These are projections of real path nodes, NOT full clinical recommendations.
# rule source row, node substring, normalized predicate, gold schema, patient row,
# target sentence selector, exact factual edit(s), original label, counterfactual label.
def atom(field, op, value): return {'field':field,'op':op,'value':value}
def schema(*atoms, mode='all'): return {'mode':mode,'conditions':list(atoms),'exceptions':[]}
SPECS = [
 (0,'Early relapse','Relapse occurred less than 6 months after treatment.',schema(atom('relapse_months','lt',6)),0,'early relapse, approximately',[['early relapse, approximately 4 months','relapse, approximately 6 months']],'T','F'),
 (10,'Late relapse','Relapse occurred at least 6 months after treatment.',schema(atom('relapse_months','ge',6)),1,'first relapse 5 months',[['5 months','6 months']],'F','T'),
 (30,'Delay cycle 2','Absolute neutrophil count is greater than 0.5 x 10^9/L.',schema(atom('anc','gt',0.5)),30,'ANC reached',[['ANC reached 0.4','ANC reached 0.6']],'F','T'),
 (30,'Delay cycle 2','Platelet count is greater than 50 x 10^9/L.',schema(atom('platelets','gt',50)),30,'platelets improved',[['platelets improved to 45','platelets improved to 51']],'F','T'),
 (60,'Consider omitting','Patient age is at least 70 years.',schema(atom('age','ge',70)),60,'72-year-old',[['72-year-old','69-year-old']],'T','F'),
 (61,'Consider omitting','Patient age is at least 65 years.',schema(atom('age','ge',65)),61,'68-year-old',[['68-year-old','64-year-old']],'T','F'),
 (60,'Consider omitting','Breast tumor diameter is at most 2 cm.',schema(atom('tumor_cm','le',2)),60,'1.5 cm invasive',[['1.5 cm','2.1 cm'],['classified as pT1, ','']],'T','F'),
 (61,'Consider omitting','Breast tumor diameter is at most 3 cm.',schema(atom('tumor_cm','le',3)),61,'tumor measures',[['2.5 cm','3.1 cm']],'T','F'),
 (68,'1–3 positive axillary','There are 1 to 3 positive axillary lymph nodes, inclusive.',schema(atom('nodes','ge',1),atom('nodes','le',3)),68,'2 positive axillary',[['2 positive axillary','4 positive axillary']],'T','F'),
 (64,'pN2–3','There are at least 4 positive axillary lymph nodes.',schema(atom('nodes','ge',4)),64,'5 positive axillary',[['pN2 disease with 5','disease with 3']],'T','F'),
 (66,'Negative axillary','Breast tumor diameter is at most 5 cm.',schema(atom('tumor_cm','le',5)),66,'pT2 tumor measuring',[['pT2 tumor measuring 4.5','tumor measuring 5.1']],'T','F'),
 (67,'Negative axillary','Breast tumor diameter is greater than 5 cm.',schema(atom('tumor_cm','gt',5)),67,'a 6 cm tumor',[['a 6 cm','a 5 cm'],[', classified as pT3','']],'T','F'),
 (193,'PSADT >10','PSA doubling time is greater than 10 months.',schema(atom('psadt','gt',10)),196,'doubling time of 8',[['8 months','11 months']],'F','T'),
 (196,'PSADT ≤10','PSA doubling time is at most 10 months.',schema(atom('psadt','le',10)),196,'doubling time of 8',[['8 months','11 months']],'T','F'),
 (134,'Lesion size <15','Esophageal lesion diameter is less than 15 mm.',schema(atom('lesion_mm','lt',15)),134,'12 mm in diameter',[['12 mm','15 mm']],'T','F'),
 (135,'Lesion size ≥15','Esophageal lesion diameter is at least 15 mm.',schema(atom('lesion_mm','ge',15)),135,'revealed a 20 mm lesion',[['20 mm','14 mm']],'T','F'),
 (126,'Nodule/mass size <','Esophageal nodule or mass diameter is less than 2 cm.',schema(atom('esophageal_cm','lt',2)),126,'a 1.5 cm visible lesion',[['1.5 cm','2 cm']],'T','F'),
 (128,'Nodule/mass size ≥','Esophageal nodule or mass diameter is at least 2 cm.',schema(atom('esophageal_cm','ge',2)),128,'approximately 2.5 cm',[['2.5 cm','1.9 cm']],'T','F'),
 (137,'Karnofsky performance','Karnofsky performance score is at least 60 percent OR ECOG performance score is at most 2.',schema(atom('kps','ge',60),atom('ecog','le',2),mode='any'),138,'Karnofsky performance score of 50',[['score of 50%','score of 60%']],'F','T'),
 (138,'Karnofsky performance','Karnofsky performance score is less than 60 percent OR ECOG performance score is at least 3.',schema(atom('kps','lt',60),atom('ecog','ge',3),mode='any'),138,'Karnofsky performance score of 50',[['score of 50%','score of 60%'],['scores 4 on the ECOG','scores 2 on the ECOG']],'T','F'),
 (163,'>8 mm','Pulmonary nodule diameter is greater than 8 mm.',schema(atom('lung_mm','gt',8)),163,'nodule measuring 1.2 cm',[['1.2 cm','0.8 cm']],'T','F'),
 (168,'≥6 mm','Pulmonary nodule diameter is at least 6 mm.',schema(atom('lung_mm','ge',6)),168,'nodule measuring 7 mm',[['7 mm','5 mm']],'T','F'),
 (1000,'<6 mm','Pulmonary nodule diameter is less than 6 mm.',schema(atom('lung_mm','lt',6)),1000,'lobe measuring 5 mm',[['5 mm','6 mm']],'T','F'),
 (104,'Previous response','Previous treatment response or remission lasted at least 12 months.',schema(atom('response_months','ge',12)),104,'remission that lasted for 14',[['14 months','11 months']],'T','F'),
 (105,'No response or short','Previous treatment response lasted less than 12 months.',schema(atom('response_months','lt',12)),105,'brief response lasting only eight',[['brief response lasting only eight','response lasting twelve'],['approximately nine months','approximately fourteen months']],'T','F'),
 (0,'PCR negative','PCR result is negative.',schema(atom('pcr','eq','negative')),0,'negative PCR levels',[['negative PCR','positive PCR']],'T','F'),
 (2,'PCR positive','PCR result is positive.',schema(atom('pcr','eq','positive')),2,'returned positive for PCR',[['positive for PCR','negative for PCR'],[', indicating residual disease despite the clinical response','']],'T','F'),
 (49,'Negative margins','Surgical margins are negative.',schema(atom('margin','eq','negative')),49,'pathology confirmed negative surgical margins',[['negative surgical margins','positive surgical margins']],'T','F'),
 (37,'Positive margin','Surgical margin is positive.',schema(atom('margin','eq','positive')),37,'Pathology reveals a positive surgical margin',[['positive surgical margin','negative surgical margin']],'T','F'),
 (61,'Consider omitting','HER2 result is negative.',schema(atom('her2','eq','negative')),61,'tumor measures',[['HER2-negative','HER2-positive']],'T','F'),
]

def dump(path, obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def sha(b): return hashlib.sha256(b).hexdigest()
def sentences(text): return re.split(r'(?<=[.!?])\s+(?=[A-Z])',text)

def build(source, out):
 out.mkdir(parents=True,exist_ok=True)
 private=out/'private'; private.mkdir(exist_ok=True)
 df=pd.read_parquet(source/'data/train-00000-of-00001.parquet')
 rows=[];rules=[];labels=[];pairs=[];rng=random.Random(20261017)
 # 50 case-rule anchors, including 20 additional opposing-polarity rules on existing excerpts.
 anchors=[(i,i,False) for i in range(30)]
 # Additional anchors use an independently specified opposite rule, keeping the same evidence.
 opposite={0:1,1:0,4:5,5:4,6:7,7:6,8:9,9:8,10:11,11:10,12:13,13:12,14:15,15:14,16:17,17:16,20:21,21:22,25:26,26:25}
 for i,j in opposite.items(): anchors.append((j,i,True))
 # Explicit labels for extra anchors, reviewed from factual values; never computed by the evaluated engine.
 extra_gold={0:('F','T'),1:('T','F'),4:('T','T'),5:('F','F'),6:('T','T'),7:('F','F'),8:('F','T'),9:('F','T'),10:('F','T'),11:('F','T'),12:('T','F'),13:('F','T'),14:('F','T'),15:('F','T'),16:('F','T'),17:('F','T'),20:('T','T'),21:('F','T'),25:('F','T'),26:('F','T')}
 # Drop extras that do not flip; replace with same evidence under another strict threshold already defined.
 # Exactly 50 pairs still include all fixed 30 canonical flips; nonflips are explicitly marked.
 for i,s in enumerate(SPECS):
  sr,node_key,text,gold,pr,selector,edits,b,c=s
  matches=[(k,n) for k,n in enumerate(df.iloc[sr]['path']) if node_key in n]
  assert len(matches)==1,(i,matches)
  ni,node=matches[0]
  rules.append({'rule_id':f'R{i+1:02}','text':text,'schema_gold':gold,'source_row':sr,'source_node_index':ni,'source_node_sha256':sha(node.encode()),'scope':'atomic_projection' if i not in [18,19] else 'compound_condition'})
 for ai,(ri,si,is_extra) in enumerate(anchors):
  sr,nk,rt,gs,pr,selector,edits,basegold,flipgold=SPECS[si]
  full=df.iloc[pr]['profile']; ss=sentences(full)
  target=[s for s in ss if selector.lower() in s.lower()]
  assert len(target)==1,(si,target)
  target=target[0]; edited=target
  for old,new in edits:
   assert old in edited,(si,old)
   edited=edited.replace(old,new)
  if is_extra: basegold,flipgold=extra_gold[si]
  # Distractor is a genuine source sentence about cytogenetics/history/general care.
  blocked=r'year.old|\b(?:age|month|cm|mm|ANC|platelet|tumor|nodule|lesion|nodes|node|PCR|HER2|margin|Karnofsky|ECOG|doubling|response|remission|relapse|positive|negative)\b|\?'
  context=next((s for s in ss if s!=target and not re.search(blocked,s,re.I)),None)
  context=context or 'This record is a research excerpt.'
  order=rng.sample([0,1],2);aid=f'A{ai+1:02}';ids=[]
  for variant,text,label in [('original',target,basegold),('counterfactual',edited,flipgold),('unknown','The relevant measurements and test results are not documented in this excerpt.','U')]:
   sid=f'{aid}_{variant}';ids.append(sid);parts=[context,text];parts=[parts[k] for k in order]
   evidence=[] if variant=='unknown' else [order.index(1)+1]
   rows.append({'sample_id':sid,'anchor_id':aid,'rule_id':f'R{ri+1:02}','sentences':parts})
   labels.append({'sample_id':sid,'anchor_id':aid,'rule_id':f'R{ri+1:02}','label':label,'evidence_sentence_ids':evidence,'variant':variant,'source_row':pr,'source_profile_sha256':sha(full.encode()),'source_target_start':full.index(target),'source_target_end':full.index(target)+len(target),'source_target_sha256':sha(target.encode()),'edits':edits if variant=='counterfactual' else [],'annotation_method':'pre-inference curated literal predicate; counterfactual intervention or evidence removal; no physician review'})
  pairs.append({'pair_id':aid,'original_id':ids[0],'counterfactual_id':ids[1],'expected_label_change':basegold!=flipgold,'edited_rule_id':f'R{ri+1:02}'})
 assert len(rows)==150 and len(rules)==30 and len(pairs)==50
 for path,data in [(private/'inputs.jsonl',rows),(private/'rules.jsonl',rules),(out/'labels.jsonl',labels),(out/'pairs.jsonl',pairs)]:
  path.write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in data))
 # Public rule manifest contains no MedGUIDE path text or clinical vignette.
 (out/'rules_manifest.jsonl').write_text(''.join(json.dumps({k:v for k,v in r.items() if k!='text'},ensure_ascii=False)+'\n' for r in rules))
 audit={'source':'MedGUIDE/MedGUIDE-MCQA-8K','revision':'1460ec478280a7295040b92f7eb985327f77dcbe','source_rows':len(df),'source_columns':list(df),'disease_keys':int(df.disease.nunique()),'unique_path_nodes':len(set(n for p in df.path for n in p)),'missing_profiles':int(df.profile.isna().sum()),'duplicate_profiles':int(df.profile.duplicated().sum()),'parquet_sha256':sha((source/'data/train-00000-of-00001.parquet').read_bytes()),'card_sha256':sha((source/'README.md').read_bytes()),'license':'TBD. Intended for academic and research use.','source_is_synthetic':True,'native_applicability_labels':False,'native_evidence_labels':False,'rules':30,'case_rule_anchors':50,'unique_source_cases':len(set(x['source_row'] for x in labels)),'samples':150,'label_counts':dict(collections.Counter(x['label'] for x in labels)),'counterfactual_pairs':len(pairs),'label_changing_pairs':sum(p['expected_label_change'] for p in pairs),'seed':20261017,'case_form':'one source evidence sentence plus one source distractor when available; randomized sentence position','gold_limit':'construction-derived engineering labels, not independent clinical gold','unimplemented':['clinical NLI','confidence calibration','MedCPT relevance','action/exception extraction','full guideline applicability','clinical expert annotation'],'observed_issues':[{'source_row':137,'issue':'disease key is eso16, profile explicitly describes pancreatic adenocarcinoma'},{'source_row':271,'issue':'disease key is vulvar_4, profile describes melanoma on the arm'},{'source_row':188,'issue':'path requires <6 months, but profile reports six months; excluded from evaluation'},{'source_row':65,'issue':'path contains margin >=1 mm; profile gives negative margins without width; that predicate was not used'}]}
 dump(out/'dataset_audit.json',audit)
 dump(out/'frozen_data_hashes.json',{str(p.relative_to(out)):sha(p.read_bytes()) for p in [out/'labels.jsonl',out/'pairs.jsonl',out/'rules_manifest.jsonl',private/'inputs.jsonl',private/'rules.jsonl']})
 print(json.dumps({k:audit[k] for k in ['samples','rules','unique_source_cases','label_counts','label_changing_pairs']}))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,default=pathlib.Path('results'));a=p.parse_args();build(a.source,a.out)
