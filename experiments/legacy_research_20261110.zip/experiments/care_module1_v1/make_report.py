"""Render a Chinese report from measured results; package without source text."""
import hashlib,json,pathlib,sys,zipfile
root=pathlib.Path(__file__).resolve().parent;p=root/'results'
m=json.loads((p/'metrics.json').read_text());a=json.loads((p/'dataset_audit.json').read_text());e=json.loads((p/'model/environment.json').read_text());n=json.loads((p/'model/normalization.json').read_text())
names={'direct':'直接判定','structured':'初版结构化','structured_normalized':'字段名修正后（事后分析）'}
lines=[]
for key,name in names.items():
 x=m['methods'][key];v=x['label_changing_pairs'];ek=x['evidence_exact_sentence_accuracy_known'];ta=x['timing']
 lines.append(f"{name}：宏平均F1={x['macro_f1']:.4f}；准确率={x['accuracy']:.2%}；有证据样本的定位准确率={ek['accuracy']:.2%}；45对标签变化病例的成对准确率={v['correct']}/{v['n']}（{v['accuracy']:.2%}）；推理耗时={ta['total_including_rule_extraction_seconds']:.2f}秒。")
text=f'''CARE 模块一：小规模可复现验证报告
日期：2026年10月17日（北京时间）

结论
已在指定服务器真实运行Qwen3-8B，交付代码、固定标签、逐样本原始回答、指标、数据审计和复现说明。
本次未证明结构化方案总体优于直接判定。字段名修正后，数值反事实判断更稳定，但缺失信息抽取仍有错误；该修正使用了同一测试集，不能视为独立验证。

实际设置
服务器：gcx@10.29.128.115；目录：/home/gcx/care_module1_20261017。
GPU：仅0号A100 80GB；BF16；batch=8；greedy；关闭thinking；seed=20261017；无训练和外部推理API。
框架记录峰值预留显存：{e['peak_reserved_gib']:.2f} GiB；模型加载：{e['model_load_seconds']:.2f}秒。模型阶段从北京时间21:55:50至21:56:31；三阶段生成累计40.74秒。预计时间原报10–20分钟，实际短片段推理更快。结束后GPU已释放。
数据源：MedGUIDE固定快照1460ec478280a7295040b92f7eb985327f77dcbe，本地实际读取{a['source_rows']}行，{a['disease_keys']}个disease键。
从真实数据文件中取23个原始合成病例，建立50个病例—条件组合；每组含原始片段、反事实片段、缺失证据片段，共150条，T/F/U分别为51/49/50。
30条条件是从路径节点人工规范化的条件片段：28条单字段条件（含一个范围），2条OR复合条件。不是30条完整诊疗规则。
50对原始/反事实片段中，45对应翻转标签，5对应保持标签。部分编辑同时清理冗余分期或相关时间，不能把每对都称为严格单原子最小编辑。
每例通常只有一个证据句和一个原文干扰句；缺失样本将证据句换成未记录说明。短片段和明确缺失提示明显降低了任务难度。

标签与评估性质
MedGUIDE原生是选择题，没有本任务的适用性或证据金标准。新增标签由预先整理的明确事实、条件阈值和编辑操作确定，存有来源行号、字符位置、哈希及编辑记录；没有用被评模型产生标签，也没有医生独立复核。
这是真实模型运行的受控工程评估，使用的是数据集中的合成病例，不是真实患者临床评估。23个源病例跨规则复用，150条不是150个独立病例。
标签和输入在推理前固定并校验哈希。两法接收同一份人工规范化规则；结构化法由Qwen提取条件结构，再按该结构提取事实，最后确定性比较和强三值逻辑聚合。
参考TrialGPT-Matching的逐条件处理、句子编号和结构化回答方式；未复现其原提示、模型、训练或原论文指标。对缺失证据统一采用未知语义。

实际结果
{chr(10).join(lines)}
初版参考规则消融F1={m['methods']['oracle_rule_ablation']['macro_f1']:.4f}，与初版结构化相同。
30条规则结构精确匹配28条；其余2条是单条件的all/any形式差异，本实验中逻辑等价。
初版字段错误：12条模型回答使用字段描述而非字段ID，其中8条有证据样本因此被当成未知。事后修正只按原有字段词典精确转换名称，未重新推理、未修改阈值或标签；原始输出及初版结果完整保留。修正处理耗时{n['elapsed_seconds']:.4f}秒。
修正后仍有6个未知样本被抽取为阴性，导致错误适用/不适用判断；因此宏F1仍低于直接法。直接法出现数值边界错误，且一个PCR阴性病例被误判。
全部50对的成对准确率：直接法47/50，初版结构化46/50，字段名修正后50/50。成对指标只覆盖原始/反事实，不覆盖额外的50条未知样本。
有证据的100条定位均为100%，但任务只有两句，不能据此声称长病历定位可靠。把未知样本的空证据要求也计入，直接法为{m['methods']['direct']['evidence_exact_sentence_accuracy_all']:.2%}，初版结构化为{m['methods']['structured']['evidence_exact_sentence_accuracy_all']:.2%}；直接法常引用“未记录”说明句，而非输出空列表。
耗时为CUDA同步后的批量生成累计，含prefill/decode；不含模型加载、分词、文件读取和后处理，不能当成单请求延迟。结构化包含6.47秒的一次性规则提取，事实提取24.14秒；直接法10.13秒。

数据审计与限制
已直接核实：row137的疾病键为eso16但病例描述胰腺癌；row271的疾病键为vulvar_4但病例描述手臂黑色素瘤；row188路径要求小于6个月但病例写6个月，该行未参与评估；row65没有切缘宽度，因此未把路径中的宽度条件当成已知事实。
这些是明确实例，未据此估计全库错误率。MedGUIDE可以支持条件片段验证，但不能直接提供本任务的三值金标准。
尚未执行：医学NLI、置信度校准、MedCPT相关性、动作/例外提取、完整指南适用性和长病例证据定位。例外逻辑仅做了单元测试。
没有训练集/独立测试集分离，没有多随机种子重复，没有独立医学标注，也未对相关样本做统计显著性推断。

后续建议
先固定字段接口并约束缺失信息抽取，再用未参与本次分析的新病例进行盲测；由独立标注者核对完整条件、上下文和证据，纳入AND/OR混合缺失、否定、例外及单位边界。通过这些验证后再接入CARE后续模块。

交付与许可证
服务器保留本次完整输入：results/private/；交付包提供索引、标签、重建脚本和模型原始JSON回答。
MedGUIDE数据卡的许可证仍为TBD，故包内不直接分发病例原文、路径原文、parquet或模型权重。使用来源数据的授权仍需自行确认。
运行方法和文件索引见REPRODUCE.zh.txt；所有实验执行均在服务器，客户端只编辑和收取文件。

来源
MedGUIDE数据：https://huggingface.co/datasets/MedGUIDE/MedGUIDE-MCQA-8K
MedGUIDE论文：https://arxiv.org/abs/2505.11613
TrialGPT-Matching：https://github.com/ncbi-nlp/TrialGPT/blob/main/trialgpt_matching/TrialGPT.py
Qwen3-8B：https://huggingface.co/Qwen/Qwen3-8B
'''
(root/'REPORT.zh.txt').write_text(text)
(root/'README.txt').write_text('已完成真实服务器推理。先看REPORT.zh.txt；复现见REPRODUCE.zh.txt。结果在results/。MedGUIDE原文仅在服务器results/private/保留，不随包分发。\n')
manifest={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file() and 'private' not in f.parts and '__pycache__' not in f.parts and f.name not in ['SHA256SUMS.json','care_module1.zip','run.pid']}
(root/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
dest=root/'care_module1.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(root.rglob('*')):
  if f.is_file() and 'private' not in f.parts and '__pycache__' not in f.parts and f.name not in ['care_module1.zip','run.pid']:z.write(f,str(f.relative_to(root)))
print(json.dumps({'report':'REPORT.zh.txt','archive_bytes':dest.stat().st_size}))
