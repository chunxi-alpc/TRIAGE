"""Offline Qwen3-8B inference on the specified server. No labels enter prompts."""
import argparse, hashlib, json, os, pathlib, platform, random, subprocess, time
from build_data import FIELDS
from logic import evaluate,valid_schema

def read(p):return [json.loads(x) for x in p.read_text().splitlines() if x]
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def json_parse(s):
 try:return json.loads(s)
 except Exception:
  a=s.find('{');b=s.rfind('}')
  if a>=0 and b>a:
   try:return json.loads(s[a:b+1])
   except Exception:pass
 return None

def main(a):
 import torch, transformers
 from transformers import AutoTokenizer,AutoModelForCausalLM
 root=a.data; out=root/'model';out.mkdir(exist_ok=True)
 frozen=json.loads((root/'frozen_data_hashes.json').read_text())
 for rel,digest in frozen.items(): assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
 inputs=read(root/'private/inputs.jsonl');rules=read(root/'private/rules.jsonl')
 rng=random.Random(20261017);torch.manual_seed(20261017)
 tokenizer=AutoTokenizer.from_pretrained(a.model,local_files_only=True,padding_side='left')
 if tokenizer.pad_token_id is None:tokenizer.pad_token_id=tokenizer.eos_token_id
 t=time.perf_counter()
 model=AutoModelForCausalLM.from_pretrained(a.model,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda:0').eval()
 load=time.perf_counter()-t
 env={'python':platform.python_version(),'torch':torch.__version__,'transformers':transformers.__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'model_path':str(a.model),'model_config_sha256':hashlib.sha256((a.model/'config.json').read_bytes()).hexdigest(),'tokenizer_sha256':hashlib.sha256((a.model/'tokenizer.json').read_bytes()).hexdigest(),'model_index_sha256':hashlib.sha256((a.model/'model.safetensors.index.json').read_bytes()).hexdigest(),'generation':{'do_sample':False,'enable_thinking':False,'batch_size':a.batch,'seed':20261017},'model_load_seconds':load,'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'hardware_nvidia_smi':subprocess.check_output(['nvidia-smi','--query-gpu=index,name,memory.total,memory.used','--format=csv,noheader'],text=True)}
 write(out/'environment.json',env)
 common='You are performing a research benchmark on clinical rule predicates. Use ONLY explicitly reported evidence. Do not infer absent facts from treatment choices or staging codes. Missing facts are unknown. Return one JSON object without explanation.'
 fields=json.dumps(FIELDS)
 rule_prompt='Extract the rule into this exact JSON schema: {"mode":"all" or "any", "conditions":[{"field":FIELD,"op":"lt|le|gt|ge|eq","value":number or "positive" or "negative"}],"exceptions":[]}. Use only FIELD names from '+fields+'. Convert units to these canonical units. Use all for AND, any for OR. Inclusive bounds use le/ge. Return only the object. Rule: '
 def generate(jobs,stage,max_new):
  dest=out/(stage+'_raw.jsonl');records=[];timings=[]
  # Resume only from exact same frozen data, model and generation configuration.
  for start in range(0,len(jobs),a.batch):
   batch=jobs[start:start+a.batch]
   texts=[tokenizer.apply_chat_template([{'role':'system','content':common},{'role':'user','content':j['prompt']}],tokenize=False,add_generation_prompt=True,enable_thinking=False) for j in batch]
   enc=tokenizer(texts,padding=True,return_tensors='pt').to('cuda:0')
   torch.cuda.synchronize();t=time.perf_counter()
   with torch.inference_mode():
    seq=model.generate(**enc,max_new_tokens=max_new,do_sample=False,pad_token_id=tokenizer.pad_token_id,eos_token_id=tokenizer.eos_token_id)
   torch.cuda.synchronize();elapsed=time.perf_counter()-t
   timing={'batch_start':start,'batch_size':len(batch),'elapsed_seconds':elapsed,'max_new_tokens':max_new,'input_padded_tokens':int(enc.input_ids.shape[1]),'generated_padded_tokens':int(seq.shape[1]-enc.input_ids.shape[1])};timings.append(timing)
   with dest.open('a') as f:
    for job,ids in zip(batch,seq):
     raw=tokenizer.decode(ids[enc.input_ids.shape[1]:],skip_special_tokens=True)
     parsed=json_parse(raw)
     rec={'id':job['id'],'raw_output':raw,'parsed':parsed,'parse_valid':isinstance(parsed,dict),'batch_start':start,'batch_seconds':elapsed,'amortized_seconds':elapsed/len(batch),'prompt_sha256':hashlib.sha256(texts[batch.index(job)].encode()).hexdigest()}
     f.write(json.dumps(rec,ensure_ascii=False)+'\n');records.append(rec)
   print(json.dumps({'stage':stage,'completed':start+len(batch),'total':len(jobs),'batch_seconds':round(elapsed,2)}),flush=True)
  write(out/(stage+'_timing.json'),timings);return records
 # Refuse accidental appends into an old evaluation run.
 if any(out.glob('*_raw.jsonl')):raise RuntimeError('Output contains a previous run; use a fresh data/output directory.')
 rule_by={r['rule_id']:r for r in rules}
 rs=generate([{'id':r['rule_id'],'prompt':rule_prompt+r['text']} for r in rules],'rule_extraction',256)
 extracted_rules={r['id']:r['parsed'] for r in rs}
 jobs=[]
 for x in inputs:
  r=rule_by[x['rule_id']]
  # Field selection uses the MODEL-extracted rule only, never the reference schema.
  er=extracted_rules.get(x['rule_id']) or {}
  atoms=(er.get('conditions') or [])+(er.get('exceptions') or [])
  keys=sorted({c.get('field') for c in atoms if isinstance(c,dict) and c.get('field') in FIELDS})
  text='\n'.join(f'[{i+1}] {s}' for i,s in enumerate(x['sentences']))
  prompt='Extract the patient facts for these fields: '+json.dumps({k:FIELDS[k] for k in keys})+'. Use canonical units; 1 cm = 10 mm. Report a number, "positive", "negative", or null if not explicitly known. Return {"facts":{FIELD:value},"evidence":{FIELD:[sentence IDs]}}. For null use an empty evidence list. Include no thresholds or applicability labels.\nCase:\n'+text
  jobs.append({'id':x['sample_id'],'prompt':prompt})
 fs=generate(jobs,'fact_extraction',192)
 jobs=[]
 for x in inputs:
  r=rule_by[x['rule_id']];text='\n'.join(f'[{i+1}] {s}' for i,s in enumerate(x['sentences']))
  jobs.append({'id':x['sample_id'],'prompt':'Decide whether the following condition is satisfied. T = satisfied, F = contradicted, U = insufficient information. Use strong three-valued logic: false AND unknown is false; true OR unknown is true. Report {"label":"T|F|U","evidence_sentence_ids":[IDs]}. Cite the sentence(s) establishing the result, and [] if unknown. Convert units when necessary.\nRule: '+r['text']+'\nCase:\n'+text})
 ds=generate(jobs,'direct',96)
 fact_by={x['id']:x for x in fs};direct_by={x['id']:x for x in ds}
 preds=[]
 for x in inputs:
  sid=x['sample_id'];rid=x['rule_id'];r=rule_by[rid];fr=fact_by[sid];p=fr['parsed'] or {};facts=p.get('facts',{})
  if not isinstance(facts,dict):facts={}
  ev=p.get('evidence',{});ev=ev if isinstance(ev,dict) else {}
  eids=sorted({v for k,vals in ev.items() if facts.get(k) is not None and isinstance(vals,list) for v in vals if isinstance(v,int) and 1<=v<=len(x['sentences'])})
  dr=direct_by[sid];dp=dr['parsed'] or {};dl=dp.get('label');de=dp.get('evidence_sentence_ids',[])
  fv=fr['parse_valid'] and isinstance(p.get('facts'),dict) and isinstance(p.get('evidence'),dict)
  sv=fv and valid_schema(extracted_rules.get(rid))
  preds.append({'sample_id':sid,'rule_id':rid,'direct':{'label':dl if dl in ['T','F','U'] else 'INVALID','evidence_sentence_ids':de,'valid':dl in ['T','F','U'],'amortized_seconds':dr['amortized_seconds']},'structured':{'label':evaluate(extracted_rules.get(rid),facts) if sv else 'INVALID','evidence_sentence_ids':eids,'valid':sv,'amortized_seconds':fr['amortized_seconds']},'oracle_rule_ablation':{'label':evaluate(r['schema_gold'],facts) if fv else 'INVALID','evidence_sentence_ids':eids,'valid':fv,'amortized_seconds':fr['amortized_seconds']}})
 (out/'predictions.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in preds))
 env.update({'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30,'finish_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())});write(out/'environment.json',env)
 print('COMPLETE',flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('results'));p.add_argument('--model',type=pathlib.Path,required=True);p.add_argument('--batch',type=int,default=8);main(p.parse_args())
