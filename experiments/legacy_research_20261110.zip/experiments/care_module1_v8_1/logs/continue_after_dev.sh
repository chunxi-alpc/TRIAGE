#!/usr/bin/env bash
set -e
cd /home/gcx/TRIAGE-worktrees/care-module1-v8-1
tail --pid=2950135 --pid=2950715 -f /dev/null
bash experiments/care_module1_v8_1/run_experiment.sh
