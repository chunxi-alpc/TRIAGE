"""Label-blind real Qwen3-8B inference. No reference rule/fact is sent to the model."""
import argparse,hashlib,json,os,pathlib,platform,time
from specs import FIELDS
from grounding import canonical_map,normalize_ids,ground
from logic import evaluate,valid_schema
def read(p):return [json.loads(x) for x in p.read_text().splitlines()]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def parse(s):
 try:return json.loads(s)
 except Exception:
  try:return json.loads(s[s.index('{'):s.rindex('}')+1])
  except Exception:return None
POLICY='Use only reported patient facts, not guideline recommendations, plans, or staging assumptions. Missing, unreported, not performed, pending, or uncertain findings are unknown, never negative or zero. Explicit absence/denial is negative. Resolve logical negation. For a field concerning the current assessment use the latest stated assessment, not older values; for an explicitly historical field such as induction exposure use that event. Two incompatible reports for the SAME current time and specimen, with neither corrected nor superseded, make that field unknown. A conflict in one field does not automatically make the whole rule unknown: use strong three-valued AND/OR. Distinguish different lesions, anatomical sites, specimen types, components, and measurements. A known bound/range can establish a rule only when every permitted value entails the same truth. Return JSON only.'
COMMON='You are evaluating research rule predicates, not choosing treatment. '+POLICY
def main(a):
 import torch,transformers
 from transformers import AutoTokenizer,AutoModelForCausalLM
 root=a.data;out=root/'model';out.mkdir(exist_ok=False)
 for name,h in json.loads((root/'frozen_data_hashes.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h
 for name,h in json.loads((root/'frozen_code_hashes.json').read_text()).items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==h
 inputs=read(root/'private/inputs.jsonl');rules=[{'rule_id':r['rule_id'],'text':r['text']} for r in read(root/'private/rules.jsonl')];rb={r['rule_id']:r for r in rules}
 torch.manual_seed(20261020);tk=AutoTokenizer.from_pretrained(a.model,local_files_only=True,padding_side='left');tk.pad_token_id=tk.eos_token_id
 t=time.perf_counter();m=AutoModelForCausalLM.from_pretrained(a.model,local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda:0').eval();loadtime=time.perf_counter()-t
 env={'python':platform.python_version(),'torch':torch.__version__,'transformers':transformers.__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'model_path':str(a.model),'model_load_seconds':loadtime,'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'generation':{'do_sample':False,'enable_thinking':False,'dtype':'bfloat16','batch':a.batch,'seed':20261020},'note':'Pre-frozen new-rule/full-case stress test. No retries or gold substitution.'};dump(out/'environment.json',env)
 def generate(jobs,stage,max_new):
  res={};batches=[]
  for start in range(0,len(jobs),a.batch):
   bs=jobs[start:start+a.batch];texts=[tk.apply_chat_template([{'role':'system','content':COMMON},{'role':'user','content':j['prompt']}],tokenize=False,add_generation_prompt=True,enable_thinking=False) for j in bs]
   enc=tk(texts,padding=True,return_tensors='pt').to('cuda:0');torch.cuda.synchronize();t=time.perf_counter()
   with torch.inference_mode():seq=m.generate(**enc,max_new_tokens=max_new,do_sample=False,pad_token_id=tk.pad_token_id,eos_token_id=tk.eos_token_id)
   torch.cuda.synchronize();elapsed=time.perf_counter()-t;batches.append({'batch_start':start,'n':len(bs),'seconds':elapsed,'input_padded_tokens':int(enc.input_ids.shape[1]),'new_padded_tokens':int(seq.shape[1]-enc.input_ids.shape[1])})
   with (out/(stage+'_raw.jsonl')).open('a') as f:
    for j,ids,txt in zip(bs,seq,texts):
     raw=tk.decode(ids[enc.input_ids.shape[1]:],skip_special_tokens=True);r={'id':j['id'],'raw_output':raw,'parsed':parse(raw),'prompt_sha256':hashlib.sha256(txt.encode()).hexdigest(),'batch_start':start,'amortized_seconds':elapsed/len(bs)};res[j['id']]=r;f.write(json.dumps(r,ensure_ascii=False)+'\n')
   print(json.dumps({'stage':stage,'completed':start+len(bs),'total':len(jobs)}),flush=True)
  dump(out/(stage+'_timing.json'),batches);return res
 dictionary=json.dumps(FIELDS)
 rp='Translate ONLY the following predicate into {"mode":"all|any", "conditions":[{"field":FIELD,"op":"lt|le|gt|ge|eq","value":number or "positive" or "negative"}],"exceptions":[]}. Use these exact FIELD keys and meanings: '+dictionary+'. Inclusive ranges require ge and le. Negative/absent is eq negative. A single condition may use all. Convert to canonical units. Rule: '
 rex=generate([{'id':r['rule_id'],'prompt':rp+r['text']} for r in rules],'rule_extraction',384)
 keys={rid:sorted({c.get('field') for c in (x['parsed'] or {}).get('conditions',[]) if isinstance(c,dict) and c.get('field') in FIELDS}) for rid,x in rex.items()}
 directjobs=[];factjobs=[]
 for x in inputs:
  sid=x['sample_id'];rid=x['rule_id'];fs=keys[rid];case='\n'.join(f'[{i+1}] {s}' for i,s in enumerate(x['sentences']))
  directjobs.append({'id':sid,'prompt':'Field meanings: '+dictionary+'\nDecide whether the rule is satisfied. T=satisfied, F=contradicted, U=insufficient/conflicting information. Return {"label":"T|F|U","evidence_sentence_ids":[integer IDs]}. Cite a sufficient proof; for missing-data U use [], for conflicting-data U cite both conflicting reports.\nRule: '+rb[rid]['text']+'\nComplete supplied case:\n'+case})
  template={'facts':{f:None for f in fs},'evidence':{f:[] for f in fs}}
  factjobs.append({'id':sid,'prompt':'Field meanings: '+dictionary+'\nExtract ONLY these fields, preserving exact keys: '+json.dumps(fs)+'. Fill '+json.dumps(template)+'. Each fact must be a number, positive, negative, or null. Do not replace a range/bound with an invented exact point: if no single exact value is stated, use null. For missing or unresolved conflicting values use null. Non-null values require supporting sentence IDs. For conflict provide both reports in evidence; for missing use []. Do not output a rule label, threshold, or explanation.\nComplete supplied case:\n'+case})
 direct=generate(directjobs,'direct',128);facts=generate(factjobs,'facts',320)
 rows=[];checks=[];t=time.perf_counter()
 for x in inputs:
  sid=x['sample_id'];rid=x['rule_id'];n=len(x['sentences']);rule=rex[rid]['parsed'];fs=keys[rid];d=direct[sid]['parsed'] or {};obj=facts[sid]['parsed'] or {};fv=canonical_map(obj.get('facts'));ev=canonical_map(obj.get('evidence'))
  valid=valid_schema(rule) and bool(fs) and all(c['field'] in FIELDS for c in rule['conditions']+rule['exceptions']) and all(f in fv and f in ev and (fv[f] is None or type(fv[f]) in [int,float] or fv[f] in ['positive','negative']) for f in fs)
  def pred(label,ids,valid):return {'label':label,'evidence_sentence_ids':ids,'valid':valid}
  ids=sorted({i for f,v in fv.items() if v is not None for i in normalize_ids(ev.get(f),n)})
  gf,ge,au=ground(obj,x['sentences'],fs)
  rows.append({'sample_id':sid,'rule_id':rid,'direct':pred(d.get('label') if d.get('label') in ['T','F','U'] else 'INVALID',normalize_ids(d.get('evidence_sentence_ids'),n),d.get('label') in ['T','F','U']),'structured_no_guard':pred(evaluate(rule,fv) if valid else 'INVALID',ids,valid),'structured':pred(evaluate(rule,gf) if valid else 'INVALID',sorted({i for ids in ge.values() for i in ids}),valid)})
  checks.append({'sample_id':sid,'checks':au})
 for name,data in [('predictions.jsonl',rows),('evidence_checks.jsonl',checks)]:
  (out/name).write_text(''.join(json.dumps(x)+'\n' for x in data))
 env.update({'postprocessing_seconds':time.perf_counter()-t,'end_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30});dump(out/'environment.json',env);print('COMPLETE',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('data'));p.add_argument('--model',required=True);p.add_argument('--batch',type=int,default=8);main(p.parse_args())
