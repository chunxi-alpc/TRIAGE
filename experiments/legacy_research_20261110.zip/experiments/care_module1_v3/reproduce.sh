#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
source /home/gcx/gcx261014/bin/activate
CARE_NEW_OUTPUT="${1:?Pass a NEW absolute server output directory}"
CARE_NEW_SOURCE="${CARE_SOURCE:-/home/gcx/TRIAGE/data/MedGUIDE}"
CARE_NEW_MODEL="${CARE_MODEL:-/home/gcx/n/models/Qwen3-8B}"
CARE_NEW_GPU="${CARE_GPU:-6}"
case "$CARE_NEW_OUTPUT" in /*) ;; *) echo 'Use an absolute server output path'; exit 1;; esac
case "$CARE_NEW_GPU" in 0|1|2|3|6|7) ;; *) echo 'GPU not authorized'; exit 1;; esac
python build_dataset.py --source "$CARE_NEW_SOURCE" --out "$CARE_NEW_OUTPUT"
python verify_rebuild.py --rebuilt "$CARE_NEW_OUTPUT"
cp data/frozen_code_hashes.json "$CARE_NEW_OUTPUT/frozen_code_hashes.json"
if [ "${2:-}" = '--data-only' ]; then exit 0; fi
test "$(nvidia-smi --id="$CARE_NEW_GPU" --query-gpu=memory.free --format=csv,noheader,nounits)" -gt 30000
CUDA_VISIBLE_DEVICES="$CARE_NEW_GPU" python run_experiment.py --data "$CARE_NEW_OUTPUT" --model "$CARE_NEW_MODEL" >"$CARE_NEW_OUTPUT/run.log" 2>&1
python evaluate.py --data "$CARE_NEW_OUTPUT" >"$CARE_NEW_OUTPUT/evaluation.log"
