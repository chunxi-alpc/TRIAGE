"""Package code/indices/results without exporting source-text quotations or private inputs."""
import hashlib,json,pathlib,shutil,zipfile
from specs import FIELDS
base=pathlib.Path(__file__).resolve().parent;stage=base/'delivery_stage'/'care_module1_v3'
stage.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b.encode() if isinstance(b,str) else b).hexdigest()
def save(rel,content):
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content,encoding='utf-8')
def copy(rel):
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/rel,p)
allowed=set(FIELDS)|{'positive','negative','T','F','U','unknown'}
def sanitize(obj,path=()):
 if isinstance(obj,dict):return {k:sanitize(v,path+(k,)) for k,v in obj.items()}
 if isinstance(obj,list):return [sanitize(v,path) for v in obj]
 if isinstance(obj,str) and (('evidence' in path and not obj.isdigit() and obj not in allowed) or len(obj)>100):return {'source_quote_omitted':True,'sha256':sha(obj),'characters':len(obj)}
 return obj
facts=[];omitted=0
for line in (base/'data/model/facts_raw.jsonl').read_text().splitlines():
 rec=json.loads(line);clean=sanitize(rec['parsed']);changed=clean!=rec['parsed'];omitted+=changed
 rec.update({'original_record_sha256':sha(line),'original_raw_output_sha256':sha(rec['raw_output']),'parsed':clean,'publication_redacted':changed})
 if changed:rec['raw_output']=None;rec['omission_reason']='Model quoted source text; unmodified output retained on authorized experiment server.'
 facts.append(rec)
save('data/model/facts_raw.redacted.jsonl',''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in facts))
analysis=json.loads((base/'error_analysis.json').read_text())
for key in ['guard_introduced_errors','guard_rescued_errors']:
 for x in analysis[key]:x['raw_facts']=sanitize(x['raw_facts'])
analysis['publication_note']='Free-text evidence omitted only in delivery copy; raw diagnostic file remains unchanged on server.'
save('error_analysis.json',json.dumps(analysis,ensure_ascii=False,indent=2)+'\n')
for p in base.glob('*.py'):copy(p.relative_to(base))
for name in ['PROTOCOL.zh.txt','README.zh.txt','REPORT.zh.txt','reproduce.sh','run.log','validation.log','rebuild.log','rebuild_first_strict_check.log','reproduction_verification.json','evaluation.log','public_metrics_check.log','analysis.log']:copy(pathlib.Path(name))
for folder in ['data','prerequisites','provenance']:
 for p in (base/folder).rglob('*'):
  if not p.is_file() or 'private' in p.parts or p.name=='facts_raw.jsonl':continue
  copy(p.relative_to(base))
save('DELIVERY_NOTES.json',json.dumps({'source_text_not_redistributed':True,'fact_outputs_with_quoted_text_omitted':omitted,'fact_output_total':len(facts),'unmodified_fact_output_server_path':str(base/'data/model/facts_raw.jsonl'),'evaluation_uses_original_outputs':True,'publication_redaction_did_not_change_predictions_or_metrics':True},indent=2)+'\n')
files=sorted(p for p in stage.rglob('*') if p.is_file());save('SHA256SUMS.json',json.dumps({str(p.relative_to(stage)):sha(p.read_bytes()) for p in files},indent=2)+'\n')
dest=base/'care_module1_v3.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,arcname=str(p.relative_to(stage.parent)))
with zipfile.ZipFile(dest) as z:assert z.testzip() is None;assert not any('/private/' in n for n in z.namelist())
print(json.dumps({'zip_bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'redacted_fact_outputs':omitted}))
