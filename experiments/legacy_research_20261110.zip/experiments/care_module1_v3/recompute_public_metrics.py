"""Recompute cached-result metrics without redistributing source text. No GPU."""
import pathlib,shutil,tempfile
from evaluate import main
base=pathlib.Path(__file__).resolve().parent/'data'
with tempfile.TemporaryDirectory(prefix='care_metrics_') as d:
 root=pathlib.Path(d);(root/'private').mkdir()
 for name in ['labels.jsonl','pairs.jsonl']:shutil.copy2(base/name,root/name)
 shutil.copytree(base/'model',root/'model')
 shutil.copy2(base/'rules_manifest.jsonl',root/'private/rules.jsonl')
 main(root)
 for name in ['metrics.json','errors.jsonl','comparison.csv']:
  assert (root/name).read_bytes()==(base/name).read_bytes(),name
print('Public cached results reproduce metrics, errors and comparison table exactly.')
