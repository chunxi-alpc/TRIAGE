CARE模块一：新规则、完整病例及困难表述验证

先读REPORT.zh.txt。主要结果为data/metrics.json中的direct与structured；structured_no_guard是推理前预设的诊断，不能在看过结果后替换主方法。

实验目录：gcx@10.29.128.115:/home/gcx/care_module1_20261017_v3
所有数据构建、推理、测试、评估、重建和结果核验均在该服务器执行；客户端仅编辑代码和收取交付件。
环境：source /home/gcx/gcx261014/bin/activate
模型：/home/gcx/n/models/Qwen3-8B
来源：/home/gcx/TRIAGE/data/MedGUIDE，固定快照1460ec478280a7295040b92f7eb985327f77dcbe。
代码固定了旧实验的来源索引路径，用于排除病例与规则。完整重建需保留服务器上care_module1_20261017及care_module1_20261017_v2的公开标签和rules_manifest.jsonl。交付prerequisites/备份这些元数据，可据此迁移路径；路径修改本身要记录，不能伪称原文件哈希不变。

文件
specs.py：16条条件的来源节点、字段定义、完整原文阅读后的参考事实/范围。
build_dataset.py：独立参考判定、原文与干预构建、来源及重复检查、全部标注位置。
logic.py：原有数值比较和强三值逻辑，未修改。
grounding.py：新字段别名和字面证据核对，不具备完整否定、时间和矛盾推理能力。
run_experiment.py：真实Qwen3-8B推理及原始输出；不向模型提供参考标签、参考事实或规则结构。
evaluate.py：主指标、分组准确率、证据证明覆盖、按新规则及源病例的配对bootstrap。
PROTOCOL.zh.txt、data/frozen_*_hashes.json：推理前固定的方案、代码和数据。
data/labels.jsonl、pairs.jsonl、rules_manifest.jsonl：参考值、来源行号/哈希、保留/删除句号、证据位置和配对关系。
data/model/rule_extraction_raw.jsonl、direct_raw.jsonl：未经人工修正的模型原始回答。
data/model/facts_raw.redacted.jsonl：交付省略版。部分模型回答复述了来源句子，包内以引用文本哈希替代，并保留原始回答/记录哈希；该省略版不用于评价。未修改的facts_raw.jsonl完整保留在服务器原目录。
data/model/predictions.jsonl、evidence_checks.jsonl：逐条预测及证据接受/拒绝原因。
data/model/*_timing.json、environment.json：实际耗时、软件参数、GPU和显存。
data/metrics.json、comparison.csv、errors.jsonl：最终指标、对照表和全部错误。
error_analysis.json：错误原因与证据核对步骤的影响，只做诊断，不改预测；交付版同样省略其中引用原句。analyze_results.py需在服务器有完整原始回答的目录运行。
run.log、validation.log、rebuild.log：详细运行和核验日志。

在指定服务器复现
cd /home/gcx/care_module1_20261017_v3
bash reproduce.sh /home/gcx/care_v3_reproduction_NEW --data-only
上述命令仅重建数据并核对冻结哈希，目录必须不存在。输入、标签、配对及规则要求逐字节一致；审计JSON中因集合遍历导致的字典键顺序差异按解析后的内容核对，首次严格哈希失败日志保留。正式重跑时去掉--data-only，默认GPU 6；也可用CARE_SOURCE、CARE_MODEL、CARE_GPU覆盖路径和获准GPU。
运行前按用户约定先汇报GPU、显存、样本规模与时间。脚本要求空闲显存超过30GB；稳定后不持续监控。
只复算公开缓存结果：python recompute_public_metrics.py，不需要原文或GPU。
测试：python -m unittest test_contract。
不同硬件或软件版本即使greedy解码也可能改变输出；原始回答、库版本、参数及已采集的模型文件哈希均保留。

口径
30个独立源病例，32个病例—规则组合，其中两例分别用于两个新规则。32条原始样本完整保留病例；160条干预样本替换相关句子，保留其余原句，不能称为未改动的原始全文。16条新规则中1条为旧肺结节字段的新范围组合，其余需要新的字段概念。仅为条件判断，不代表完整指南推荐。
标签由原文阅读与可追溯编辑产生，没有独立医生复核。使用来源路径生成的最终治疗选项不作为标签。原始组类别不平衡，必须查看分组结果，不能只看总准确率。

许可
已读取的MedGUIDE数据卡许可证为TBD，未据此认定允许公开再分发。交付包不含病例全文、路径全文、parquet或模型权重；只包含代码、索引、标签、简短选择片段/编辑规则、哈希与模型JSON输出。真实输入留在服务器data/private/。拥有合法来源数据后可复现。
模型权重和软件版本来源元数据沿用前次采集，另记录本次运行环境；没有声称此次重新下载或联网核验所有来源。
