"""Predeclared vocabulary adaptation of v2 literal evidence checks.

No global contradiction, temporal relation, or numeric interval machinery was added.
This intentionally tests the limitations of the prior point-value architecture.
"""
import math,re
from specs import FIELDS,ALIASES,CATEGORY,NAMES
def canonical_map(obj):
 if not isinstance(obj,dict):return {}
 reverse={v:k for k,v in FIELDS.items()};out={}
 for k,v in obj.items():
  k=reverse.get(k,k)
  if k in FIELDS:out[k]=v if k not in out or out[k]==v else None
 return out
def normalize_ids(ids,n):
 if not isinstance(ids,list):return []
 out=[]
 for x in ids:
  if isinstance(x,str) and re.fullmatch('[1-9][0-9]*',x):x=int(x)
  if type(x) is int and 1<=x<=n:out.append(x)
 return sorted(set(out))
def numeric_supported(f,v,s):
 if type(v) not in [int,float] or not math.isfinite(v) or not re.search(ALIASES[f],s,re.I):return False
 vals=[float(x) for x in re.findall(r'(?<![A-Za-z])\d+(?:\.\d+)?',s)]
 words=['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty']
 vals += [float(words.index(x.lower())) for x in re.findall(r'\b[a-z]+\b',s,re.I) if x.lower() in words]
 if f.endswith('_mm'):vals += [float(x)*10 for x in re.findall(r'(\d+(?:\.\d+)?)\s*cm\b',s,re.I)]
 if f.endswith('_cm'):vals += [float(x)/10 for x in re.findall(r'(\d+(?:\.\d+)?)\s*mm\b',s,re.I)]
 return any(abs(v-x)<1e-6 for x in vals)
def category_supported(f,v,s):
 if v not in ['positive','negative']:return False
 alias='(?:'+ALIASES[f]+'|'+re.escape(NAMES[f])+')'
 token='(?:positive|present|confirmed)' if v=='positive' else '(?:negative|absent)'
 pats=[rf'{alias}\s*[-:]?\s*(?:(?:is|was|are|were|remains)\s+)?{token}\b',rf'\b{token}\s+(?:for\s+)?{alias}']
 if v=='negative':pats.append(rf'\bno\s+(?:evidence\s+of\s+)?{alias}')
 for p in pats:
  for m in re.finditer(p,s,re.I):
   if re.search(r'\b(?:not|if|whether)\s*$',s[max(0,m.start()-20):m.start()],re.I):continue
   return True
 return False
def ground(parsed,sents,fs):
 parsed=parsed if isinstance(parsed,dict) else {};facts=canonical_map(parsed.get('facts'));ev=canonical_map(parsed.get('evidence'));out={};evidence={};audit=[]
 for f in fs:
  v=facts.get(f);ids=normalize_ids(ev.get(f,[]),len(sents));supported=[];reason='accepted'
  if v is None:reason='model_missing'
  elif not ids:reason='no_valid_evidence'
  else:
   supported=[i for i in ids if (category_supported(f,v,sents[i-1]) if f in CATEGORY else numeric_supported(f,v,sents[i-1]))]
   if not supported:reason='cited_sentence_does_not_support_value'
  out[f]=v if reason=='accepted' else None;evidence[f]=supported if reason=='accepted' else []
  audit.append({'field':f,'proposed_value':v,'accepted_value':out[f],'proposed_ids':ids,'accepted_ids':evidence[f],'reason':reason})
 return out,evidence,audit
