"""Build complete originals and audited controlled perturbations, before inference."""
import argparse,hashlib,itertools,json,pathlib,re,collections
import pandas as pd
from specs import RULES,CASES,FIELDS,ALIASES,CATEGORY,NAMES,UNITS
def sha(b):return hashlib.sha256(b.encode() if isinstance(b,str) else b).hexdigest()
def split(s):return re.split(r'(?<!Mr\.)(?<!Ms\.)(?<!Dr\.)(?<=[.!?])\s+(?=[A-Z*])',s)
def atom_truth(c,v):
 if v is None:return 'U'
 op=c['op'];t=c['value']
 cmp=lambda a:{'lt':lambda:a<t,'le':lambda:a<=t,'gt':lambda:a>t,'ge':lambda:a>=t,'eq':lambda:a==t}[op]()
 if not isinstance(v,dict):return 'T' if cmp(v) else 'F'
 # Independent annotation oracle: cover every ordering interval cut by bounds.
 piv=sorted({0.,float(t),*[float(x) for x in v.values()]});piv.append(max(piv)+100)
 points=set(piv)|{(a+b)/2 for a,b in zip(piv,piv[1:])}
 good=[p for p in points if all({'lt':p<b,'le':p<=b,'gt':p>b,'ge':p>=b}[o] for o,b in v.items())]
 assert good
 truth={cmp(p) for p in good};return 'T' if truth=={True} else 'F' if truth=={False} else 'U'
def gold(rule,facts):
 ts=[atom_truth(c,facts.get(c['field'])) for c in rule['conditions']]
 return ('F' if 'F' in ts else 'U' if 'U' in ts else 'T') if rule['mode']=='all' else ('T' if 'T' in ts else 'U' if 'U' in ts else 'F')
def fields(rule):return sorted({a['field'] for a in rule['conditions']})
def point(rule,f,wanted):
 cs=[c for c in rule['conditions'] if c['field']==f]
 pool=['positive','negative'] if f in CATEGORY else sorted({1,*[c['value'] for c in cs],*[max(1,c['value']-1) for c in cs],*[c['value']+1 for c in cs]},key=lambda v:(abs(v-cs[0]['value']),v))
 for v in pool:
  states=[atom_truth(c,v) for c in cs];truth=all(z=='T' for z in states)
  if truth==wanted:return v
 raise ValueError((f,wanted))
def state(rule,label):
 fs=fields(rule);vals={f:point(rule,f,rule['mode']=='all') for f in fs}
 if (rule['mode']=='all' and label=='F') or (rule['mode']=='any' and label=='T'):vals[fs[0]]=point(rule,fs[0],label=='T')
 assert gold(rule,vals)==label
 return vals

# Evidence selectors were chosen by reading complete source cases, not model output.
SELECT={
 (4818,'afp'):r'Laboratory studies show',(4818,'liver_mm'):r'During today',
 (4545,'afp'):r'Laboratory studies show',(4545,'liver_mm'):r'His ultrasound',
 (4819,'liver_mm'):r'During his scheduled',(4272,'liver_mm'):r'During his semi',
 (4001,'pci'):r'A subsequent comprehensive',(4001,'stable'):r'A subsequent comprehensive',(4001,'progression'):r'A subsequent comprehensive',
 (7584,'pci'):r'The laparoscopy revealed',(7584,'stable'):r'The laparoscopy revealed',(7584,'progression'):r'The CT showed',(7584,'extra'):r'The CT showed',
 (7585,'pci'):r'A repeat diagnostic laparoscopy',(5096,'pci'):r'Follow-up diagnostic laparoscopy',
 (4625,'testosterone'):r'He has been on continuous',(6808,'testosterone'):r'He experienced a biochemical recurrence',
 (5417,'solid_mm'):r'While no trauma',(4871,'solid_mm'):r"The radiologist.s report",
 (5951,'lung_mm'):r'7 mm solid',(4041,'lung_mm'):r'Incidentally',
 (4909,'thyroid_cm'):r'4.5 cm',(4909,'lymphatic'):r'Surgical pathology confirmed',(4909,'highgrade'):r'Surgical pathology confirmed',(4909,'multifocal_cm'):r'The tumor also',
 (6823,'thyroid_cm'):r'Pathology from the surgical',(6823,'lymphatic'):r'Pathology from the surgical',(6823,'highgrade'):r'Pathology from the surgical',
 (3567,'vessels'):r'Intraoperative frozen',(6567,'vessels'):r'After discussion',
 (4936,'vessels'):r'The patient underwent',(6022,'vessels'):r'After lobectomy',
 (7171,'sln_count'):r'^Bilateral sentinel',(7171,'sln_mm'):r'Detailed pathological',
 (5518,'sln_count'):r'One sentinel',(5518,'sln_mm'):r'One sentinel',
 (5519,'sln_mm'):r'The pathology report reveals',(5244,'sln_mm'):r'Pathology results show',
 (5519,'groin_nodes'):r'After the initial surgical',(5519,'ene'):r'After the initial surgical',
 (5244,'groin_nodes'):r'Final pathology from',(5244,'ene'):r'Final pathology from',
 (7054,'csf'):r'After four weeks on high-dose',(7054,'lm_progression'):r'After four weeks on high-dose',
 (3207,'csf'):r'Repeat MRI demonstrated',(3207,'lm_progression'):r'Repeat MRI demonstrated',
 (3081,'mass_effect'):r'Further imaging with MRI',(3081,'icp'):r'Brain CT is obtained',
 (4454,'mass_effect'):r'Based on his concerning',(4454,'icp'):r'Based on his concerning',
 (3628,'cd33'):r'Bone marrow biopsy confirms',(3628,'go_induction'):r'She initially underwent induction',
 (6629,'cd33'):r'initial workup showed',(6629,'go_induction'):r'He received intensive induction'
}
def original_ev(row,sents,vals):
 ev={}
 for f,v in vals.items():
  if v is None:ev[f]=[];continue
  matches=[i+1 for i,s in enumerate(sents) if re.search(SELECT[row,f],s,re.I)]
  assert len(matches)==1,(row,f,matches)
  ev[f]=matches
 return ev
def statement(f,v):
 if v is None:return f'The current record does not report {NAMES[f]}; this assessment is unavailable.'
 return f'Current assessment: {NAMES[f]} is {v} {UNITS[f]}.'.replace(' .','.')
def evidence_proofs(rule,vals,ev):
 label=gold(rule,vals)
 if label=='U':return [[]]
 atoms=rule['conditions'];ts=[atom_truth(c,vals.get(c['field'])) for c in atoms]
 if (rule['mode']=='all' and label=='T') or (rule['mode']=='any' and label=='F'):
  return [sorted({i for c in atoms for i in ev[c['field']]})]
 return [ev[c['field']] for c,t in zip(atoms,ts) if t==label]
def grams(s):
 ws=re.findall(r'[a-z]+',s.lower());return set(zip(ws,ws[1:],ws[2:]))
def similarity(a,b):return len(a&b)/len(a|b)
def build(source,out):
 out.mkdir(parents=True,exist_ok=False);(out/'private').mkdir()
 df=pd.read_parquet(source/'data/train-00000-of-00001.parquet');old=set()
 old_paths=['/home/gcx/care_module1_20261017/results/labels.jsonl','/home/gcx/care_module1_20261017_v2/holdout/labels.jsonl','/home/gcx/care_module1_20261017_v2/round2/holdout/labels.jsonl']
 for path in old_paths:old.update(json.loads(s)['source_row'] for s in pathlib.Path(path).read_text().splitlines())
 old_rules=[json.loads(s) for s in pathlib.Path('/home/gcx/care_module1_20261017_v2/rules_manifest.jsonl').read_text().splitlines()]
 old_nodes={r['source_node_sha256'] for r in old_rules}
 sig=lambda r:json.dumps(r,sort_keys=True)
 old_sigs={sig(r['schema_gold']) for r in old_rules}
 inputs=[];labels=[];pairs=[];reviews=[];new=set();rm=[]
 for r in RULES:
  rule=r['schema_gold'];fs=fields(rule);node=df.iloc[r['source_row']].path[r['source_node_index']]
  assert sha(node) not in old_nodes and sig(rule) not in old_sigs
  rm.append(r|{'source_node_sha256':sha(node)})
  for position,(row,original) in enumerate(CASES[r['rule_id']]):
   assert row not in old
   profile=df.iloc[row].profile;sents=split(profile);ev=original_ev(row,sents,original);aid=f'B{len(pairs)+1:02}'
   def target_mention(f,s):
    if not re.search(ALIASES[f],s,re.I):return False
    if f.endswith('_mm') or f.endswith('_cm'):
     # Preserve all background and follow-up statements lacking a size claim.
     return bool(re.search(r'\b(?:mm|cm|millimet|centimet)|sub.centimet|micrometast',s,re.I))
    return True
   removed=[i for i,s in enumerate(sents) if any(target_mention(f,s) for f in fs)]
   # All explicitly annotated target evidence must be replaced as well.
   removed=sorted(set(removed)|{i-1 for ids in ev.values() for i in ids})
   context=[s for i,s in enumerate(sents) if i not in removed]
   assert context,(r['rule_id'],row,len(sents))
   native_label=gold(rule,original);new.add(row)
   variants=[]
   variants.append(('original',original,sents,ev,[],{}))
   flipped=state(rule,'F' if native_label=='T' else 'T')
   controlled=state(rule,'T' if position==0 else 'F')
   part={f:point(rule,f,rule['mode']=='all') for f in fs};missing=fs[0];part[missing]=None
   if position==1 and len(fs)>1:part[fs[1]]=point(rule,fs[1],rule['mode']=='any')
   for kind,vals in [('counterfactual',flipped),('partial_missing',part),('multiple_values',controlled),('negation',controlled),('contradiction',{f:point(rule,f,rule['mode']=='all') for f in fs})]:
    notes=[];nev={};extra={};conflict=fs[0]
    for f,v in vals.items():
     start=len(notes)
     if kind=='contradiction' and f==conflict:
      a,b=point(rule,f,True),point(rule,f,False)
      notes += [f'Current assessment, report A from today: {NAMES[f]} is {a} {UNITS[f]}.',f'Current assessment, report B from the same time and same specimen: {NAMES[f]} is {b} {UNITS[f]}. Neither report is corrected or superseded.']
      vals[f]=None;extra={'conflict_field':f,'conflicting_values':[a,b]}
     elif kind=='multiple_values' and v is not None:
      other=point(rule,f,not all(atom_truth(c,v)=='T' for c in rule['conditions'] if c['field']==f))
      notes.append(f'Historical assessment one year ago: {NAMES[f]} was {other} {UNITS[f]}; current assessment today: {NAMES[f]} is {v} {UNITS[f]}. The concurrently recorded hemoglobin is 11.2 g/dL and platelet count is 150 x 10^9/L.')
     elif kind=='negation' and v is not None:
      if f in CATEGORY:
       if v=='negative':notes.append(f'The current assessment of {NAMES[f]} excludes positivity; the result is confirmed to be negative, with no equivocal finding.')
       else:notes.append(f'It is not true that {NAMES[f]} is negative: the current assessment explicitly confirms a positive finding.')
      else:
       other=point(rule,f,not all(atom_truth(c,v)=='T' for c in rule['conditions'] if c['field']==f))
       notes.append(f'The current {NAMES[f]} is not {other} {UNITS[f]}; the confirmed measurement is {v} {UNITS[f]}.')
     else:notes.append(statement(f,v))
     nev[f]=list(range(len(context)+start+1,len(context)+len(notes)+1)) if v is not None else []
     if kind=='contradiction' and f==conflict:extra['conflict_evidence_ids']=list(range(len(context)+start+1,len(context)+len(notes)+1));nev[f]=[]
    variants.append((kind,dict(vals),context+notes,nev,removed,extra|({'missing_field':missing,'partial_at_rule_level':len(fs)>1,'decisive_other_field':position==1 and len(fs)>1} if kind=='partial_missing' else {})))
   for kind,vals,text,ve,deleted,extra in variants:
    sid=aid+'_'+kind;label=gold(rule,vals)
    inputs.append({'sample_id':sid,'anchor_id':aid,'rule_id':r['rule_id'],'sentences':text})
    labels.append({'sample_id':sid,'anchor_id':aid,'source_row':row,'source_profile_sha256':sha(profile),'rule_id':r['rule_id'],'variant':kind,'label':label,'gold_observations':vals,'gold_atom_truth':[atom_truth(c,vals.get(c['field'])) for c in rule['conditions']],'field_evidence_ids':ve,'acceptable_evidence_proofs':evidence_proofs(rule,vals,ve),'all_relevant_evidence_ids':sorted({i for ids in ve.values() for i in ids}),'source_sentence_count':len(sents),'retained_source_sentence_ids':[i+1 for i in range(len(sents)) if i not in deleted],'removed_source_sentence_ids':[i+1 for i in deleted],'inserted_sentence_sha256':[sha(s) for s in text[len(context):]] if kind!='original' else [],'word_count':len(' '.join(text).split()),'annotation':'source-read natural observations or explicit controlled edit; no evaluated-model label; no clinician adjudication'}|extra)
   pairs.append({'pair_id':aid,'source_row':row,'rule_id':r['rule_id'],'original_id':aid+'_original','counterfactual_id':aid+'_counterfactual','expected_label_change':True})
   reviews.append({'anchor_id':aid,'rule_id':r['rule_id'],'source_row':row,'original_label':native_label,'facts':original,'evidence':{f:[sents[i-1] for i in ids] for f,ids in ev.items()},'retained_context':context,'removed_original_sentences':[sents[i] for i in removed]})
 for name,data in [('private/inputs.jsonl',inputs),('private/rules.jsonl',rm),('labels.jsonl',labels),('pairs.jsonl',pairs),('rules_manifest.jsonl',[{k:v for k,v in r.items() if k!='text'} for r in rm])]:
  (out/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in data))
 (out/'private/annotation_review.json').write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
 previous=[grams(df.iloc[i].profile) for i in old];gs=[grams(df.iloc[i].profile) for i in sorted(new)]
 audit={'source_revision':'1460ec478280a7295040b92f7eb985327f77dcbe','source_parquet_sha256':sha((source/'data/train-00000-of-00001.parquet').read_bytes()),'new_rules':len(rm),'new_source_rows':sorted(new),'previous_source_rows':sorted(old),'previous_source_row_overlap':len(new&old),'source_node_hash_overlap':0,'normalized_rule_signature_overlap':0,'rule_case_anchors':len(pairs),'unique_source_cases':len(new),'samples':len(inputs),'variants':dict(collections.Counter(x['variant'] for x in labels)),'label_counts':dict(collections.Counter(x['label'] for x in labels)),'max_profile_similarity_to_previous':max(sim(a,b) for a in gs for b in previous) if False else max(similarity(a,b) for a in gs for b in previous),'native_originals_full_text':True,'word_counts_by_variant':{v:{'min':min(x['word_count'] for x in labels if x['variant']==v),'max':max(x['word_count'] for x in labels if x['variant']==v),'mean':sum(x['word_count'] for x in labels if x['variant']==v)/32} for v in {x['variant'] for x in labels}},'partial_rule_level_n':sum(x.get('partial_at_rule_level',False) for x in labels),'partial_decisive_n':sum(x.get('decisive_other_field',False) for x in labels),'limitations':['30 distinct source cases across 32 rule-case anchors; two vulvar cases shared by two new predicates','Originals preserve the entire profile; edited variants replace target-related sentences while retaining every unrelated source sentence','One new rule is a new range combination using previously seen lung diameter; other rules require new field concepts','Rule projections are explicitly declared, not complete treatment applicability','Natural-source gold reviewed by Codex without independent clinical adjudication','Source vignettes are synthetic and may include recommendation or guideline-like text; retained in original full records']}
 (out/'dataset_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 (out/'frozen_data_hashes.json').write_text(json.dumps({str(p.relative_to(out)):sha(p.read_bytes()) for p in out.rglob('*') if p.is_file() and p.name!='frozen_data_hashes.json'},indent=2)+'\n')
 print(json.dumps({k:audit[k] for k in ['new_rules','unique_source_cases','samples','label_counts','partial_rule_level_n','partial_decisive_n']}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,default=pathlib.Path('data'));a=p.parse_args();build(a.source,a.out)
