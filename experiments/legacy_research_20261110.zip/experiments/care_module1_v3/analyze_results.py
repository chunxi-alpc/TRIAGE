"""Post-run diagnosis only; never mutates frozen inputs, labels or predictions."""
import collections,hashlib,json,pathlib
from evaluate import read
base=pathlib.Path(__file__).resolve().parent;root=base/'data'
for name,h in json.loads((root/'frozen_data_hashes.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
for name,h in json.loads((root/'frozen_code_hashes.json').read_text()).items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h,name
lb={x['sample_id']:x for x in read(root/'labels.jsonl')};pb={x['sample_id']:x for x in read(root/'model/predictions.jsonl')};raw={x['id']:x['parsed'] for x in read(root/'model/facts_raw.jsonl')};checks=read(root/'model/evidence_checks.jsonl');err=read(root/'errors.jsonl')
rejections=collections.Counter();introduced=[];rescued=[]
for row in checks:
 sid=row['sample_id'];y=lb[sid];p=pb[sid]
 for a in row['checks']:
  if a['reason'] not in ['accepted','model_missing']:rejections[(y['variant'],a['reason'])]+=1
 rec={'sample_id':sid,'rule_id':y['rule_id'],'source_row':y['source_row'],'variant':y['variant'],'gold':y['label'],'unverified':p['structured_no_guard']['label'],'guarded':p['structured']['label'],'raw_facts':raw[sid],'checks':row['checks']}
 if p['structured_no_guard']['label']==y['label'] and p['structured']['label']!=y['label']:introduced.append(rec)
 if p['structured_no_guard']['label']!=y['label'] and p['structured']['label']==y['label']:rescued.append(rec)
out={'frozen_data_and_code_unchanged':True,'diagnosis_scope':'No post-run tuning or label changes. Evidence rejections describe observed pipeline behavior, not model internal reasoning.','rejections_by_variant':[{'variant':v,'reason':r,'field_count':n} for (v,r),n in rejections.items()],'guard_introduced_errors':introduced,'guard_rescued_errors':rescued,'direct_wrong_structured_correct':[x['sample_id'] for x in err if x['direct']['label']!=x['label'] and x['structured']['label']==x['label']],'structured_wrong_direct_correct':[x['sample_id'] for x in err if x['direct']['label']==x['label'] and x['structured']['label']!=x['label']]}
breakdown=collections.Counter();diagnoses=collections.Counter();ids=collections.defaultdict(list)
for x in introduced:
 reasons={c['reason'] for c in x['checks'] if c['reason'] not in ['accepted','model_missing']}
 key='interface_only' if reasons=={'no_valid_evidence'} else 'literal_check_only' if reasons=={'cited_sentence_does_not_support_value'} else 'mixed';breakdown[key]+=1
 y=lb[x['sample_id']];tags=set()
 for z in x['checks']:
  if z['reason']=='no_valid_evidence':tags.add('evidence_format_or_out_of_range')
  elif z['reason']=='cited_sentence_does_not_support_value':
   tags.add('reference_value_and_sentence_but_literal_guard_rejects' if z['proposed_value']==y['gold_observations'].get(z['field']) and set(z['proposed_ids'])&set(y['field_evidence_ids'].get(z['field'],[])) else 'non_reference_value_or_sentence')
 for tag in tags:diagnoses[tag]+=1;ids[tag].append(x['sample_id'])
out.update({'guard_introduced_breakdown':dict(breakdown),'introduced_error_nonexclusive_diagnoses':dict(diagnoses),'diagnosis_sample_ids':dict(ids)})
(base/'error_analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'guard_introduced_n':len(introduced),'guard_rescued_n':len(rescued),'rejection_counts':out['rejections_by_variant'],'frozen_data_and_code_unchanged':True}))
