"""Manually audited source conditions and observations, frozen before inference.

These are rule predicates, NOT treatment recommendations. Source path labels
are never used as patient gold; each natural observation was read from the profile.
"""
FIELDS={
 'afp':'AFP result: positive if explicitly elevated above the reported laboratory reference, negative if explicitly normal; otherwise null',
 'liver_mm':'Largest current liver nodule diameter on ultrasound, in mm (largest across multiple liver nodules)',
 'pci':'Current Peritoneal Cancer Index (PCI), numeric score',
 'stable':'Current stable or improved disease, positive if explicitly present, negative if explicitly not stable or improved',
 'progression':'Current metastatic disease progression, positive or negative',
 'extra':'Current extraperitoneal disease, positive or negative; absence of progression alone does not exclude existing disease',
 'testosterone':'Current serum testosterone, ng/dL',
 'solid_mm':'Current solid-component diameter of the part-solid pulmonary nodule, mm; not total nodule diameter',
 'lung_mm':'Current largest solid pulmonary nodule diameter, mm',
 'thyroid_cm':'Primary thyroid carcinoma diameter in the surgical specimen, cm; not lymph-node or secondary-focus diameter',
 'lymphatic':'Lymphatic invasion on thyroid pathology, positive or negative',
 'multifocal_cm':'Largest additional macroscopic thyroid tumor focus diameter, cm',
 'highgrade':'Poorly differentiated or high-grade thyroid carcinoma features, positive or negative',
 'vessels':'Number of invaded vessels in thyroid carcinoma pathology',
 'sln_count':'Number of positive sentinel lymph nodes in sentinel-node biopsy, excluding completion-dissection nodes',
 'sln_mm':'Largest metastatic deposit diameter in sentinel lymph nodes, mm; not primary tumor, invasion depth, or completion-dissection deposit',
 'groin_nodes':'Number of positive nodes in the completion inguinofemoral lymphadenectomy specimen, excluding earlier sentinel-node biopsy',
 'ene':'Extranodal extension in the completion inguinofemoral dissection specimen, positive or negative',
 'csf':'Persistent positive CSF cytology at the latest reassessment, positive or negative',
 'lm_progression':'Clinical or radiologic progression of leptomeningeal disease at the latest reassessment, positive or negative',
 'mass_effect':'Imaging-confirmed intracranial mass effect, positive or negative; suspected/potential alone is null',
 'icp':'Confirmed raised intracranial pressure, positive or negative; concern/risk alone is null',
 'cd33':'CD33 expression result, positive or negative',
 'go_induction':'Documented gemtuzumab ozogamicin administration during induction, positive if received, negative if explicitly not received'
}
ALIASES={
 'afp':r'AFP|alpha.?fetoprotein','liver_mm':r'liver|hepatic|ultrasound|nodul',
 'pci':r'\bPCI\b|peritoneal cancer index','stable':r'stabl|improv',
 'progression':r'progress|stable disease','extra':r'extraperitoneal|peritoneal.only|other distant|other sites|limited to',
 'testosterone':r'testosterone|castrate','solid_mm':r'solid component|solid-component|part.solid|subsolid',
 'lung_mm':r'pulmonary|lung|nodul','thyroid_cm':r'thyroid|carcinoma|tumou?r|lobectomy',
 'lymphatic':r'lymphatic','multifocal_cm':r'multifocal|secondary focus|distinct foci|additional.*focus',
 'highgrade':r'high.grade|poorly differentiated','vessels':r'vessel|vascular channel|angioinva',
 'sln_count':r'sentinel|\bSLN\b','sln_mm':r'sentinel|\bSLN\b|micrometast|metastatic focus',
 'groin_nodes':r'lymphadenectomy|lymph nodes|node.*positive','ene':r'extranodal|\bENE\b',
 'csf':r'\bCSF\b|cerebrospinal|cytology|malignant cells',
 'lm_progression':r'leptomeningeal|MRI|progression|weakness|mental status',
 'mass_effect':r'mass effect|midline shift','icp':r'intracranial pressure',
 'cd33':r'CD33','go_induction':r'gemtuzumab|induction'
}
# Generic literal surface forms only; no trained NLI or global contradiction resolver.
CATEGORY={k for k in FIELDS if k not in ['liver_mm','pci','testosterone','solid_mm','lung_mm','thyroid_cm','multifocal_cm','vessels','sln_count','sln_mm','groin_nodes']}
NAMES={'afp':'AFP result','liver_mm':'largest liver nodule diameter','pci':'Peritoneal Cancer Index (PCI)','stable':'stable or improved disease','progression':'metastatic disease progression','extra':'extraperitoneal disease','testosterone':'serum testosterone','solid_mm':'pulmonary nodule solid component diameter','lung_mm':'largest solid pulmonary nodule diameter','thyroid_cm':'primary thyroid carcinoma diameter','lymphatic':'lymphatic invasion','multifocal_cm':'additional macroscopic thyroid tumor focus diameter','highgrade':'high-grade thyroid carcinoma features','vessels':'number of invaded vessels','sln_count':'positive sentinel lymph node count','sln_mm':'largest sentinel lymph node metastatic deposit diameter','groin_nodes':'positive lymph node count in the completion inguinofemoral lymphadenectomy','ene':'extranodal extension','csf':'persistent CSF cytology','lm_progression':'leptomeningeal disease progression','mass_effect':'intracranial mass effect','icp':'raised intracranial pressure','cd33':'CD33 result','go_induction':'gemtuzumab ozogamicin administration during induction'}
UNITS={k:('mm' if k.endswith('_mm') else 'cm' if k.endswith('_cm') else 'ng/dL' if k=='testosterone' else '') for k in FIELDS}
def atom(f,op,v):return {'field':f,'op':op,'value':v}
def rule(rid,row,node,text,atoms,mode='all',scope='complete stated predicate'):
 return {'rule_id':rid,'source_row':row,'source_node_index':node,'text':text,'schema_gold':{'mode':mode,'conditions':atoms,'exceptions':[]},'scope':scope}
RULES=[
 rule('N01',116,1,'AFP is positive OR the largest liver nodule on ultrasound is at least 10 mm.',[atom('afp','eq','positive'),atom('liver_mm','ge',10)],'any'),
 rule('N02',117,1,'The largest liver nodule on ultrasound is less than 10 mm.',[atom('liver_mm','lt',10)]),
 rule('N03',119,4,'PCI is at most 10 AND disease is stable or improved AND metastatic progression is absent AND extraperitoneal disease is absent.',[atom('pci','le',10),atom('stable','eq','positive'),atom('progression','eq','negative'),atom('extra','eq','negative')]),
 rule('N04',121,4,'The Peritoneal Cancer Index is greater than 10.',[atom('pci','gt',10)],scope='numeric projection of a broader branch'),
 rule('N05',193,1,'Serum testosterone is less than 50 ng/dL.',[atom('testosterone','lt',50)],scope='numeric target, not a treatment eligibility claim'),
 rule('N06',170,4,'The solid component of the part-solid pulmonary nodule is at least 6 mm.',[atom('solid_mm','ge',6)],scope='numeric condition, not the resulting action'),
 rule('N07',162,2,'The largest solid pulmonary nodule is between 6 and 8 mm, inclusive.',[atom('lung_mm','ge',6),atom('lung_mm','le',8)]),
 rule('N08',209,2,'Primary thyroid carcinoma is greater than 4 cm OR lymphatic invasion is present OR an additional macroscopic thyroid tumor focus exceeds 1 cm OR poorly differentiated/high-grade carcinoma features are present.',[atom('thyroid_cm','gt',4),atom('lymphatic','eq','positive'),atom('multifocal_cm','gt',1),atom('highgrade','eq','positive')],'any'),
 rule('N09',235,5,'Thyroid carcinoma invades at least 4 vessels.',[atom('vessels','ge',4)],scope='numeric projection, excludes alternative widely invasive branch'),
 rule('N10',236,5,'Thyroid carcinoma invades fewer than 4 vessels.',[atom('vessels','lt',4)],scope='numeric projection, excludes alternative minimally invasive branch'),
 rule('N11',271,1,'Exactly one sentinel lymph node is positive AND its metastatic deposit is at most 2 mm.',[atom('sln_count','eq',1),atom('sln_mm','le',2)]),
 rule('N12',549,1,'A positive sentinel lymph node contains a metastatic deposit greater than 2 mm.',[atom('sln_mm','gt',2)]),
 rule('N13',827,3,'At least 2 nodes are positive in the completion inguinofemoral dissection OR extranodal extension is present.',[atom('groin_nodes','ge',2),atom('ene','eq','positive')],'any',scope='stated conditional threshold; not a treatment recommendation'),
 rule('N14',152,3,'CSF cytology remains positive AND clinical or radiologic leptomeningeal progression is present at the latest reassessment.',[atom('csf','eq','positive'),atom('lm_progression','eq','positive')]),
 rule('N15',24,2,'Intracranial mass effect is confirmed OR raised intracranial pressure is confirmed.',[atom('mass_effect','eq','positive'),atom('icp','eq','positive')],'any'),
 rule('N16',298,2,'CD33 is positive AND gemtuzumab ozogamicin was given during induction.',[atom('cd33','eq','positive'),atom('go_induction','eq','positive')],scope='two stated regimen conditions; not full regimen applicability')
]
# Original full-case observations. None means genuinely unreported/uncertain.
# Interval records preserve bounds, never fabricate a representative scalar.
CASES={
 'N01':[(4818,{'afp':'positive','liver_mm':12}),(4545,{'afp':'positive','liver_mm':12})],
 'N02':[(4819,{'liver_mm':8}),(4272,{'liver_mm':7})],
 'N03':[(4001,{'pci':8,'stable':'positive','progression':'negative','extra':None}),(7584,{'pci':8,'stable':'positive','progression':'negative','extra':'negative'})],
 'N04':[(7585,{'pci':15}),(5096,{'pci':18})],
 'N05':[(4625,{'testosterone':{'lt':20}}),(6808,{'testosterone':{'lt':20}})],
 'N06':[(5417,{'solid_mm':4}),(4871,{'solid_mm':7})],
 'N07':[(5951,{'lung_mm':7}),(4041,{'lung_mm':{'ge':6,'le':8}})],
 'N08':[(4909,{'thyroid_cm':4.5,'lymphatic':'positive','multifocal_cm':1.2,'highgrade':'positive'}),(6823,{'thyroid_cm':3,'lymphatic':'positive','multifocal_cm':None,'highgrade':'negative'})],
 'N09':[(3567,{'vessels':{'gt':4}}),(6567,{'vessels':5})],
 'N10':[(4936,{'vessels':3}),(6022,{'vessels':3})],
 'N11':[(7171,{'sln_count':1,'sln_mm':1.8}),(5518,{'sln_count':1,'sln_mm':1.8})],
 'N12':[(5519,{'sln_mm':3.6}),(5244,{'sln_mm':2.8})],
 'N13':[(5519,{'groin_nodes':3,'ene':'positive'}),(5244,{'groin_nodes':3,'ene':'positive'})],
 'N14':[(7054,{'csf':'positive','lm_progression':'positive'}),(3207,{'csf':'positive','lm_progression':'positive'})],
 'N15':[(3081,{'mass_effect':'positive','icp':'positive'}),(4454,{'mass_effect':'positive','icp':'positive'})],
 'N16':[(3628,{'cd33':'positive','go_induction':'positive'}),(6629,{'cd33':'positive','go_induction':'positive'})]
}
