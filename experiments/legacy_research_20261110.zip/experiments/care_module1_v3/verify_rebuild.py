import argparse,hashlib,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--rebuilt',type=pathlib.Path,required=True);a=p.parse_args();base=pathlib.Path(__file__).resolve().parent
hs=json.loads((base/'data/frozen_data_hashes.json').read_text());identical=[];metadata_order=[]
for name,h in hs.items():
 if hashlib.sha256((a.rebuilt/name).read_bytes()).hexdigest()==h:identical.append(name);continue
 # The frozen builder iterates a set only for audit dictionary key order.
 # Preserve that code and first failed strict-hash log; never change inference data.
 assert name=='dataset_audit.json',name
 assert json.loads((a.rebuilt/name).read_text())==json.loads((base/'data'/name).read_text()),name
 metadata_order.append(name)
result={'all_model_inputs_labels_pairs_rules_byte_identical':True,'byte_identical_files':identical,'semantically_identical_audit_with_different_key_order':metadata_order}
(base/'reproduction_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
