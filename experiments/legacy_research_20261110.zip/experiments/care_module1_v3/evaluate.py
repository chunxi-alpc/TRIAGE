import argparse,collections,csv,json,pathlib
import numpy as np
from sklearn.metrics import f1_score,confusion_matrix
def read(p):return [json.loads(s) for s in p.read_text().splitlines()]
def macro(g,p):
 return float(np.mean([2*np.sum((g==c)&(p==c))/(2*np.sum((g==c)&(p==c))+np.sum((g!=c)&(p==c))+np.sum((g==c)&(p!=c))) if np.any(g==c) or np.any(p==c) else 0. for c in ['T','F','U']]))
def main(root):
 labels=read(root/'labels.jsonl');pred=read(root/'model/predictions.jsonl');pairs=read(root/'pairs.jsonl');pb={x['sample_id']:x for x in pred};lb={x['sample_id']:x for x in labels};assert len(pb)==len(labels)==192
 g=np.array([x['label'] for x in labels]);methods=['direct','structured_no_guard','structured'];out={'status':'executed_once_after_freeze','n':len(labels),'methods':{}}
 def evidence_hit(x,m):
  ids=set(pb[x['sample_id']][m]['evidence_sentence_ids'])
  if x.get('conflict_evidence_ids'):return ids==set(x['conflict_evidence_ids'])
  if x['label']=='U':return not ids
  return any(set(proof)<=ids for proof in x['acceptable_evidence_proofs']) and ids<=set(x['all_relevant_evidence_ids'])
 rt=sum(x['seconds'] for x in json.loads((root/'model/rule_extraction_timing.json').read_text()))
 arrays={}
 for m in methods:
  p=np.array([pb[x['sample_id']][m]['label'] for x in labels]);arrays[m]=p;s=macro(g,p);assert abs(s-f1_score(g,p,labels=['T','F','U'],average='macro',zero_division=0))<1e-10
  known=[x for x in labels if x['label']!='U'];unknown=[x for x in labels if x['label']=='U'];changing=sum(all(pb[z[k]][m]['label']==lb[z[k]]['label'] for k in ['original_id','counterfactual_id']) for z in pairs)
  t=sum(x['seconds'] for x in json.loads((root/('model/'+('direct' if m=='direct' else 'facts')+'_timing.json')).read_text()))
  v={'macro_f1':s,'correct':int(np.sum(g==p)),'accuracy':float(np.mean(g==p)),'confusion_order':['T','F','U','INVALID'],'confusion':confusion_matrix(g,p,labels=['T','F','U','INVALID']).tolist(),'invalid':int(np.sum(p=='INVALID')),'pair_correct':changing,'pair_n':len(pairs),'pair_accuracy':changing/len(pairs),'unknown_correct':sum(pb[x['sample_id']][m]['label']=='U' for x in unknown),'unknown_n':len(unknown),'known_to_unknown':sum(pb[x['sample_id']][m]['label']=='U' for x in known),'known_n':len(known),'evidence_known_correct':sum(evidence_hit(x,m) for x in known),'evidence_known_accuracy':sum(evidence_hit(x,m) for x in known)/len(known),'evidence_all_correct':sum(evidence_hit(x,m) for x in labels),'conflict_evidence_correct':sum(evidence_hit(x,m) for x in labels if x['variant']=='contradiction'),'timing':{'fact_or_direct_generation_seconds':t,'one_time_rule_extraction_seconds':0 if m=='direct' else rt,'generation_seconds_including_rules':t+(0 if m=='direct' else rt),'note':'CUDA synchronized batch generation; excludes model loading, tokenization and I/O'},'by_variant':{},'subsets':{}}
  def subset(xs):return {'n':len(xs),'correct':sum(pb[x['sample_id']][m]['label']==x['label'] for x in xs),'labels':dict(collections.Counter(x['label'] for x in xs))}
  for typ in sorted({x['variant'] for x in labels}):v['by_variant'][typ]=subset([x for x in labels if x['variant']==typ])
  for typ,predicate in [('partial_decisive',lambda x:x.get('decisive_other_field',False)),('partial_indeterminate',lambda x:x.get('partial_at_rule_level',False) and not x.get('decisive_other_field',False)),('single_field_missing',lambda x:x['variant']=='partial_missing' and not x.get('partial_at_rule_level',False)),('native_intervals',lambda x:x['variant']=='original' and any(isinstance(y,dict) for y in x['gold_observations'].values()))]:v['subsets'][typ]=subset([x for x in labels if predicate(x)])
  out['methods'][m]=v
 rng=np.random.default_rng(20261020);out['bootstrap']={}
 for unit in ['rule_id','source_row']:
  groups=collections.defaultdict(list)
  for i,x in enumerate(labels):groups[x[unit]].append(i)
  clusters=list(groups.values());ds=[]
  for _ in range(2000):
   ix=[i for j in rng.integers(0,len(clusters),len(clusters)) for i in clusters[j]];ds.append(macro(g[ix],arrays['structured'][ix])-macro(g[ix],arrays['direct'][ix]))
  out['bootstrap'][unit]={'clusters':len(clusters),'replications':2000,'delta_f1_structured_minus_direct':macro(g,arrays['structured'])-macro(g,arrays['direct']),'percentile_95_interval':np.quantile(ds,[.025,.975]).tolist()}
 s=arrays['structured'];ng=arrays['structured_no_guard'];d=arrays['direct']
 out['paired_disagreements']={'structured_correct_direct_wrong':int(np.sum((s==g)&(d!=g))),'direct_correct_structured_wrong':int(np.sum((d==g)&(s!=g))),'both_wrong':int(np.sum((s!=g)&(d!=g))),'guard_introduced_errors':int(np.sum((ng==g)&(s!=g))),'guard_rescued_errors':int(np.sum((ng!=g)&(s==g)))}
 def normalize(r):
  if not isinstance(r,dict):return r
  r=dict(r)
  if len(r.get('conditions',[]))==1:r['mode']='all'
  r['conditions']=sorted(r.get('conditions',[]),key=lambda c:json.dumps(c,sort_keys=True));return r
 rr={r['rule_id']:r['schema_gold'] for r in read(root/'private/rules.jsonl')};rx=read(root/'model/rule_extraction_raw.jsonl')
 out['rule_extraction']={'normalized_exact_match':sum(normalize(x['parsed'])==normalize(rr[x['id']]) for x in rx),'n':len(rx),'mismatches':[x['id'] for x in rx if normalize(x['parsed'])!=normalize(rr[x['id']])]}
 errors=[]
 for x in labels:
  if any(pb[x['sample_id']][m]['label']!=x['label'] for m in methods):errors.append({k:x[k] for k in ['sample_id','rule_id','source_row','variant','label','gold_observations']}|{m:pb[x['sample_id']][m] for m in methods})
 (root/'errors.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in errors));(root/'metrics.json').write_text(json.dumps(out,indent=2)+'\n')
 with (root/'comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.writer(f);w.writerow(['method','macro_f1','correct','n','pair_correct','pair_n','evidence_known_correct','known_n','generation_seconds'])
  for m,v in out['methods'].items():w.writerow([m,v['macro_f1'],v['correct'],192,v['pair_correct'],32,v['evidence_known_correct'],v['known_n'],v['timing']['generation_seconds_including_rules']])
 print(json.dumps(out))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=pathlib.Path,default=pathlib.Path('data'));main(p.parse_args().data)
