import unittest
from logic import evaluate
from build_dataset import atom_truth,gold
from grounding import normalize_ids,ground
class Contract(unittest.TestCase):
 def test_partial_and(self):
  r={'mode':'all','conditions':[{'field':'a','op':'ge','value':2},{'field':'b','op':'eq','value':'positive'}],'exceptions':[]}
  self.assertEqual(evaluate(r,{'a':1,'b':None}),'F');self.assertEqual(evaluate(r,{'a':3,'b':None}),'U')
 def test_partial_or(self):
  r={'mode':'any','conditions':[{'field':'a','op':'ge','value':2},{'field':'b','op':'eq','value':'positive'}],'exceptions':[]}
  self.assertEqual(evaluate(r,{'a':3,'b':None}),'T');self.assertEqual(evaluate(r,{'a':1,'b':None}),'U')
 def test_annotation_interval(self):
  self.assertEqual(atom_truth({'op':'lt','value':50},{'lt':20}),'T')
  self.assertEqual(atom_truth({'op':'gt','value':6},{'ge':6,'le':8}),'U')
  self.assertEqual(atom_truth({'op':'lt','value':4},{'gt':4}),'F')
 def test_ids(self):self.assertEqual(normalize_ids(['1',1,True,1.2,'2',0,7],3),[1,2])
 def test_unrelated_negative(self):
  f,_,_=ground({'facts':{'cd33':'negative'},'evidence':{'cd33':['1']}},['CD33 result is unavailable; HER2 is negative.'],['cd33'])
  self.assertIsNone(f['cd33'])
if __name__=='__main__':unittest.main()
