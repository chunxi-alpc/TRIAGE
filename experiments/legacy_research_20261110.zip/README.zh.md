# 早期方法与实验补录

本包把此前仅散落在服务器或旧研究分支、未在 main 完整收录的代码和结果集中保存。只收录已有材料，没有重跑实验。解压后按原 experiments 路径组织；support 保存对应历史 src 依赖，不覆盖当前主线实现。

## 如何阅读

先看各组 REPORT、RESULTS、TEACHER_REPORT 或 STATUS，再看同组指标和已存预测。历史报告中的“当前”“后续”及模块编号只指当时版本；完成状态与评价范围见仓库中央实验总览。V2 的事后重放、V3 的失败、V8.1 未采纳方案、N1/N4未执行及后续开发检查均保留原义。

## 保存范围

- CARE V1/V2/V3：来自原公开交付包，保存代码、协议、报告、标签、指标和已存模型输出。
- reliability：保存 V6/V7 与模块二真实运行的源码、报告、汇总和最终预测，不重复失败尝试及大缓存。
- steering：保存代码、原工作分支与服务器更新报告、指标和逐例预测的紧凑字段。compact 表仅选择原记录字段，没有生成或重新计算预测；完整提示和自由生成输出仍在来源目录。
- causal_attention：保存注意力干预、结构修复、最终对照预测和诊断表，开发扫描大日志留在原分支。
- A1、V8.1、U示例：保存同目录源码、构造数据、报告、参数选择及逐规则结果；重复的完整提示和生成日志保留原分支。
- N1–N5：保存修复后最终评估及 N3 最终开发检查；旧失效轮次只在来源保留，未把它们当成独立成功结果。
- TrialGPT A1：保存官方母集的派生逐例结果、指标与 U 错误分析；原患者文本、完整提示和原始生成日志不在本包。
- 适用性子空间、共享方向在线读取、决策后续：保存历史源码依赖、报告、最终记录与统计。
- SEKA：保存源码、报告、审阅结果、标准任务和临床实测的逐例指标；574MB完整树中的大型 predictions、run_records 与权重留在原分支。

## 依赖与复现

CARE V1/V2/V3 按各自 reproduce.sh 与公开说明使用来源数据重建输入。其余代码保留原文件名、相对路径和参数，未修改成新主线API。历史的 src 依赖单独放在 support/<实验组>/src，阅读时以该目录为准；需要完整模型重跑时，应在下列对应历史分支中还原 experiments 文件，使用该分支配套的配置和环境。不要把多个 support/src 同时覆盖到当前 main。所有同目录 Python 源码已保存；外部模型、LoRA、完整权重和大激活不打包。实际实验仍应按用户规定在服务器环境执行并先报告资源。

本包保存的是历史运行证据，不把可解包或可复算描述为已在当前软件环境重新跑通。

## 原始来源

| 组 | 服务器原路径 | 原分支 |
|---|---|---|
| care_module1_v1 | /home/gcx/care_module1_20261017 | server-only public delivery |
| care_module1_v2 | /home/gcx/care_module1_20261017_v2 | server-only public delivery |
| care_module1_v3 | /home/gcx/care_module1_20261017_v3 | server-only public delivery |
| care_reliability_20261019 | /home/gcx/TRIAGE-worktrees/care-reliability-20261019/experiments/care_reliability_20261019 | codex/care-reliability-20261019-work |
| care_conflictmed_20261019 | /home/gcx/TRIAGE-worktrees/care-steering-github-20261019/experiments/care_conflictmed_20261019 | codex/care-steering-20261019 |
| causal_attention_20261019 | /home/gcx/TRIAGE-worktrees/causal-attention-20261019/experiments/causal_attention_20261019 | codex/causal-attention-20261019 |
| care_module1_semantic_v8 | /home/gcx/TRIAGE-worktrees/care-module1-semantic-v8-20261019/experiments/care_module1_semantic_v8 | codex/care-module1-semantic-v8-20261019 |
| care_module1_v8_1 | /home/gcx/TRIAGE-worktrees/care-module1-v8-1/experiments/care_module1_v8_1 | codex/care-module1-v8-1 |
| care_module1_u_examples_dev | /home/gcx/TRIAGE-worktrees/care-module1-u-examples-dev/experiments/care_module1_u_examples_dev | codex/care-module1-u-examples-dev |
| care_module2_incremental_20261020 | /home/gcx/TRIAGE-worktrees/care-module2-n1-n5-20261020/experiments/care_module2_incremental_20261020 | codex/care-module2-n1-n5-only-20261020 |
| trialgpt_a1_full_20261021 | /home/gcx/TRIAGE-worktrees/trialgpt-a1-full-20261021/experiments/trialgpt_a1_full_20261021 | codex/trialgpt-a1-full-expert-20261021 |
| module2_applicability_20261027 | /home/gcx/TRIAGE (git origin/research/module2-applicability-subspace) | research/module2-applicability-subspace |
| module2_mechanism_20261028 | /home/gcx/TRIAGE (git origin/research/module2-mechanism-20261028) | research/module2-mechanism-20261028 |
| module2_decision_followup_20261029 | /home/gcx/TRIAGE (git origin/codex/triage-applicability-decision-20261029) | codex/triage-applicability-decision-20261029 |
| aster_seka_execution | /home/gcx/TRIAGE (git origin/codex/aster-seka-execution-20261025) | codex/aster-seka-execution-20261025 |

原始完整GPU输出按本表的服务器目录和研究分支查找。代码、数据与预测均不以报告数字反向构造。没有执行哈希检查或新增实验。
