"""Recount existing current-protocol artifacts; no model inference or new CI."""
import ast, collections, gzip, hashlib, json, os, pathlib, re, sys, zipfile
import numpy as np
from audit_search import sha
OUT=pathlib.Path('/home/gcx/aster-final-missing-audit-20261114')
R=pathlib.Path('/home/gcx/aster-e678-gaps-20261112/reports/aster_e678_20261112')
Q=pathlib.Path('/home/gcx/aster-cr-retrain-paired-v2-20261111/reports/aster_cr_retrain_paired_v2_20261111')
F=pathlib.Path('/home/gcx/aster-cr-balanced-publish-20261112/reports/aster_cr_final_method_10006_20261112')
D=pathlib.Path('/home/gcx/aster-cr-diagnostics-e3cv-20261111/reports/aster_cr_m3_intercept_diagnostics_20261112')
HIST=pathlib.Path('/home/gcx/aster_cr_repair_v2_run_20261108')
REG={}
def rows(path):
    path=pathlib.Path(path)
    if not path.exists():return
    with (gzip.open(path,'rt') if path.suffix=='.gz' else path.open()) as f:
        for l in f:
            if l.strip():yield json.loads(l)
def read(path):
    p=pathlib.Path(path)
    return json.loads(p.read_text()) if p.exists() else {}
def record(path):
    p=pathlib.Path(path)
    if not p.exists():return {'path':str(p),'exists':False}
    if str(p) not in REG:REG[str(p)]={'path':str(p),'size':p.stat().st_size,'sha256':sha(p),'realpath':str(p.resolve())}
    return REG[str(p)]
def save(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def lines(name,values):
    p=OUT/name;p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('w') as w:
        for x in values:w.write(json.dumps(x)+'\n')
    return record(p)
def graph(case):
    ans={}
    for g in case['guideline']['groups']:
        n={}
        for r in g['rules']:
            m=re.match(r'(L\d+)[：:]',r['action']) or re.search(r'G\d+',r['action'])
            n['yes' if r['rule_id'].endswith('Y') else 'no']=m.group(1) if m.lastindex else m.group(0)
        ans[g['group_id']]=n
    return ans

def audit_parameters():
    out={}
    for model,root in [('qwen',Q)]+[(k,R/'models'/k) for k in ['llama31','gemma2','gemma3','medgemma','qwen_base','gemma2_base']]:
        d=root/'models/E1/full';j=read(d/'model.json');m3=read(d/'m3.json');conf=read(root/'configuration.json');fr=read(root/'frozen.json')
        with np.load(d/'m2.npz',allow_pickle=False) as z:shapes={k:list(z[k].shape) for k in z.files};heads=z['heads'].tolist()
        out[model]={'root':str(root),'files':[record(d/n) for n in ['model.json','m1.json','m2.npz','m3.json','m3.npz','calibration.json'] if (d/n).exists()], 'configuration_file':record(root/'configuration.json'),'frozen_file':record(root/'frozen.json'),'model_metadata_file':record(root/'model_metadata.json'),'training_pair_count':j.get('training_pair_count'),'training_source_count':len(j.get('training_sources',j.get('train_sources',[]))),'heads':heads,'m2_shapes':shapes,'m3_scalar_fields':{k:v for k,v in m3.items() if not isinstance(v,(list,dict))},'configuration':conf,'calibration':read(d/'calibration.json'),'frozen_time':fr.get('time',fr.get('frozen_at'))}
    for p in [Q/'data/E1_pairs.jsonl',pathlib.Path('/home/gcx/aster_cr_pair_dataset_20261111/balanced_train.jsonl'),Q/'data/natural_views.jsonl',Q/'data/path_features.jsonl',Q/'data/path_interference_views.jsonl',HIST/'data/path_cases.jsonl',pathlib.Path('/home/gcx/aster_next_20261109/inventory/official_all_path_cases.jsonl')]:record(p)
    src={}
    for fn in ['historical_views.jsonl','natural_views.jsonl','path_features.jsonl','path_interference_views.jsonl']:
        ss=collections.defaultdict(set)
        for v in rows(Q/'data'/fn):ss[v.get('split','unspecified')].add(v['source_id'])
        src[fn]={k:sorted(v) for k,v in ss.items()}
    pairs=list(rows(Q/'data/E1_pairs.jsonl'));out['data']={'pair_kinds':dict(collections.Counter(v['kind'] for v in pairs)),'sources':src,'source_overlap_fit_test':sorted(set(src['natural_views.jsonl'].get('fit',[]))&set(src['historical_views.jsonl'].get('test',[])))}
    save('protocol_current.json',out)
    return out

def audit_paths():
    official={c['case_id']:c for c in rows('/home/gcx/aster_next_20261109/inventory/official_all_path_cases.jsonl')}
    controlled={c['case_id']:c for c in rows(HIST/'data/path_cases.jsonl') if c['split']=='test'}
    result=[]
    for model,root in [('qwen',Q)]+[(k,R/'models'/k) for k in ['llama31','gemma2','gemma3','medgemma','qwen_base','gemma2_base']]:
        for scope,expected in [('test',controlled),('mega_official',official)]:
            p=root/'evaluation'/scope
            fs=sorted(p.glob('**/path_predictions.jsonl'))
            items=collections.defaultdict(dict);dups=collections.defaultdict(list);counts=collections.Counter();errors=collections.Counter();correct=collections.Counter();flagmismatch=collections.Counter()
            for f in fs:
                record(f)
                for r in rows(f):
                    if scope=='test' and (r.get('interference') or r.get('variant','original') not in ('original','full')):continue
                    m=r['method'];cid=r['case_id'];counts[m]+=1
                    if cid in items[m]:dups[m].append(cid)
                    items[m][cid]=r
                    if r.get('error') or r.get('status')=='unavailable':errors[m]+=1
                    c=expected.get(cid)
                    if c:
                        path=r.get('predicted_path',r.get('path'));leaf=r.get('predicted_leaf',r.get('leaf'))
                        ok=not r.get('error') and path==c['gold_path'] and leaf==c['gold_leaf']
                        correct[m]+=int(ok);flagmismatch[m]+=int(bool(r.get('correct'))!=ok)
            methods=['raw','E1','calibration'] if scope=='test' else ['raw','aster_cr','bias_only']
            if model=='qwen' and scope=='test':
                # Diagnostic output carries the independent source-fit intercept.
                extra=sorted((D/'predictions/test').glob('*path*.jsonl*'))
                for f in extra:
                    record(f)
                    for r in rows(f):
                        if r.get('method')!='independent_intercept' or r.get('variant','original') not in ('original','full'):continue
                        m='calibration';cid=r['case_id'];counts[m]+=1
                        if cid in items[m]:dups[m].append(cid)
                        items[m][cid]=r
                        if r.get('correct') is True:correct[m]+=1
                fs+=extra
            rr={'model':model,'scope':scope,'target_paths':len(expected),'target_sources':len({c['source_id'] for c in expected.values()}),'files':[record(f) for f in fs],'methods':{}}
            for m in methods:
                missing=sorted(set(expected)-set(items[m]));unexpected=sorted(set(items[m])-set(expected))
                rr['methods'][m]={'rows':counts[m],'unique_cases':len(items[m]),'unique_paths':len(items[m]),'sources':len({r['source_id'] for r in items[m].values()}),'correct_recount':correct[m],'correct_flag_mismatches':flagmismatch[m],'errors':errors[m],'missing_paths':len(missing),'duplicate_path_ids':sorted(set(dups[m])),'unexpected_ids':unexpected,'missing_manifest':lines('missing_ids/e6_'+model+'_'+scope+'_'+m+'.jsonl',({'case_id':x,'source_id':expected[x]['source_id']} for x in missing))}
            result.append(rr)
    save('e6_current_recount.json',result)
    print('E6',[(r['model'],r['scope'],{m:v['unique_paths'] for m,v in r['methods'].items()}) for r in result],flush=True)

def audit_e7():
    result=[]
    for model in ['qwen','llama31','gemma2','gemma3','medgemma']:
        for scope,target in [('nli4ct',500),('nli4ct_official5500',5500),('medpic',188),('medpic_official467',467)]:
            root=(F if scope.endswith(('5500','467')) else Q) if model=='qwen' else R/'models'/model
            d=root/'evaluation'/scope;ps=list(rows(d/'predictions.jsonl'));qs=list(rows(d/'question_predictions.jsonl'));methods=set(m for r in ps for m in r.get('scores',{}));vv=ps if scope.startswith('nli') else [r for r in qs if r.get('variant') in ('full','original')]
            if scope=='nli4ct':vv=[r for r in ps if r.get('original') and r.get('kind')=='original']
            count={};correct={};duplicates={};sources={}
            for m in sorted(methods):
                if scope.startswith('nli'):
                    rr=[r for r in vv if m in r.get('scores',{})];ids=[r['view_id'] for r in rr];count[m]=len(rr);correct[m]=sum(int(r.get('predictions',{}).get(m,int(r['scores'][m]>0)))==int(r['label']) for r in rr if r.get('label') is not None)
                else:
                    rr=[r for r in vv if r.get('method')==m];ids=[str(r.get('question_id',r.get('item_id'))) for r in rr];count[m]=len(rr);correct[m]=sum(r.get('correct') is True for r in rr)
                duplicates[m]=len(ids)-len(set(ids));sources[m]=len({r['source_id'] for r in rr})
            metrics=read(d/'metrics.json');cal=read(root/'models/E1/full/calibration.json')
            rr={'model':model,'scope':scope,'target':target,'views':len(ps),'unique_views':len({r['view_id'] for r in ps}),'view_sources':len({r['source_id'] for r in ps}),'population_counts':count,'correct_recount':correct,'population_duplicates':duplicates,'population_sources':sources,'score_methods':sorted(methods),'bootstrap_items':len(metrics.get('bootstrap',[])),'source_calibration':cal,'files':[record(d/n) for n in ['predictions.jsonl','question_predictions.jsonl','pair_predictions.jsonl','metrics.json'] if (d/n).exists()]}
            if model!='qwen':
                delta=max([abs(r['scores']['calibration']-(r['scores']['raw']+cal['b'])) for r in ps],default=0);rr['intercept_score_identity_max_abs_error']=delta
            result.append(rr)
    save('e7_current_recount.json',result)
    print('E7',[(r['model'],r['scope'],r['population_counts'],r['correct_recount']) for r in result],flush=True)

def audit_cache():
    test_rows=[r for n in ['path_features.jsonl','path_interference_views.jsonl'] for r in rows(Q/'data'/n) if r['split']=='test']
    byvar=collections.defaultdict(set)
    for r in test_rows:byvar[r['variant']].add(r['uid'])
    result={}
    for model,root in [('qwen',Q)]+[(k,R/'models'/k) for k in ['llama31','gemma2','gemma3','medgemma']]:
        records={};fs=[root/'data/reused_scores.jsonl']+sorted((root/'cache').glob('scores*.jsonl'))+sorted((root/'cache').glob('*/scores*.jsonl'))
        for p in fs:
            record(p)
            for r in rows(p):
                if r.get('status','ok')=='ok' and 'feature' in r and 'ell' in r:records[r.get('uid',r.get('view_id'))]=r
        allids=set().union(*byvar.values());selected=read(root/'models/E1/full/m1.json').get('heads')
        with np.load(root/'models/E1/full/m2.npz',allow_pickle=False) as z:selected=z['heads'].tolist()
        summary={'records':len(records),'manifest_files':[record(p) for p in fs],'coverage_by_variant':{},'feature_validation':{}}
        for variant,ids in byvar.items():
            available=ids & records.keys();missing=ids-records.keys()
            summary['coverage_by_variant'][variant]={'candidate_uids':len(ids),'cached_uids':len(available),'missing_uids':len(missing),'missing_manifest':lines('missing_ids/e6_'+model+'_test_'+variant+'_candidate_uids.jsonl',({'uid':u} for u in sorted(missing)))}
        if model in ['gemma3','medgemma']:
            checked=collections.Counter();shapes=collections.Counter();invalid=[]
            target=set(read(root/'stage_ids.json')['test'])&records.keys()
            for uid in target:
                r=records[uid];p=pathlib.Path(r['feature'])
                if not p.is_absolute():p=root/p
                if not p.exists():invalid.append({'uid':uid,'reason':'feature_missing'});continue
                try:
                    with np.load(p,allow_pickle=False) as z:
                        a=z['heads'];a=a.reshape(-1,a.shape[-1]);hid=z['head_ids'].tolist() if 'head_ids' in z else list(range(a.shape[0]));idx={int(h):i for i,h in enumerate(hid)};shapes[str(a.shape)]+=1
                        if any(h not in idx for h in selected):invalid.append({'uid':uid,'reason':'selected_heads_missing'});continue
                        if not np.isfinite(a[[idx[h] for h in selected]]).all() or not np.isfinite(r['ell']):invalid.append({'uid':uid,'reason':'nonfinite'});continue
                        checked['valid_selected_heads_and_raw']+=1;checked['with_residual']+=int('residual' in z)
                except Exception as e:invalid.append({'uid':uid,'reason':str(e)})
            summary['feature_validation']={'target_records':len(target),'counts':dict(checked),'shapes':dict(shapes),'invalid':invalid}
        result[model]=summary
    save('e6_cache_coverage.json',result)
    print('CACHE', {k:v['coverage_by_variant'] for k,v in result.items() if k in ('gemma3','medgemma')},flush=True)

if __name__=='__main__':
    mode=sys.argv[1]
    {'parameters':audit_parameters,'paths':audit_paths,'e7':audit_e7,'cache':audit_cache}[mode]()
    save('files_'+mode+'.json',list(REG.values()))
