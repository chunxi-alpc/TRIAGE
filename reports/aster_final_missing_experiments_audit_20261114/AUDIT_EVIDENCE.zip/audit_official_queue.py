"""Existing official caches and exact initial node requests; no inference."""
import ast,collections,functools,hashlib,json,pathlib,re,zipfile
import numpy as np
from audit_current import OUT,Q,R,REG,rows,read,record,save,lines,graph

def main():
    source=pathlib.Path('/home/gcx/aster-e678-gaps-20261112/experiments/aster_closed_form/data.py');tree=ast.parse(source.read_text());ns={'re':re};funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['canonical_guide','render_guide','prompt']];exec(compile(ast.Module(body=funcs,type_ignores=[]),str(source),'exec'),ns);prompt=ns['prompt']
    cases={c['case_id']:c for c in rows('/home/gcx/aster_next_20261109/inventory/official_all_path_cases.jsonl')};out={}
    for model in ['qwen','gemma2','gemma3','medgemma']:
        root=Q if model=='qwen' else R/'models'/model;currentheads=np.load(root/'models/E1/full/m2.npz')['heads'].astype(int).tolist()
        oldparam=pathlib.Path('/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz') if model=='qwen' else pathlib.Path('/home/gcx/aster_five_models_20261109/results')/model/'mega/fitted.npz'
        oldheads=np.load(oldparam)['heads'].astype(int).tolist();missingheads=sorted(set(currentheads)-set(oldheads));record(oldparam)
        completed=set();own={}
        for f in (root/'evaluation/mega_official').glob('**/path_predictions.jsonl'):
            for r in rows(f):
                if r.get('method')=='aster_cr' and not r.get('error'):completed.add(r['case_id'])
        for f in (root/'evaluation/mega_official').glob('**/nodes.jsonl'):
            record(f)
            for r in rows(f):
                if r.get('status')=='ok':own[(r['case_id'],r['gid'])]=r
        if model=='qwen':
            oldfiles=list(pathlib.Path('/home/gcx/aster_next_20261109/results').glob('*/nodes.jsonl'))+list(pathlib.Path('/home/gcx/aster_next_20261109/primary_results/mega_official_test').glob('*/nodes.jsonl'))+list(pathlib.Path('/home/gcx/aster_next_20261109/fidelity/mega_official').glob('nodes.jsonl'))
        else:oldfiles=list(pathlib.Path('/home/gcx/aster_cross_model_mega_20261111',model).glob('*/nodes.jsonl'))
        old={}
        for f in oldfiles:
            record(f)
            for r in rows(f):
                if r.get('case_id') in cases and r.get('status')=='ok' and r.get('input_variant','canonical')=='canonical' and 'feature' in r:old[(r['case_id'],r['gid'])]=r
        compatible={};shape_counts=collections.Counter();errors=[]
        # Sparse historical selected_heads use the recorded historical head order.
        for key,r in old.items():
            p=pathlib.Path(r['feature'])
            try:
                with zipfile.ZipFile(p) as z:
                    names=z.namelist()
                    if 'heads.npy' in names:
                        with z.open('heads.npy') as h:
                            version=np.lib.format.read_magic(h);shape,_,_=np.lib.format._read_array_header(h,version)
                        shape_counts[str(shape)]+=1
                        if len(shape)==3 or (len(shape)==2 and shape[0]>max(currentheads)):compatible[key]=r
                    elif 'selected_heads.npy' in names:
                        shape_counts['historical_selected_heads']+=1
                        if not missingheads:compatible[key]=r
                    else:shape_counts['no_heads']+=1
            except Exception as e:errors.append({'feature':str(p),'error':str(e)})
        available=dict(compatible);available.update(own)
        pending={cid:c for cid,c in cases.items() if cid not in completed};gold=[];candidate=[];first=[];tokenkeys={}
        for cid,c in pending.items():
            tree=ns['canonical_guide'](c['guideline']);goldg={x['gid'] for x in c['gold_path']};rootgid=tree['nodes'][0]['id']
            for node in tree['nodes']:
                gid=node['id'];key=(cid,gid)
                if key in available:continue
                text=prompt(c['guideline'],c.get('definitions',[]),c['patient'],gid);digest=hashlib.sha256(text.encode()).hexdigest();tokenkeys.setdefault(digest,{'uid':'mega_prompt_'+digest[:24],'aliases':[],'gold':False,'first':False})
                tokenkeys[digest]['aliases'].append({'case_id':cid,'gid':gid,'source_id':c['source_id']});tokenkeys[digest]['gold']|=gid in goldg;tokenkeys[digest]['first']|=gid==rootgid
        for digest,v in sorted(tokenkeys.items()):
            item=dict(v,prompt_sha256=digest,model=model,methods=['raw','bias_only','aster_cr']);candidate.append(item)
            if v['gold']:gold.append(item)
            if v['first']:first.append(item)
        status=read(root/'evaluation/mega_official/shard0/status.json')
        entry={'model':model,'completed_paths':len(completed),'pending_paths':len(pending),'pending_sources':len({c['source_id'] for c in pending.values()}),'current_cached_nodes':len(own),'historical_canonical_nodes':len(old),'historical_feature_shapes':dict(shape_counts),'historical_compatible_nodes':len(compatible),'missing_selected_heads_in_historical':missingheads,'historical_parameters':record(oldparam),'historical_node_manifests':[record(p) for p in oldfiles],'cache_errors':errors,'pending_gold_nodes':sum(len(c['gold_path']) for c in pending.values()),'pending_gold_nodes_already_cached':sum((cid,n['gid']) in available for cid,c in pending.items() for n in c['gold_path']),'unique_missing_gold_forwards':len(gold),'unique_missing_root_forwards':len(first),'unique_missing_all_candidate_nodes_upper_bound':len(candidate),'initial_gold_manifest':lines('missing_ids/e6_'+model+'_official_initial_gold_nodes.jsonl',gold),'candidate_manifest':lines('missing_ids/e6_'+model+'_official_candidate_nodes.jsonl',candidate),'initial_root_manifest':lines('missing_ids/e6_'+model+'_official_initial_root_nodes.jsonl',first),'partial_status':status}
        out[model]=entry
    save('e6_official_queue_audit.json',out);save('files_official.json',list(REG.values()));print(json.dumps({m:{k:v for k,v in e.items() if k in ['completed_paths','pending_paths','current_cached_nodes','historical_compatible_nodes','historical_feature_shapes','missing_selected_heads_in_historical','pending_gold_nodes','pending_gold_nodes_already_cached','unique_missing_gold_forwards','unique_missing_root_forwards','unique_missing_all_candidate_nodes_upper_bound']} for m,e in out.items()}))

if __name__=='__main__':main()
