"""Prepare the audit-only report and compact evidence package; no experiment execution."""
from pathlib import Path
import hashlib
import json
import zipfile

A = Path('/home/gcx/aster-final-missing-audit-20261114')

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

methods = ['leace_pair', 'iti_style', 'sea_adaptation']
requests = {}
for method in methods:
    with (A / 'missing_ids' / ('e5_' + method + '_first_missing.jsonl')).open() as f:
        for line in f:
            row = json.loads(line)
            requests.setdefault(row['uid'], set()).add(method)
sharing = {
    'methods': methods,
    'first_frontier_unique_inputs': len(requests),
    'first_frontier_method_score_requests': sum(map(len, requests.values())),
    'shared_stage': 'One original-model prompt prefill per simultaneous UID request; separate method-specific final-token forwards.',
    'reason': 'Comparators.edited installs interventions after Engine.prepare. Engine.run copies the original prefix cache before each final-token forward.',
    'other_methods': 'Do not share adapter-modified or strong-prompt contexts across methods or seeds.',
    'inspection_only': True,
    'new_model_forwards': 0,
    'source_files': [],
}
for rel in ['experiments/aster_cr/comparators.py', 'experiments/aster_cr/engine.py', 'experiments/m1_diagnostics/engine.py', 'experiments/aster_e5_gaps_20261112/e1_representation_baselines.py']:
    p = Path('/home/gcx/aster-e5-gaps-20261112') / rel
    sharing['source_files'].append({'path': str(p), 'sha256': sha(p), 'size': p.stat().st_size})
write_json(A / 'e5_shared_prefill_plan.json', sharing)

plan = json.loads((A / 'MINIMAL_EXECUTION_PLAN.json').read_text())
plan['representation_shared_prefill'] = sharing
for task in plan['gpu_tasks']:
    if any(method in task['unit'] for method in methods):
        task['shared_worker_group'] = 'e5_original_prefix_representation_methods'
        task['share_prompt_prefill_only'] = True
        task['method_specific_scores_separate'] = True
write_json(A / 'MINIMAL_EXECUTION_PLAN.json', plan)

p = A / 'ASTER_FINAL_MISSING_EXPERIMENTS_AUDIT.md'
report = p.read_text()
needle = '同一方法/种子的重复UID只计算一次。'
paragraph = (
    f'LEACE-pair、ITI-style和SEA的现有实现均先计算原模型提示前缀，再对最后token施加方法修改。'
    f'三方法首批共{sharing["first_frontier_method_score_requests"]:,}个评分请求涉及{len(requests):,}个唯一输入；'
    '安排同一worker按UID共同处理，可共享提示前缀缓存，再分别执行方法修改后的最后token前向。'
    'Engine.run会复制前缀缓存，三方法的修正分数分别保存。LoRA、LoFiT、LoReFT及强证据提示继续使用各自适配器或提示对应的计算。'
    '源码依据和请求数见`e5_shared_prefill_plan.json`。\n\n'
)
if '源码依据和请求数见`e5_shared_prefill_plan.json`' not in report:
    report = report.replace(needle, paragraph + needle)
report = report.replace('计算完成，停止状态不能盖过逐例证据。', '逐例证据完整，按计算已完成登记。')
marker = '以上均重新读取逐例文件计数'
note = 'Qwen Base受控和官方两个单元登记为COMPLETE_CURRENT；表内其余完整计算单元因上游不可变revision缺项登记为NEEDS_VALIDATION，具体追溯状态见第2节。\n\n'
if note not in report:
    report = report.replace(marker, note + marker)
if '审计证据包' not in report:
    report += '\n审计证据包：`AUDIT_EVIDENCE.zip`。包含完整报告、待批准计划、逐项计数、缺失UID/路径清单、缓存映射、哈希目录、搜索范围和审计脚本。体量较大的原始全盘文件清单保留在服务器；压缩包内的`EVIDENCE_INDEX.json`列出对应位置。所有附件仅含路径、ID、配置、计数和证据元数据，不含临床提示原文。\n'
p.write_text(report)

for source, target in [('all_prediction_files.jsonl', 'prediction_index.jsonl'), ('archive_predictions.jsonl', 'archive_prediction_index.jsonl')]:
    with (A / source).open() as src, (A / target).open('w') as out:
        for line in src:
            obj = json.loads(line)
            ids = obj.pop('path_ids', None)
            if ids is not None:
                obj['path_ids_retained_in_server_full_index'] = True
            out.write(json.dumps(obj, ensure_ascii=False, separators=(',', ':')) + '\n')

server_only = [
    'inventory.jsonl', 'metadata_code_logs_inventory.jsonl', 'model_files_inventory.jsonl',
    'all_prediction_files.jsonl', 'archive_predictions.jsonl',
]
excluded = set(server_only) | {'AUDIT_EVIDENCE.zip', 'EVIDENCE_INDEX.json'}
files = [p for p in A.iterdir() if p.is_file() and p.name not in excluded and p.suffix in ['.json', '.jsonl', '.md', '.py', '.txt']]
for folder in ['missing_ids', 'cache_maps']:
    files.extend(p for p in (A / folder).rglob('*') if p.is_file())
files = sorted(files)
index = {
    'scope': 'Audit outputs only; no clinical prompts, model weights, or newly generated experiment predictions.',
    'server_directory': str(A),
    'server_only_large_indices': [{'path': str(A / name), 'size': (A / name).stat().st_size} for name in server_only],
    'packaged_files': [{'relative_path': str(p.relative_to(A)), 'size': p.stat().st_size} for p in files],
    'execution_approved': False,
    'models_loaded': False,
    'training_runs': 0,
    'gpu_forwards': 0,
}
write_json(A / 'EVIDENCE_INDEX.json', index)
files.append(A / 'EVIDENCE_INDEX.json')
with zipfile.ZipFile(A / 'AUDIT_EVIDENCE.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for f in files:
        z.write(f, str(f.relative_to(A)))
print(json.dumps({'report_bytes': p.stat().st_size, 'files_in_evidence_package': len(files), 'zip_bytes': (A / 'AUDIT_EVIDENCE.zip').stat().st_size, 'execution_approved': False}))
