"""Model identity and frozen-parameter provenance; never hash model weight shards."""
import collections, json, pathlib, re
import numpy as np
from audit_current import OUT,Q,R,D,F,REG,read,rows,record,save

def main():
    specs=read('/home/gcx/aster-e678-gaps-20261112/experiments/aster_e678/models.json');out={}
    manifest_paths={'qwen':['/home/gcx/TRIAGE/configs/qwen3_8b_modelscope_manifest.json','/home/gcx/TRIAGE-worktrees/aster-dynamic-fusion-review/experiments/aster_action_mass_seed0_20261025/results/model_weight_hashes.json'],'medgemma':['/home/gcx/TRIAGE/configs/medgemma_27b_modelscope_manifest.json'],'gemma3':['/home/gcx/gemma3_27b_head_pilot_20261103/download_manifest.json'],'qwen_base':['/home/gcx/TRIAGE-worktrees/aster-seka-execution-20261025/experiments/aster_seka_execution/qwen_base_download_manifest_v2.json'],'gemma2_base':[str(R/'status/gemma2_base_download.json')],'gemma2':['/home/gcx/aster_five_models_20261109/gemma2_download.json'],'llama31':[]}
    for key,c in specs.items():
        root=pathlib.Path(c['path']);config=read(root/'config.json');tokenizers=[p for p in root.iterdir() if p.is_file() and (p.name.startswith(('tokenizer','vocab','merges','special_tokens','added_tokens','chat_template')) or p.name in ['config.json','configuration.json','generation_config.json','model.safetensors.index.json'])]
        entry={'name':c['name'],'root':str(root),'revision':None,'tokenizer_revision':None,'model_type':config.get('model_type'),'config_name_or_path':config.get('_name_or_path'),'commit_hash_recorded':config.get('_commit_hash'),'weight_shards':[{'path':str(p),'bytes':p.stat().st_size,'mtime':p.stat().st_mtime} for p in sorted(root.glob('model-*.safetensors'))],'tokenizer_and_config_files':[record(p) for p in tokenizers],'manifests':[record(p) for p in manifest_paths.get(key,[]) if pathlib.Path(p).exists()]}
        if key=='qwen_base':
            m=read(manifest_paths[key][0]);entry['revision']=m['revision'];entry['tokenizer_revision']=m['revision'];entry['existing_weight_sha256_records']=m['weight_shards'];recorded={f['filename']:f['sha256'] for f in m['files']};entry['small_file_manifest_matches']={p.name:record(p)['sha256']==recorded[p.name] for p in tokenizers if p.name in recorded}
        elif key=='qwen':entry['existing_weight_sha256_records']=read(manifest_paths[key][1])
        elif key.startswith('gemma2'):entry['existing_weight_hash_record_source']='previous_audit.zh.md section 6.2; preserved prior computed values; not recomputed'
        else:entry['existing_weight_hash_record_source']='not found in inspected model download manifests'
        out[key]=entry
    comparisons={}
    for family,base,it in [('qwen','qwen_base','qwen'),('gemma2','gemma2_base','gemma2')]:
        roots=[R/'models'/base,Q if it=='qwen' else R/'models'/it];hs=[]
        for d in roots:
            with np.load(d/'models/E1/full/m2.npz',allow_pickle=False) as z:hs.append(set(z['heads'].tolist()))
        comparisons[family]={'comparison_file':record(R/'base_it'/family/'comparison.json'),'base_heads':len(hs[0]),'it_heads':len(hs[1]),'intersection':len(hs[0]&hs[1]),'union':len(hs[0]|hs[1]),'jaccard':len(hs[0]&hs[1])/len(hs[0]|hs[1]),'base_model':base,'it_model':it,'intermediate_sft_rl_checkpoint':'not found; endpoint comparison only'}
    independ=read(D/'configs/independent_intercepts_reused.json')['full'];natural={r['uid']:r for r in rows(Q/'data/natural_views.jsonl')};calids=independ['calibration_ids'];fit_sources={natural[u]['source_id'] for u in calids if u in natural}
    cal={'file':record(D/'configs/independent_intercepts_reused.json'),'b0':independ['b0'],'nodes':independ['nodes'],'calibration_ids_found_in_natural':len(set(calids)&natural.keys()),'calibration_source_count':len(fit_sources),'calibration_splits':sorted({natural[u].get('split') for u in calids if u in natural}),'target_task_fit':independ.get('target_task_fit'),'fit_sources_record':independ.get('fit_sources'),'ids_file':None}
    e1same=[]
    for n in ['model.json','m1.json','m2.npz','m3.json','m3.npz']:
        q=record(Q/'models/E1/full'/n);f=record(F/'models/E1/full'/n);e1same.append({'name':n,'qwen_original':q,'balanced_directory_E1':f,'sha256_identical':q['sha256']==f['sha256']})
    save('model_identity.json',out);save('e8_comparisons.json',comparisons);save('qwen_transfer_provenance.json',{'E1_parameter_identity':e1same,'independent_intercept':cal});save('files_identity.json',list(REG.values()))
    print(json.dumps({'revisions':{k:v['revision'] for k,v in out.items()},'E8':{k:{a:b for a,b in v.items() if a!='comparison_file'} for k,v in comparisons.items()},'intercept':{k:v for k,v in cal.items() if k not in ['file','fit_sources_record']},'F_E1_identity':all(x['sha256_identical'] for x in e1same)}))

if __name__=='__main__':main()
