"""E5 cache coverage, source prediction counts and exact missing-UID manifests."""
import collections, gzip, hashlib, json, pathlib, sys, zipfile
import numpy as np
from audit_current import OUT,Q,R,HIST,REG,rows,read,record,save,lines,graph
E5=pathlib.Path('/home/gcx/aster-e5-gaps-20261112/reports/aster_e5_gaps_20261112')
EXT=pathlib.Path('/home/gcx/aster-codex03-external-20261112/reports/aster_codex03_external_20261112')

def main():
    views=[v for v in rows(Q/'data/historical_views.jsonl') if v['split']=='test'];alias={v['original_view_id']:v['uid'] for v in views if 'original_view_id' in v}
    pv=[v for v in rows(Q/'data/path_interference_views.jsonl') if v['split']=='test'];ids={v['uid'] for v in pv};grouped=collections.defaultdict(dict)
    for v in pv:grouped[(v['case_id'],v['variant'])][v['gid']]=v['uid']
    cases={c['case_id']:c for c in rows(HIST/'data/path_cases.jsonl') if c['split']=='test'};trees={cid:graph(c) for cid,c in cases.items()}
    promptmap={}
    for v in rows(Q/'data/inputs.jsonl'):
        if v['uid'] in ids:promptmap[hashlib.sha256(v['prompt'].encode()).digest()]=v['uid']
    rawrec={}
    for f in [Q/'data/reused_scores.jsonl']+sorted((Q/'cache').glob('scores*.jsonl')):
        for v in rows(f):
            uid=v.get('uid',v.get('view_id'))
            if uid in ids and v.get('status','ok')=='ok' and 'ell' in v:rawrec[uid]=v
    jobs=[]
    for method,lr in [('lora','0.001'),('lofit','0.0001'),('loreft','0.0001')]:
        for seed in [11,22,33]:
            d=E5/('loreft_e1' if method=='loreft' else 'native_supervised_e1/'+method)/('lr'+lr+'_seed'+str(seed));jobs.append((method+'_seed'+str(seed),d,seed))
    for m in ['leace_pair','iti_style','sea_adaptation']:jobs.append((m,E5/'representation_e1_plan'/m,None))
    jobs+=[('strong_evidence_prompt',E5/'prompt_controls_e1/strong_evidence_prompt',None),('CC',E5/'prompt_controls_e1/CC',None)]
    output=[];unionmissing=set();frontier_union=set();logicaltasks=set();allcached=set();searesidual={}
    for name,d,seed in jobs:
        scores={};files=[]
        for suffix in ['input_predictions','path_node_scores']:
            f=d/('test_'+suffix+'.jsonl');files.append(record(f))
            for v in rows(f):
                uid=alias.get(v.get('view_id')) if suffix=='input_predictions' else promptmap.get(hashlib.sha256(v['prompt'].encode()).digest())
                if uid in ids:scores[uid]=float(v['score'])
        cached=set(scores);allcached|=cached
        missing=ids-cached
        if name!='CC':
            unionmissing|=missing
            logicaltasks.update((name,u) for u in missing)
        complete=[];stalled=[];frontier=set();cycles=[]
        for (cid,variant),nodes in grouped.items():
            tree=trees[cid];gid=next(iter(tree));visited=set()
            while gid in tree and gid not in visited:
                uid=nodes[gid]
                if uid not in scores:frontier.add(uid);stalled.append({'method':name,'seed':seed,'case_id':cid,'variant':variant,'source_id':cases[cid]['source_id'],'gid':gid,'uid':uid});break
                visited.add(gid);gid=tree[gid]['yes' if scores[uid]>0 else 'no']
            else:
                if gid not in tree:complete.append({'case_id':cid,'variant':variant})
                else:cycles.append({'case_id':cid,'variant':variant})
        if name!='CC':frontier_union|=frontier
        savedpaths=list(rows(d/'test_path_predictions.jsonl'));pairs=list(rows(d/'test_pair_predictions.jsonl'));metrics=read(d/'test_metrics.json')
        for f in ['test_path_predictions.jsonl','test_pair_predictions.jsonl','test_metrics.json','training.json','fit.json','selection.json','adapter.pt','operator.pt']:
            if (d/f).exists():files.append(record(d/f))
        out={'method':name,'seed':seed,'root':str(d),'natural_prediction_rows':len(savedpaths),'natural_unique_cases':len({v['case_id'] for v in savedpaths}),'natural_sources':len({v['source_id'] for v in savedpaths}),'natural_correct_flags':sum(v.get('correct') is True for v in savedpaths),'natural_duplicate_rows':len(savedpaths)-len({v['case_id'] for v in savedpaths}),'pair_rows':len(pairs),'pair_kind_counts':dict(collections.Counter(v.get('kind',v.get('type','unknown')) for v in pairs)),'saved_interference_predictions':sum(v.get('interference',False) for v in savedpaths),'interference_candidate_uids':len(ids),'cached_interference_uids':len(cached),'missing_candidate_uids':len(missing),'traversable_from_existing_scores':len(complete),'paths_needing_new_scores':len(stalled),'first_missing_unique_uids':len(frontier),'cycles':cycles,'files':files,'runtime':{k:metrics.get(k) for k in ['seconds','peak_gib','engine_counts']},'existing_metric_groups':list(metrics.get('groups',{})),'missing_manifest':lines('missing_ids/e5_'+name+'_candidate_uids.jsonl',({'uid':u} for u in sorted(missing))),'frontier_manifest':lines('missing_ids/e5_'+name+'_first_missing.jsonl',stalled)}
        output.append(out)
        if name=='sea_adaptation':
            # Enumerate residual availability from the raw E1 cache, INLP raw capture and truth features.
            residuals={};origins=collections.Counter()
            for u in missing:
                rec=rawrec.get(u)
                candidates=[]
                if rec and rec.get('feature'):candidates.append(('E1_raw_feature',pathlib.Path(rec['feature'])))
                candidates += [('INLP_raw_final_residual',EXT/'inlp/test/raw_residuals'/(u+'.npy')),('E5_truth_feature',E5/'representation_e1_plan/truth_features'/(u+'.npz'))]
                for kind,p in candidates:
                    if not p.exists():continue
                    if p.suffix=='.npz':
                        with zipfile.ZipFile(p) as z:
                            if 'residual.npy' not in z.namelist():continue
                    residuals[u]={'uid':u,'path':str(p),'kind':kind};origins[kind]+=1;break
            searesidual={'missing_score_uids':len(missing),'raw_residuals_available':len(residuals),'origins':dict(origins),'still_requires_residual':len(missing-residuals.keys()),'available_manifest':lines('cache_maps/e5_SEA_reusable_residuals.jsonl',residuals.values())}
    ext=[]
    for d in sorted((EXT/'evaluation/test').iterdir()):
        if not d.is_dir():continue
        ps=list(rows(d/'path_predictions.jsonl'));groups=collections.defaultdict(list)
        for r in ps:groups['interference' if r.get('interference') or r.get('variant','original') not in ('original','full') else 'natural'].append(r)
        stat=read(d/'statistics.json');ext.append({'method':d.name,'root':str(d),'path_groups':{k:{'rows':len(v),'unique_path_ids':len({(x['case_id'],x.get('variant','original')) for x in v}),'sources':len({x['source_id'] for x in v}),'correct_flags':sum(x.get('correct') is True for x in v)} for k,v in groups.items()},'statistics_keys':list(stat),'files':[record(d/n) for n in ['path_predictions.jsonl','pair_predictions.jsonl','predictions.jsonl','statistics.json','statistics.csv','training_and_implementation.json']]})
    summary={'candidate_uids_per_row':len(ids),'candidate_uids_union_13_rows':len(ids),'cached_uid_union':len(allcached),'missing_uid_union_13_rows':len(unionmissing),'method_specific_missing_uid_pairs_upper_bound':len(logicaltasks),'first_missing_uid_union_13_rows':len(frontier_union),'raw_cached_uids':len(ids&rawrec.keys()),'raw_missing_uids':len(ids-rawrec.keys()),'SEA_final_residuals':searesidual,'methods':output,'external_11_rows':ext,'CC_parameters':read(E5/'prompt_controls_e1/cc_parameters.json')}
    task_methods=sorted({m for m,_ in logicaltasks})
    lines('missing_ids/e5_unique_candidate_nodes.jsonl',({'uid':u,'needs_methods':[m for m in task_methods if (m,u) in logicaltasks],'raw_score_available':u in rawrec} for u in sorted(unionmissing)))
    save('e5_cache_and_predictions.json',summary);save('files_e5.json',list(REG.values()));print(json.dumps({k:v for k,v in summary.items() if k not in ['methods','external_11_rows']}));print('METHODS',[(x['method'],x['cached_interference_uids'],x['traversable_from_existing_scores'],x['first_missing_unique_uids']) for x in output])

if __name__=='__main__':main()
