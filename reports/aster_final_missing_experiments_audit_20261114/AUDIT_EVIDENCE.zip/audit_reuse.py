"""Check cached-feature sufficiency, recording coverage only, not new experiment results."""
import collections, functools, json, pathlib, sys
import numpy as np
from audit_current import OUT,Q,R,HIST,REG,rows,read,record,save,lines,graph

def main():
    cases={r['case_id']:r for r in rows(HIST/'data/path_cases.jsonl') if r['split']=='test'}
    oldcases={r['case_id']:r for r in rows('/home/gcx/aster_five_models_20261109/data/mega/path_cases.jsonl') if r['split']=='test'}
    viewmap={(r['case_id'],r['gid']):r['uid'] for r in rows(Q/'data/path_features.jsonl') if r['split']=='test'}
    equal={cid:all(c.get(k)==oldcases.get(cid,{}).get(k) for k in ['patient','guideline','definitions','gold_path','gold_leaf']) for cid,c in cases.items()}
    allout={}
    for model in ['gemma3','medgemma']:
        root=R/'models'/model;oldroot=pathlib.Path('/home/gcx/aster_five_models_20261109/results')/model/'mega'
        oldmeta=read(oldroot/'model_metadata.json');newmeta=read(root/'model_metadata.json')
        metadiff={k:[v,newmeta.get(k)] for k,v in oldmeta.items() if newmeta.get(k)!=v}
        records={}
        for f in [root/'data/reused_scores.jsonl']+list((root/'cache').glob('scores*.jsonl')):
            for r in rows(f):
                if r.get('status','ok')=='ok' and 'feature' in r:records[r.get('uid',r.get('view_id'))]=r
        initial=set(records);added={};overlaps=0
        p=oldroot/'paths/nodes.jsonl';record(p);reject=[]
        for r in rows(p):
            key=(r.get('case_id'),r.get('gid'));uid=viewmap.get(key)
            if not uid or not equal.get(key[0]):continue
            if r.get('status')!='ok' or not pathlib.Path(r['feature']).exists():reject.append({'id':r.get('id'),'reason':'missing_or_failed'});continue
            if uid in records:overlaps+=1;continue
            with np.load(r['feature'],allow_pickle=False) as z:
                h=z['heads'];shape=h.shape
                if 'head_ids' in z:reject.append({'id':r['id'],'reason':'sparse_requires_separate_check'});continue
                if len(shape)!=3 or shape[:2]!=(newmeta['num_layers'],newmeta['num_attention_heads']):reject.append({'id':r['id'],'reason':'shape_mismatch'});continue
            records[uid]=r;added[uid]=r
        m2=dict(np.load(root/'models/E1/full/m2.npz',allow_pickle=False));m3=dict(np.load(root/'models/E1/full/m3.npz',allow_pickle=False));heads=m2['heads'].astype(int);alpha=(m2['N'].astype(float)@m3['w'].astype(float))/m2['scale'];offset=float(m3['b'])-float(m2['mu']@alpha);b0=read(root/'models/E1/full/calibration.json')['b']
        @functools.lru_cache(maxsize=None)
        def cached_sign(uid,method):
            r=records[uid];ell=float(r['ell'])
            if method=='raw':return ell>0
            if method=='calibration':return ell+b0>0
            with np.load(r['feature'],allow_pickle=False) as z:
                h=z['heads'].astype(np.float32);h=h.reshape(-1,h.shape[-1]);ids=z['head_ids'].tolist() if 'head_ids' in z else list(range(len(h)));index={int(x):i for i,x in enumerate(ids)}
                if any(int(x) not in index for x in heads):return None
                selected=h[[index[int(x)] for x in heads]].reshape(-1)
            if not np.isfinite(selected).all():return None
            return ell+float(selected@alpha)+offset>0
        complete=collections.Counter();frontier=collections.defaultdict(set);used=collections.defaultdict(set);stalled=[]
        for cid,c in cases.items():
            tree=graph(c);start=next(iter(tree))
            for method in ['raw','calibration','E1']:
                gid=start;visited=set()
                while gid in tree and gid not in visited:
                    uid=viewmap[(cid,gid)];used[method].add(uid)
                    if uid not in records:
                        frontier[method].add(uid);stalled.append({'model':model,'method':method,'case_id':cid,'source_id':c['source_id'],'gid':gid,'uid':uid});break
                    sign=cached_sign(uid,method)
                    if sign is None:frontier[method].add(uid);stalled.append({'model':model,'method':method,'case_id':cid,'source_id':c['source_id'],'gid':gid,'uid':uid,'reason':'incompatible_feature'});break
                    visited.add(gid);gid=tree[gid]['yes' if sign else 'no']
                else:
                    if gid not in tree:complete[method]+=1
        entry={'model':model,'old_nodes_file':record(p),'old_metadata':record(oldroot/'model_metadata.json'),'current_metadata':record(root/'model_metadata.json'),'metadata_differences':metadiff,'matching_case_payloads':sum(equal.values()),'target_cases':len(cases),'initial_natural_candidate_uids':len(set(viewmap.values())&initial),'additional_natural_uids':len(added),'available_natural_uids':len(set(viewmap.values())&records.keys()),'remaining_candidate_uids':len(set(viewmap.values())-records.keys()),'overlap_records':overlaps,'rejected_records':reject,'cached_paths_traversable':dict(complete),'first_missing_unique_uids':{m:len(v) for m,v in frontier.items()},'first_missing_union':len(set().union(*frontier.values())) if frontier else 0,'visited_unique_uids':{m:len(v) for m,v in used.items()},'frontier_manifest':lines('missing_ids/e6_'+model+'_test_first_missing.jsonl',stalled),'additional_cache_manifest':lines('cache_maps/e6_'+model+'_additional_fullhead_nodes.jsonl',({'uid':u,'feature':v['feature'],'original_id':v['id']} for u,v in sorted(added.items()))),'note':'Transient sign calculation only checks whether existing caches cover each branch; no predictions, accuracy, or CI are generated.'}
        allout[model]=entry
    save('e6_additional_cache_reuse.json',allout);save('files_reuse.json',list(REG.values()));print(json.dumps({m:{k:v for k,v in x.items() if k in ['additional_natural_uids','available_natural_uids','remaining_candidate_uids','cached_paths_traversable','first_missing_unique_uids','first_missing_union','matching_case_payloads','metadata_differences']} for m,x in allout.items()}))

if __name__=='__main__':main()
