"""Build the audit report and an inert execution plan from verified evidence."""
import collections,hashlib,json,pathlib,time
from audit_current import OUT,Q,R,F,D,HIST,rows,read,record

def main():
    e6=read(OUT/'e6_current_recount.json');reuse=read(OUT/'e6_additional_cache_reuse.json');official=read(OUT/'e6_official_queue_audit.json');e5=read(OUT/'e5_cache_and_predictions.json');e7=read(OUT/'e7_current_recount.json');e8=read(OUT/'e8_comparisons.json');ident=read(OUT/'model_identity.json');proto=read(OUT/'protocol_current.json');runtime=read(OUT/'runtime_final.json');scope=read(OUT/'search_scope.json');archives=read(OUT/'archive_summary.json');scan=read(OUT/'prediction_scan_summary.json');formats=read(OUT/'other_format_summary.json');extra=read(OUT/'additional_search_scope.json');consistency=read(OUT/'cached_score_consistency.json')
    E5=pathlib.Path('/home/gcx/aster-e5-gaps-20261112/reports/aster_e5_gaps_20261112');EXT=pathlib.Path('/home/gcx/aster-codex03-external-20261112/reports/aster_codex03_external_20261112');PUB=pathlib.Path('/home/gcx/aster-results-publish-20261114')
    aliases={'R':str(R),'Q':str(Q),'F':str(F),'D':str(D),'E5':str(E5),'EXT':str(EXT),'PUB':str(PUB),'AUDIT':str(OUT),'OLD5':'/home/gcx/aster_five_models_20261109/results','OLDM':'/home/gcx/aster_cross_model_mega_20261111','OLDQ':'/home/gcx/aster_next_20261109/primary_results/mega_official_test'}
    def short(p):
        p=str(p)
        for a,base in sorted(aliases.items(),key=lambda x:-len(x[1])):
            if p==base or p.startswith(base+'/'):return a+p[len(base):]
        return p
    reg={x['path']:x for x in read(OUT/'artifact_sha256_registry.json')}
    def frow(path,label=None):
        path=str(path);x=reg.get(path)
        if x is None:x=record(path);reg[path]=x
        if not x.get('sha256'):return f"| {label or short(path)} | 未找到 | — |"
        return f"| `{label or short(path)}` | {x['size']:,} | `{x['sha256']}` |"
    names={'qwen':'Qwen3-8B-IT','llama31':'Llama-3.1-8B-Instruct','gemma2':'Gemma-2-9B-IT','gemma3':'Gemma-3-27B-IT','medgemma':'MedGemma-27B-Text-IT','qwen_base':'Qwen3-8B-Base','gemma2_base':'Gemma-2-9B-Base'}
    # The plan has no launch commands and is deliberately not an active scheduler manifest.
    cpus=[
      {'id':'C01','unit':'Gemma3 受控806','state':'PARTIAL_CURRENT','inputs':[str(R/'models/gemma3/models/E1/full'),str(OUT/'cache_maps/e6_gemma3_additional_fullhead_nodes.jsonl'),str(R/'models/gemma3/data/reused_scores.jsonl')],'implementation':'新建 cpu_rebuild_controlled_from_cache.py；复用 evaluation.py 的冻结线性评分、原树遍历及来源统计函数，按实际访问节点读取缓存','output':'reports/aster_final_gap_completion_20261114/e6/gemma3/test/','acceptance':'raw/calibration/E1 各806个唯一自然路径、40来源，已有配对指标和来源配对95%区间；0新模型前向'},
      {'id':'C02','unit':'MedGemma 受控806','state':'PARTIAL_CURRENT','inputs':[str(R/'models/medgemma/models/E1/full'),str(OUT/'cache_maps/e6_medgemma_additional_fullhead_nodes.jsonl'),str(R/'models/medgemma/data/reused_scores.jsonl')],'implementation':'同C01，使用MedGemma自己的头、子空间、M3和截距','output':'reports/aster_final_gap_completion_20261114/e6/medgemma/test/','acceptance':'同C01，使用MedGemma参数'},
      {'id':'C03','unit':'CC干扰路径','state':'PARTIAL_CURRENT','inputs':[str(E5/'prompt_controls_e1/cc_parameters.json'),str(Q/'cache'),str(Q/'data/path_interference_views.jsonl'),str(HIST/'data/path_cases.jsonl')],'implementation':'新建 cpu_complete_cc.py；raw+冻结offset后按树遍历；复用 bootstrap_summary 的来源配对抽样，不调用原prompt main()','output':'reports/aster_final_gap_completion_20261114/e5/CC/','acceptance':'2418干扰路径、806自然路径、40来源，纠正/新增错误、A/P、C/F与相对raw配对区间；0新模型前向'},
      {'id':'C04','unit':'新增方法11行配对差值','state':'PARTIAL_CURRENT','inputs':[str(EXT/'evaluation/test'),str(Q/'evaluation/test/path_predictions.jsonl')],'implementation':'新建 cpu_paired_path_ci.py；按(case_id,variant,source_id)配对，再对40来源共同抽样','output':'reports/aster_final_gap_completion_20261114/e5/external_paired_ci/','acceptance':'11行×自然/干扰两总体的差值点估计与95%区间；保留逐种子、方法自身既有区间及配对计数'},
      {'id':'C05','unit':'Qwen NLI500','state':'PARTIAL_CURRENT','inputs':[str(Q/'evaluation/nli4ct/predictions.jsonl'),str(D/'configs/independent_intercepts_reused.json')],'implementation':'新建 cpu_qwen_transfer.py；使用冻结b0=3.0993948961894406，不拟合任何参数；聚类口径待确认','output':'reports/aster_final_gap_completion_20261114/e7/qwen/nli500/','acceptance':'500原声明、2864视图；三方法逐例、准确率/宏F1、原生配对指标、纠正/新增错误、95%区间'},
      {'id':'C06','unit':'Qwen NLI5500','state':'PARTIAL_CURRENT','inputs':[str(F/'evaluation/nli4ct_official5500'),str(D/'configs/independent_intercepts_reused.json')],'implementation':'同C05；全量5500单独计算，避免natural字段的500分母；聚类口径待确认','output':'reports/aster_final_gap_completion_20261114/e7/qwen/nli5500/','acceptance':'三方法各5500声明；完整统计、原生关系指标、配对差值区间及脱敏逐例归档'},
      {'id':'C07','unit':'Qwen MedPIC467','state':'PARTIAL_CURRENT','inputs':[str(F/'evaluation/medpic_official467'),str(D/'configs/independent_intercepts_reused.json')],'implementation':'同C05；使用已冻结的原整题集合解码；376来源共同抽样','output':'reports/aster_final_gap_completion_20261114/e7/qwen/medpic467/','acceptance':'三方法各467原题/2335原始选项，保留7005含扰动视图；标注含开发题的描述性评价'},
      {'id':'C08','unit':'E5十三行接续统计','state':'PARTIAL_CURRENT','inputs':[str(E5), 'G05–G17新增节点分数'],'implementation':'完成路径后复用现有自然/配对预测；补干扰路径、配对来源区间和纠正/新增错误','output':'reports/aster_final_gap_completion_20261114/e5/','acceptance':'每方法/种子自然806、干扰2418、40来源；A/P2293与C/F40，F0另列；相对raw来源配对95%区间'},
      {'id':'C09','unit':'E6官方合并统计','state':'PARTIAL_CURRENT','inputs':['G01–G04新节点/路径',str(R/'models/gemma2/evaluation/mega_official/shard0')],'implementation':'复用 official_mega.py 的路径和自然节点汇总；按来源共同抽样','output':'reports/aster_final_gap_completion_20261114/e6/','acceptance':'每模型三方法各7458路径、418来源；重复ID=0；缺失ID=0；保留45627金标准自然节点总体；失败记录计入分母'}]
    gpu=[]
    estimates={'qwen':([3,4],[18,28],0),'gemma2':([5.5,7],[26,40],1),'gemma3':([8,11],[54,66],5),'medgemma':([7.5,10],[54,66],6)}
    for i,m in enumerate(['qwen','gemma2','gemma3','medgemma'],1):
        e=official[m];hours,vram,device=estimates[m]
        gpu.append({'id':f'G{i:02d}','unit':m+'_official','state':'PARTIAL_CURRENT' if m=='gemma2' else 'NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH','model':names[m],'model_path':ident[m]['root'],'upstream_revision':ident[m]['revision'],'frozen_parameters':str((Q if m=='qwen' else R/'models'/m)/'models/E1/full'),'pending_paths':e['pending_paths'],'initial_path_root_uids':e['unique_missing_root_forwards'],'known_gold_node_forwards':e['unique_missing_gold_forwards'],'all_tree_candidate_upper_bound':e['unique_missing_all_candidate_nodes_upper_bound'],'manifest':e['initial_gold_manifest']['path'],'root_manifest':e['initial_root_manifest']['path'],'candidate_manifest':e['candidate_manifest']['path'],'new_activation_required':'当前51头；同一次前向供raw/独立截距/ASTER使用','load_backbone':True,'gpu_count':1,'preferred_gpu':device,'vram_gib':vram,'estimated_gpu_hours':hours,'output':'reports/aster_final_gap_completion_20261114/e6/'+m+'/mega_official/','acceptance':cpus[-1]['acceptance']})
    for i,e in enumerate([x for x in e5['methods'] if x['method']!='CC'],5):
        gpu.append({'id':f'G{i:02d}','unit':e['method']+'_interference','state':'PARTIAL_CURRENT','model':'Qwen3-8B-IT','model_path':ident['qwen']['root'],'parameters':e['root'],'seed':e['seed'],'first_missing_uid_count':e['first_missing_unique_uids'],'frontier_manifest':e['frontier_manifest']['path'],'candidate_manifest':e['missing_manifest']['path'],'candidate_uid_upper_bound':e['missing_candidate_uids'],'load_backbone':'同卡同模型任务连续执行可复用已加载主干；冻结适配器按方法/种子切换','new_activation_required':'最终层原始残差，接冻结SEA算子' if e['method']=='sea_adaptation' else '方法特定前向分数；不复用其他方法的修正分数','gpu_count':1,'vram_gib':[18,28],'output':'reports/aster_final_gap_completion_20261114/e5/'+e['method']+'/','acceptance':cpus[-2]['acceptance']})
    plan={'status':'AWAITING_USER_APPROVAL','active_scheduler_manifest':False,'allowed_gpus':[0,1,5,6],'gpu_type':'NVIDIA A100-SXM4-80GB','max_active_gpu_jobs':4,'per_gpu_active_jobs':1,'scheduler':'单一统一GPU队列；同一模型优先连续复用；禁止各脚本自行启动独立调度器','training_tasks':0,'model_download_tasks':0,'cpu_tasks':cpus,'gpu_tasks':gpu,'estimated_gpu_hours':[32,46],'estimated_wall_hours_with_four_gpus':[12,18],'estimated_cpu_wall_hours':[1,3],'open_decision':'NLI500现有113临床试验/组合簇与NLI5500现有500原始声明簇：确认分别沿用并明确标注，或统一为临床试验/组合簇后再统计。','archive_after_execution':True,'monitoring':'启动后确认稳定运行即停止持续监控；调度器写状态和完成标记。'}
    (OUT/'MINIMAL_EXECUTION_PLAN.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    b=[]
    def add(s=''):b.append(s)
    def table(headers,rs):
        add('| '+' | '.join(headers)+' |');add('| '+' | '.join(['---']*len(headers))+' |')
        for row in rs:add('| '+' | '.join(str(x) for x in row)+' |')
        add()
    add('# ASTER-CR 最终实验缺口核验与最小补实验执行审计')
    add()
    add('审计日期：2026-11-14。服务器：`gcx@10.29.128.115`；环境：`gcx261014`。本轮输出审计材料和待批准计划，未执行新模型前向、训练、模型下载、补实验统计区间或GitHub写入。')
    add()
    add('**最小GPU范围为四个E6官方MEGA单元和E5十三行干扰路径。Gemma3、MedGemma的806条受控自然路径可由既有全头路径缓存完成CPU重建，GPU任务应从原六个E6单元减为四个。训练任务为0。**')
    add()
    add('已找到上一轮未纳入复用清单的两款27B全头路径缓存；它们补足了各自的实际访问节点。服务器仍缺对应的当前E1最终预测文件，需在批准后进行CPU重建和统计。缓存覆盖检查与实验交付完成状态分别登记。')
    add()
    add('## 1. 基准、证据与搜索范围')
    add()
    add('- 主线：`a783bc6330512028fd167868aff0f85666e747f8`。归档：`37cce4de0fc64cf1bfcb928a07ba3c60fb5c2584`。关联：[PR #69](https://github.com/chunxi-alpc/TRIAGE/pull/69)。')
    add('- 已首先通读[上一轮完整报告](https://github.com/chunxi-alpc/TRIAGE/blob/37cce4de0fc64cf1bfcb928a07ba3c60fb5c2584/reports/aster_remaining_experiments_audit_20261114/REPORT.zh.md)，其缺失判断作为待核查假设。副本保存在 `previous_audit.zh.md`。')
    add('- 服务器发布工作树位于`b67f7367…`。GitHub比较确认其至指定归档提交的文件差异为实验管理文档和上一轮审计报告；预测文件未改变。因此服务器发布树可用于核对该归档的逐例内容。')
    add()
    table(['范围','本轮实际检查'],[
      ['文件清单',f"{scope['files']:,}个文件；包含隐藏文件、非Git文件及软链接目标记录。"],
      ['目录', '`/home/gcx`、`/tmp`、`/var/tmp`、`/dev/shm`、`/data`、`/mnt`、`/media`，并补查`/srv`、`/opt`、`/var/backups`及存在的备份/工作目录。'],
      ['工作树与Git历史','70条注册工作树记录（其中1条失效临时工作树）、22个有改动的工作树；另检查7个仓库。165个本地/远程引用、106个不同提交；6个Git bundle列出引用，未导入或改写仓库。'],
      ['逐例文件',f"检查{scan['candidates']:,}个JSONL候选；识别{scan['counts']['paths']:,}份路径结果、{scan['counts']['scores_views']:,}份分数/视图、{scan['counts']['pairs']:,}份配对结果、{scan['counts']['questions']}份整题结果。"],
      ['其他格式',f"检查{formats['csv_checked']:,}个CSV及{formats['other_gzip_checked']:,}个其他GZIP；205份CSV路径结果按SHA256归并为14份不同内容。"],
      ['压缩归档','143个ZIP/TAR/压缩包或Git bundle，SHA256归并为42份不同文件；归档成员12,284项。检查了成员列表及其中的逐例文件。'],
      ['内容检索','243,944份元数据、代码和日志；按内容归并93,836份。检索E1协议、模型/方法名、目标分母、revision、SHA256、任务ID及完成/停止记录。'],
      ['重复识别','逐例内容归并为1,928组，其中744组含副本；保存物理文件SHA256及GZIP解压内容SHA256。'],
      ['模型缓存','检查模型清单、已有权重哈希、分词器/模板、全头/选头数组、最终残差、缓存UID及调度历史；未重新递归计算基础模型权重哈希。']])
    add('用户指定的13个目录均已检查。搜索还覆盖`aster_five_models_20261109`、`aster_cr_repair_v2_run_20261108`、各发布临时工作树、`aster_cr_final_results`、历史`aster_*`目录及`TRIAGE/results/diagnostic_backups`。')
    add()
    add('范围记录见`search_scope.json`、`worktree_status.json`、`additional_search_scope.json`、`git_ref_artifact_inventory.json`、`archive_summary.json`、`archive_members.jsonl`和`metadata_hits.jsonl`。原始完整文件清单保存在服务器`AUDIT/inventory.jsonl`。')
    add()
    add('本报告的“全面搜索未发现”限定于上述可访问实验空间。权限拒绝涉及其他用户/系统临时目录、容器目录和lost+found；坏软链接主要属于软件依赖。4份不按JSONL编码的候选属于TempoMed/CounterFact数据，已记录，未作为ASTER结果。系统软件目录、虚拟环境、依赖包和Git对象实体不递归搜索；Git内容通过引用树检查。')
    add()
    table(['路径简称','服务器绝对路径'],[(f'`{k}`',f'`{v}`') for k,v in aliases.items()])
    add('下文“简称/相对路径”拼接后为精确服务器路径。哈希均为完整SHA256。审计附件提供精确缺失case、路径与UID清单；不含原始临床提示或患者文本。')
    add()
    add('## 2. 当前E1协议与版本核查')
    add()
    add('E1规范化训练清单实际为2,540对，A/P/C/F各635；拟合80来源、开发20来源、受控测试40来源。五IT及两Base均有冻结的M1/M2/M3。参数为各检查点独立选择的51头、16维、λ=0.01、δ=0.2923349。A/P权重合计4,887为损失归一化权重，不是旧版4,887个A/P训练对。')
    add()
    add('规范化清单`Q/data/E1_pairs.jsonl`与包含原文的`/home/gcx/aster_cr_pair_dataset_20261111/balanced_train.jsonl`采用不同表示；样本角色、类别和来源对应E1。`F/models/E1/full`的五个参数文件与`Q/models/E1/full`逐字节相同，F目录中的这个E1对照可复用。F的其他混合来源模型单独保留。')
    add()
    add('| 文件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for p in [Q/'data/E1_pairs.jsonl',pathlib.Path('/home/gcx/aster_cr_pair_dataset_20261111/balanced_train.jsonl'),Q/'data/path_features.jsonl',Q/'data/path_interference_views.jsonl',pathlib.Path('/home/gcx/aster_next_20261109/inventory/official_all_path_cases.jsonl')]:add(frow(p))
    add()
    add('评分保持原检查点模板：最后提示token的“是/否”单token分数，BF16主干、FP32标签投影，取是减否的logit差，判定阈值为0；Gemma2保留原生softcap。IT使用各自聊天模板，Base使用配置中记录的原生completion模板。未把旧提示、旧M3或旧头集合产生的修正分数记作当前结果。')
    add()
    table(['检查点','上游不可变revision','本地证据与追溯状态'],[(names[m],ident[m]['revision'] or '未找到', 'Base清单及分词器小文件与固定revision记录一致' if m=='qwen_base' else 'NEEDS_VALIDATION：本地权重路径/清单/模板可定位，上游revision未确认') for m in names])
    add('模型权重分片清单、大小和已有哈希来源、分词器及配置文件本轮SHA256均保存在`model_identity.json`。Qwen IT使用历史权重哈希记录；Gemma2 Base/IT保留上一轮已实际计算的分片哈希。其余下载清单中的revision/hash缺项如实保留，未用可变分支名推测不可变revision。所有完成项的“本地E1计算完整性”和“上游版本追溯”分别列出；追溯缺项不自动生成重训任务。')
    add()
    add('五IT参数、冻结记录、种子、来源清单、M1头集合、M2数组形状、M3配置及独立截距文件见`protocol_current.json`。本地参数哈希见下表；每行参数目录还包含`m1.json`、`m3.json`、`model.json`，完整哈希在`artifact_sha256_registry.json`。')
    add()
    table(['模型','参数目录','m2.npz SHA256','m3.npz SHA256'],[(names[m],f"`{short((Q if m=='qwen' else R/'models'/m)/'models/E1/full')}`",f"`{reg[str((Q if m=='qwen' else R/'models'/m)/'models/E1/full/m2.npz')]['sha256']}`",f"`{reg[str((Q if m=='qwen' else R/'models'/m)/'models/E1/full/m3.npz')]['sha256']}`") for m in names])
    add('当前源任务独立截距来自761个MEGA拟合节点、80个fit来源。Qwen的冻结b₀=3.0993948961894406，`D/configs/independent_intercepts_reused.json`的761个ID均能映射到源任务fit自然节点，`target_task_fit=false`。四个非Qwen模型现存迁移逐例的独立截距分数与raw+b₀的最大差为0。')
    add()
    add('## 3. E6逐项结论与实际预测计数')
    add()
    table(['模型/目标','当前结果状态','已保存的raw / 截距 / E1唯一路径','来源','缺失路径','处理'],[
      ['Qwen IT 官方7458','NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH','0 / 0 / 0',0,7458,'当前E1补充评价；历史完整结果另列HISTORICAL_ONLY'],
      ['Gemma2 IT 官方7458','PARTIAL_CURRENT','2379 / 2379 / 2379',115,5079,'保留已有分片与未完成路径的6个节点，接续'],
      ['Gemma3 受控806','PARTIAL_CURRENT','0 / 0 / 0',0,806,'兼容缓存可遍历三方法各806；CPU重建'],
      ['Gemma3 官方7458','NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH','0 / 0 / 0',0,7458,'当前E1补充评价；历史结果HISTORICAL_ONLY'],
      ['MedGemma 受控806','PARTIAL_CURRENT','0 / 0 / 0',0,806,'兼容缓存可遍历三方法各806；CPU重建'],
      ['MedGemma 官方7458','NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH','0 / 0 / 0',0,7458,'当前E1补充评价；历史结果HISTORICAL_ONLY']])
    add('六单元均完成跨工作树、分片、归档、缓存、日志与Git引用检索。没有找到另一份完整当前E1官方预测或Gemma2剩余分片。目标分母：受控806路径/40来源，官方7,458路径/418来源。当前结果缺失与旧协议完成分开记录。版本追溯缺项见第2节。')
    add()
    table(['已有完整评价','raw正确数','独立截距正确数','E1正确数','每方法路径/来源'],[(names[x['model']]+' '+('受控' if x['scope']=='test' else '官方'),x['methods']['raw']['correct_recount'],x['methods']['calibration' if x['scope']=='test' else 'bias_only']['correct_recount'],x['methods']['E1' if x['scope']=='test' else 'aster_cr']['correct_recount'],f"{x['target_paths']}/{x['target_sources']}") for x in e6 if all(v['unique_paths']==x['target_paths'] for v in x['methods'].values())])
    add('以上均重新读取逐例文件计数，并将保存的路径/终点与数据清单中的gold路径/终点比较：现存完整E6记录的正确标记差异为0，重复路径为0。Qwen受控独立截距来自`D/predictions/test/paths.jsonl.gz`。Qwen Base官方结果属于Base，原`qwen_mega_parallel`目录不能用作Qwen IT完成证据。')
    add()
    add('### 3.1 两款27B的新增缓存复用证据')
    add()
    table(['检查','Gemma3','MedGemma'],[
      ['原计划已映射的自然候选UID',761,761],
      ['旧路径缓存新增可复用UID',reuse['gemma3']['additional_natural_uids'],reuse['medgemma']['additional_natural_uids']],
      ['合并后的自然缓存UID',reuse['gemma3']['available_natural_uids'],reuse['medgemma']['available_natural_uids']],
      ['三方法可完整遍历的自然路径','806 / 806 / 806','806 / 806 / 806'],
      ['实际路径首个缺失UID',0,0],
      ['旧/当前病例、指南、定义、gold结构一致',806,806],
      ['重叠缓存raw分数核对','755条，最大差0','740条，最大差0']])
    add('新增缓存位于`OLD5/{gemma3,medgemma}/mega/paths/nodes.jsonl`及其`node_*.npz`。数组包含62×32×128全头激活和5376维最终残差；对应metadata在模型路径、分词器模板、答案token、BF16/FP32评分、激活位置和attention实现上与当前记录一致。原先3,100条全头视图缓存中，当前选中头及raw分数也已逐文件检查可读、有限。')
    add()
    add('审计只在内存中使用冻结参数检查分支能否由现有缓存走完，输出覆盖数量及缺失ID，没有生成新实验预测、正确率或区间。所有实际访问节点均有兼容缓存。E6受控单元按本次指定的806条自然路径及已有配对指标验收。')
    add()
    add('执行时需要按访问节点读取缓存的CPU包装脚本。现有`evaluate_model(test)`会先要求完整候选节点集合；直接调用会把未访问节点也当作缺失。计划复用其冻结评分和统计函数，使用`cache_maps/e6_*_additional_fullhead_nodes.jsonl`补充索引，再遍历实际分支。两模型各11,662/11,651个未缓存自然候选节点均未被这三种冻结评分访问，无需为本单元补前向。')
    add()
    add('| 关键缓存/部分结果 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for p in [R/'models/gemma2/evaluation/mega_official/shard0/path_predictions.jsonl',R/'models/gemma2/evaluation/mega_official/shard0/nodes.jsonl',pathlib.Path(aliases['OLD5'])/'gemma3/mega/paths/nodes.jsonl',pathlib.Path(aliases['OLD5'])/'medgemma/mega/paths/nodes.jsonl'] :add(frow(p))
    add()
    add('### 3.2 官方评价的确切接续范围')
    add()
    table(['模型','剩余路径','首批路径起点唯一UID','缺失金标准节点唯一前向','可复用未完成路径节点','旧缓存缺当前头数'],[(names[m],x['pending_paths'],x['unique_missing_root_forwards'],x['unique_missing_gold_forwards'],x['pending_gold_nodes_already_cached'],len(x['missing_selected_heads_in_historical'])) for m,x in official.items()])
    add('沿用现有官方评价的金标准自然节点及动态路径统计：四任务共有167,453个已知缺失金标准节点请求；路径首次访问节点去重为27,452个。分支产生的额外节点按需追加，三种方法共享同一次原模型前向及当前51头。Gemma2已有15,363个当前节点缓存，其中6个属于尚未完成的下一条路径。')
    add()
    add('已逐个检查旧官方索引引用的特征容器：Qwen 45,098、Gemma2 46,408、Gemma3 46,232、MedGemma 46,100个官方自然输入缓存均采用历史选头数组；缺当前头分别9、7、11、2个。可保留历史raw及旧协议比较，当前修正需要补取所需头。缺头列表和原参数文件哈希见`e6_official_queue_audit.json`。')
    add()
    add('缺失路径ID保存在`missing_ids/e6_{model}_{scope}_{method}.jsonl`；已完成单元的缺失表为空，重复ID列表为空。官方起点、金标准节点、完整候选节点分别保存在`e6_*_official_initial_root_nodes.jsonl`、`e6_*_official_initial_gold_nodes.jsonl`、`e6_*_official_candidate_nodes.jsonl`。完整候选数为上限，不是一次性前向清单。')
    add()
    add('## 4. E5逐项状态与节点去重')
    add()
    table(['方法/种子','状态','自然路径正确/806','已保存干扰路径','缓存可走完/2418','首批缺失UID'],[(x['method'],'PARTIAL_CURRENT',x['natural_correct_flags'],x['saved_interference_predictions'],x['traversable_from_existing_scores'],x['first_missing_unique_uids']) for x in e5['methods']])
    add('上述14行（13个前向方法加CC）均已有完整自然路径、2,339个配对记录、A/P与C/F指标、纠正/新增错误、来源95%区间和自然路径相对raw的配对差值区间。自然路径均为806唯一case/40来源，重复、执行错误和正确标记差异均为0。配对总体保持A/P=2,293、C/F=40，F0=6另列。无需重复计算已经完备的自然路径前向。')
    add()
    add('13行所需的干扰候选UID联合去重后为50,022个，每行已保存的修正分数覆盖2,283个，缺失候选UID联合为47,739个。raw缓存覆盖50,022/50,022，新增raw评分任务为0。按当前分支推到第一个未知节点后，13行第一批请求涉及2,387个唯一UID、30,855个“方法/种子×UID”评分请求。')
    add()
    add('同一方法/种子的重复UID只计算一次。不同方法或随机种子的修正结果独立保存；47,739个输入不能当成所有方法共用的一次修正前向。全候选上限为620,607个方法/种子节点请求，实际执行沿树逐批扩展，访问结束即停止。精确清单见`missing_ids/e5_unique_candidate_nodes.jsonl`及每行的`e5_*_first_missing.jsonl`。')
    add()
    add('SEA另需最后Transformer层输出、最终norm之前的原始残差。已检查E1原始特征、INLP的原始残差和E5 truth_features；47,739个缺修正分数的候选节点中，可直接使用的最终残差为0。INLP test的3,100份残差对应已有视图，未补足这些缺失节点。已有attention heads不能替代SEA最终残差；SEA沿实际访问节点补取残差并复用冻结算子。')
    add()
    add('CC冻结offset=-1.0324354956866095；本轮复查3,100份已有输入分数，均精确等于raw+offset。全部候选raw可用，干扰路径与统计转为CPU。原`e1_prompt_controls.py:main()`会加载Engine，CPU补算应使用独立包装脚本。')
    add()
    add('### 4.1 修复后参数与11行已完成外部方法')
    add()
    add('LoRA复用学习率0.001；LoFiT/LoReFT复用0.0001；三方法均保留11、22、33种子和4,637个训练端点。LoReFT正式适配器读取结果有限且非零，记录的旋转参数更新L2为0.457101、0.463157、0.468976，旋转范数约1。旧零旋转适配器和旧失败smoke记为FAILED，不进入接续计划。PSR seed22已有4,475个训练步、参数变化L2=0.5425931811；其预测与raw相同属于已完成结果。')
    add()
    table(['新增方法/种子','计算状态','自然正确/806','干扰正确/2418','剩余'],[(x['method'],'PARTIAL_CURRENT：前向完整',x['path_groups']['natural']['correct_flags'],x['path_groups']['interference']['correct_flags'],'CPU补两总体相对raw配对差值区间') for x in e5['external_11_rows']])
    add('11行均有自然806、干扰2418、40来源，方法自身的指标区间已保存。新增差值区间必须按同一来源抽样索引同时重算方法和raw，再相减；不采用两套独立抽样的区间相减。对应输入为`EXT/evaluation/test/{method}/path_predictions.jsonl`和`Q/evaluation/test/path_predictions.jsonl`。')
    add()
    add('温度、E1端点截距、仿射、监督线性读出已有完整自然/干扰评价，保存在`E5/output_controls_e1/evaluation/test/`。原模型、固定缩放和E1参照均复用。完成产物本地E1协议一致；上游revision待追溯的项标记NEEDS_VALIDATION，不加入GPU队列。')
    add()
    add('## 5. E7二十个目标单元')
    add()
    rr=[]
    for x in e7:
        m=x['model'];s=x['scope'];cc=x['correct_recount'];intercept=cc.get('calibration',66 if m=='qwen' and s=='medpic' else '待CPU')
        status='PARTIAL_CURRENT' if m=='qwen' and s!='medpic' else 'NEEDS_VALIDATION（计算已完整，追溯待补）'
        rr.append([names[m],s,x['target'],f"{cc.get('raw')} / {intercept} / {cc.get('E1')}",x['views'],next(iter(x['population_sources'].values())),status])
    table(['模型','总体','目标分母','raw/独立截距/E1正确数','视图数','来源簇','状态'],rr)
    add('所有目标总体已有前向。四个非Qwen模型的16个单元均有三方法逐例及区间，逐例截距恒等式核查通过。Qwen MedPIC188的独立截距和95%区间保存在`D/predictions/medpic_test/`，只补版本说明。Qwen其他三单元从已有raw和冻结源截距补统计，不重新加载主干。')
    add()
    add('NLI500包含500原声明和共2,864视图；NLI5500含5,500声明。NLI5500旧`natural_*`部分字段的分母是500，完整总体正确数已按5,500逐例重计。MedPIC188为2,820含扰动选项视图；Qwen MedPIC467保存7,005视图，其中原始选项2,335；其他模型的MedPIC467保存原始2,335选项。')
    add()
    add('**统计口径待用户确认：** NLI500现有113个“临床试验或试验组合”簇，NLI5500现有500个“原始声明及其变体”簇。可分别沿用并明确标注，也可在确认后统一到临床试验/组合。两项新NLI区间不在确认前计算。MedPIC188/467分别为150/376来源；467含开发题，保留描述性评价标注。目标测试标签从未用于本计划的截距拟合或选参。')
    add()
    add('## 6. E8 Base/IT追溯')
    add()
    table(['比较','状态','Base/IT头数','交集/并集','Jaccard','剩余'],[(k,'NEEDS_VALIDATION',f"{v['base_heads']}/{v['it_heads']}",f"{v['intersection']}/{v['union']}",f"{v['jaccard']:.10f}",'模型/分词器上游revision追溯；不拟合') for k,v in e8.items()])
    add('两组比较的头集合、M2子空间、谱与有效秩产物已存在，比较文件与归档一致。本轮重计头交集与并集相符。Qwen Base确认固定revision；Qwen IT及Gemma2两侧不可变revision未查明，明列在`model_identity.json`。未找到同一训练链的SFT/RL中间检查点，结论保持Base/IT端点比较。阶段因果归因及新增中间检查点研究记为OPTIONAL，本轮无任务。')
    add()
    add('| 比较文件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for fam in ['qwen','gemma2']:add(frow(R/'base_it'/fam/'comparison.json'))
    add()
    add('## 7. A–D分类：复用、归档、接续与无有效结果')
    add()
    add('### A. 计算已完成，无需再运行')
    add()
    add('五IT和两Base的E1拟合/开发/冻结；Qwen/Llama/Gemma2的受控806；Llama、Qwen Base、Gemma2 Base的官方7458；E7所有模型前向及四个非Qwen模型的全量统计；E8两组比较；E5所有已训练适配器、自然路径、四个输出控制和11行新增方法完整前向。版本缺项统一保留NEEDS_VALIDATION，已完成计算不得因此重跑。')
    add()
    add('### B. 已完成但尚未上传的产物')
    add()
    add('Qwen NLI5500与MedPIC467的7份关键逐例/指标文件合计51,423,608字节，服务器存在，指定归档未包含这些完整逐例。其中raw/E1计算产物为COMPLETE_NOT_ARCHIVED，整个三方法单元因缺独立截距统计仍为PARTIAL_CURRENT。建议归档到`reports/aster_final_gap_completion_20261114/e7/qwen/{nli5500,medpic467}/`，先补齐三方法及统计再统一提交。')
    add()
    add('| 服务器文件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for sc,ns in [('nli4ct_official5500',['predictions.jsonl','pair_predictions.jsonl','metrics.json']),('medpic_official467',['predictions.jsonl','pair_predictions.jsonl','question_predictions.jsonl','metrics.json'])]:
        for n in ns:add(frow(F/'evaluation'/sc/n))
    add()
    add('SEA算子、DoRA三个适配器、选中INLP投影及Qwen Base下载清单也有服务器原件可补充参数归档；大缓存保留服务器，并提交清单和引用。Gemma2官方7,137行部分路径预测尚未归档，应先保留，再与接续结果按ID合并。新发现的两27B全头路径缓存同样保留原位，通过本轮映射清单复用。')
    add()
    add('| 参数原件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for p in [E5/'representation_e1_plan/sea_adaptation/operator.pt',*[(EXT/'dora/full'/('seed'+str(s))/'adapter/adapter_model.safetensors') for s in [11,22,33]],EXT/'inlp/iterations_1/projection.npz',pathlib.Path('/home/gcx/TRIAGE-worktrees/aster-seka-execution-20261025/experiments/aster_seka_execution/qwen_base_download_manifest_v2.json')]:add(frow(p))
    add()
    add('### C. 部分完成，接续即可')
    add()
    add('Gemma2官方缺5,079路径；两27B受控缺当前预测导出与统计，兼容缓存已足；E5十三行缺干扰路径结果，CC缺CPU导出；11行新增方法缺相对raw差值区间；Qwen三个迁移单元缺独立截距统计。缺失UID、路径ID、可复用缓存及输出位置已写入`MINIMAL_EXECUTION_PLAN.json`和`missing_ids/`。')
    add()
    add('### D. 全面搜索后未发现当前有效结果')
    add()
    add('Qwen IT、Gemma3、MedGemma的当前E1官方7458评价：NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH。三个模型各自有HISTORICAL_ONLY完整旧协议结果，旧M3/头集合不能直接充当当前修正结果。E5十三行的完整干扰路径预测未发现；其方法整体已有当前训练与自然结果，按PARTIAL_CURRENT接续。此状态表示未找到当前有效产物，不推断服务器过去从未尝试运行。')
    add()
    add('## 8. E–F最小执行计划、资源与验收')
    add()
    add('### E. CPU任务')
    add()
    table(['编号','任务','输入','实施与预期输出'],[(c['id'],c['unit'],'；'.join('`'+short(x)+'`' for x in c['inputs']),c['implementation']+'。输出：`'+c['output']+'`') for c in cpus])
    add('CPU工作预计1–3小时，按8–16线程、约8–16 GiB内存安排。使用现有2,000次来源bootstrap配置和既有种子；每个对比共享抽样来源索引。全部CPU补实验同样等待用户批准，本轮仅计数、检查兼容性及生成清单。')
    add()
    add('### F. GPU任务')
    add()
    table(['编号','任务','模型加载/激活','GPU/显存','预计GPU小时','结果目录'],[(g['id'],names[m]+' 官方接续',g['new_activation_required'],'1张，'+str(g['vram_gib'][0])+'–'+str(g['vram_gib'][1])+' GiB',str(g['estimated_gpu_hours'][0])+'–'+str(g['estimated_gpu_hours'][1]),'`'+g['output']+'`') for g,m in zip(gpu[:4],['qwen','gemma2','gemma3','medgemma'])]+[['G05–G17','E5十三行干扰路径','复用Qwen主干驻留与冻结参数；方法/种子分数独立，SEA补最终残差','每任务1张，18–28 GiB','合计8–14','`reports/aster_final_gap_completion_20261114/e5/{method}/`']])
    add('允许资源固定为GPU **0、1、5、6**，均为A100-SXM4-80GB。建议首轮分配：Qwen官方→0，Gemma2官方→1，Gemma3官方→5，MedGemma官方→6；完成后释放卡给E5队列。只使用一个统一调度器，每卡一个任务，最多四个已协调任务。旧队列允许列表含GPU4，新增计划显式采用0/1/5/6，不继承GPU4。')
    add()
    add('总量约32–46 GPU小时；四卡协调执行预计12–18小时墙钟时间。估算来自已有记录：Qwen约0.18–0.25秒/节点、Gemma2部分官方约0.61秒/节点、Gemma3约0.60秒/节点、MedGemma约0.56–0.59秒/节点，E5原生自然路径任务约0.21–0.22秒/输入。时长包含合理的分支追加和I/O余量，不包含新训练或下载。实际访问节点数在推理过程中确定；候选全树UID不会全部预提交。')
    add()
    add('当前没有模型驻留GPU，因此首次GPU任务需加载现有本地检查点；后续同卡Qwen任务可连续复用主干。原始节点分数、当前参数、已完成分片与合法全头缓存均复用。GPU任务启动后确认稳定即停止持续监控，由队列保留日志和完成标记。')
    add()
    table(['任务','完成验收'],[(c['id'],c['acceptance']) for c in cpus]+[['G01–G04','逐例三方法各7458、418来源；原部分结果逐字节保留；无重复/缺失ID；原始/独立截距/E1同一分母；参数冻结与模板保持一致。'],['G05–G17','每方法/种子自然806、干扰2418、40来源；同方法UID不重复前向；已修复适配器生效；追加节点与方法参数一一对应。'],['归档','压缩逐例分数/预测、配置、参数清单、来源配对95%区间、图表及报告；不公开原始临床提示、患者文本或带prompt的节点缓存；获准后再GitHub提交。']])
    add('计划文件中所有新计算任务的准入状态均为PARTIAL_CURRENT或NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH。NEEDS_VALIDATION版本事项为追溯任务，HISTORICAL_ONLY结果不重复报告为当前完成，OPTIONAL扩展不进入本队列。')
    add()
    add('## 9. 进程、队列及旧状态误判')
    add()
    add(f"快照时间：{runtime['snapshot_utc']}（北京时间13:17:38）。GPU0/1/5/6均无计算进程，显存占用记录为0。统一队列`completed_with_cancellations`，完成46、取消3、pending/running/failed/blocked均0；旧调度器PID {runtime['scheduler_pid']}已不存在。")
    add()
    table(['旧记录','本轮依据','正确处理'],[
      ['Gemma3/MedGemma run_status=stopped_by_user','后续dev、冻结、四目标迁移逐例与指标均存在','这些已完成阶段不重跑；受控自然路径转CPU；官方当前评价继续列缺失。'],
      ['Llama官方shard status仍为running','done.json及三方法各7458完整逐例','计算完成，停止状态不能盖过逐例证据。'],
      ['Qwen Base shard0仍为running','五个resume分片并集与原分片完整覆盖7458，三方法无重复','Base官方已完成；不再按旧分片状态重跑。'],
      ['Gemma2停止记录','2379完整路径及下一路径6个节点，未见其余分片','PARTIAL_CURRENT，精确接续。'],
      ['LoReFT旧失败记录','final有效性记录、三个非零旋转适配器及正式预测','旧适配器FAILED，修复后训练已完成。'],
      ['PSR seed22预测等于raw','训练步及参数变化L2均存在','已完成，保留该种子。']])
    add('旧状态文件原样保留。当前有效RUNNING实验任务为0。本轮没有恢复被取消的旧全流程，也没有创建活动GPU队列。')
    add()
    add('## 10. 各单元主要文件与SHA256')
    add()
    add('以下提供逐项结果入口；完整配置、冻结参数、模型版本、分片及缓存清单见`artifact_sha256_registry.json`，物理/解压内容对应关系见`publication_prediction_mapping.json`和`prediction_duplicate_groups.jsonl`。157份同路径文本/参数文件与发布树SHA256相同，83份已登记逐例文件与发布树解压内容相同；空文件不作为完成证据。')
    add()
    add('### E6现存路径文件')
    add()
    add('| 文件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    seen=set()
    for x in e6:
        for f in x['files']:
            if f['path'] not in seen:seen.add(f['path']);add(frow(f['path']))
    add()
    add('### E5每行自然路径与11行全路径文件')
    add()
    add('| 文件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for x in e5['methods']:add(frow(pathlib.Path(x['root'])/'test_path_predictions.jsonl'))
    for x in e5['external_11_rows']:add(frow(pathlib.Path(x['root'])/'path_predictions.jsonl'))
    add(frow(E5/'output_controls_e1/evaluation/test/path_predictions.jsonl'))
    add()
    add('### E7每个总体的逐视图分数文件')
    add()
    add('| 文件 | 字节 | SHA256 |');add('| --- | ---: | --- |')
    for x in e7:
        for f in x['files']:
            if pathlib.Path(f['path']).name=='predictions.jsonl':add(frow(f['path']))
    add(frow(D/'predictions/medpic_test/questions.jsonl.gz'))
    add(frow(D/'configs/independent_intercepts_reused.json'))
    add()
    add('历史路径文件逐片计数及SHA256在`historical_prediction_recount.json`；它们的评价范围可能同时包含420开发、806受控和7458官方，官方结果按`evaluation_group=official_test`区分。旧五模型15组、MedEinst混合来源模型和旧M3均保留原身份。')
    add()
    add('## 11. 最终答复与批准事项')
    add()
    table(['必须回答的问题','结论'],[
      ['哪些确实未完成？','三个IT的当前E1官方完整评价、Gemma2剩余5079、两27B受控当前文件/统计、E5十三行干扰路径、CC导出、11行差值区间、Qwen三个迁移截距统计。'],
      ['哪些只是没有上传？','Qwen NLI5500与MedPIC467已有raw/E1逐例；部分冻结参数、下载清单及服务器缓存。整个三方法单元仍需补统计。'],
      ['哪些被旧状态误判？','两27B后续开发/冻结/迁移、Llama官方、Qwen Base官方续片；LoReFT修复后训练与PSR seed22均已完成。'],
      ['哪些只有部分结果？','Gemma2官方2379/7458；E5十三行自然路径完整、干扰只覆盖少量可遍历缓存；Qwen三项迁移已有raw/E1。'],
      ['哪些CPU即可？','两27B受控806、CC2418、11行相对raw区间、Qwen NLI500/NLI5500/MedPIC467独立截距统计、归档与E8追溯。'],
      ['哪些需要GPU？','四个官方E6接续单元；E5十三行实际访问的未知方法分数，其中SEA需要最终残差。'],
      ['哪些完全不应再运行？','全部既有M1/M2/M3与基线训练；E6完整评价；所有E7前向；两组E8拟合/比较；E5自然路径和11行完整前向；LoReFT旧失败流程、PSR seed22训练；既有E0–E4、E9–E11不扩大本轮范围。']])
    add('**审计完成后停止。等待用户批准`MINIMAL_EXECUTION_PLAN.json`，并确认NLI聚类口径。** 批准后依次处理CPU缺项、E6官方前向、E5干扰前向、逐例复算/来源配对区间和归档提交。')
    add()
    add('附：状态统一使用COMPLETE_CURRENT、COMPLETE_NOT_ARCHIVED、PARTIAL_CURRENT、HISTORICAL_ONLY、RUNNING、FAILED、NEEDS_VALIDATION、NOT_FOUND_AFTER_EXHAUSTIVE_SEARCH、OPTIONAL。COMPLETE_CURRENT用于计算和所需身份均已可确认的单元；其余已完成计算若缺上游版本，保留NEEDS_VALIDATION，不将追溯缺项等同为缺实验。')
    (OUT/'ASTER_FINAL_MISSING_EXPERIMENTS_AUDIT.md').write_text('\n'.join(b)+'\n',encoding='utf-8')
    (OUT/'artifact_sha256_registry.json').write_text(json.dumps(list(reg.values()),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'report_bytes':(OUT/'ASTER_FINAL_MISSING_EXPERIMENTS_AUDIT.md').stat().st_size,'gpu_jobs':len(gpu),'cpu_jobs':len(cpus),'training_jobs':0,'downloads':0,'state':plan['status']}))

if __name__=='__main__':main()
