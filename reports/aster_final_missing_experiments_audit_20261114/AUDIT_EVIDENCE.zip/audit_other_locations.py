import collections,csv,gzip,hashlib,io,json,os,pathlib,re,subprocess,sys
from audit_search import OUT,inventory,sha,classify

def formats():
    csvhits=[];gziphits=[];seen={};errors=[];count=collections.Counter()
    for f in inventory():
        p=f['path']
        if not any(s in p for s in ['aster','TRIAGE']):continue
        if p.endswith('.csv'):
            count['csv_checked']+=1
            try:
                with open(p,encoding='utf-8-sig') as h:
                    reader=csv.DictReader(h);keys=reader.fieldnames or []
                    if not ('case_id' in keys and any(k in keys for k in ['correct','path_correct','predicted_path','predicted_leaf'])):continue
                    digest=sha(p)
                    if digest in seen:csvhits.append(dict(f,sha256=digest,duplicate_of=seen[digest]));continue
                    seen[digest]=p;counts=collections.Counter();ids=collections.defaultdict(set);src=collections.defaultdict(set)
                    for row in reader:
                        k=str(row.get('method','unspecified'))+'|'+str(row.get('variant','unspecified'));counts[k]+=1;ids[k].add(row.get('case_id'));src[k].add(row.get('source_id'))
                    csvhits.append(dict(f,sha256=digest,keys=keys,groups={k:{'rows':v,'unique_cases':len(ids[k]),'sources':len(src[k])} for k,v in counts.items()}))
            except Exception as e:errors.append({'path':p,'error':str(e)})
        elif p.endswith('.gz') and not p.endswith(('.tar.gz','.jsonl.gz','.ndjson.gz')):
            count['other_gzip_checked']+=1
            try:
                b=gzip.open(p,'rb').read();digest=hashlib.sha256(b).hexdigest()
                if digest in seen:gziphits.append(dict(f,content_sha256=digest,duplicate_of=seen[digest]));continue
                seen[digest]=p
                terms=[x for x in ['E1-balanced-2540','0.2923349','loreft','lofit','sea_adaptation','nli4ct_official5500','medpic_official467'] if x.encode() in b]
                x={'path':p,'sha256':sha(p),'content_sha256':digest,'size':f['size'],'terms':terms}
                try:
                    obj=json.loads(b);x['json_type']=type(obj).__name__;x['keys']=list(obj)[:40] if isinstance(obj,dict) else None
                    if isinstance(obj,list):x['rows']=len(obj);x['first_row_kind']=classify(obj[0]) if obj else None
                except Exception:x['format']='non-single-JSON (CSV, text or JSONL)'
                gziphits.append(x)
            except Exception as e:errors.append({'path':p,'error':str(e)})
    for n,v in [('other_csv_predictions.json',csvhits),('other_gzip_inspection.json',gziphits),('other_format_errors.json',errors)]: (OUT/n).write_text(json.dumps(v,indent=2))
    (OUT/'other_format_summary.json').write_text(json.dumps(dict(count,csv_result_files=len(csvhits),gzip_result_files=len(gziphits),errors=len(errors)),indent=2))
    print(json.dumps(dict(count,csv_result_files=len(csvhits),gzip_result_files=len(gziphits),errors=len(errors))))

def scopes():
    roots=['/srv','/opt','/var/backups','/backup','/backups','/workspace','/workspaces'];errors=[];files=[]
    for root in roots:
        if not os.path.isdir(root):continue
        for dp,ds,fs in os.walk(root,onerror=lambda e:errors.append(str(e)),followlinks=False):
            ds[:]=[d for d in ds if d not in ['node_modules','site-packages','__pycache__']]
            for name in fs:
                p=os.path.join(dp,name)
                try:
                    st=os.stat(p)
                    if st.st_uid==os.getuid() or any(x in p.lower() for x in ['aster','triage','gemma','qwen']):files.append({'path':p,'size':st.st_size,'uid':st.st_uid})
                except OSError as e:errors.append(str(e))
    repos=set()
    for f in inventory():
        p=f['path']
        if p.endswith('/.git'):repos.add(p[:-5])
        if p.endswith('/.git/HEAD'):repos.add(p[:-10])
    known={x['path'] for x in json.loads((OUT/'worktree_status.json').read_text())};other=[]
    for p in sorted(repos-known):
        if not any(s in p for s in ['aster','TRIAGE','gemma','medgemma']):continue
        if any(s in p for s in ['/vendor/','/official/','/runtime/vendors/']):continue
        def git(*args):return subprocess.run(['git','--no-optional-locks','-C',p,*args],capture_output=True,text=True).stdout.strip()
        other.append({'path':p,'head':git('rev-parse','HEAD'),'status':git('status','--porcelain=v1','--untracked-files=all').splitlines()})
    history=pathlib.Path('/home/gcx/.bash_history');refs=[]
    if history.exists():
        for l in history.read_text(errors='replace').splitlines():
            if any(x in l.lower() for x in ['aster','triage','gemma','e678','loreft','lofit']):
                refs.extend(re.findall(r'/(?:home|tmp|data|mnt|srv|opt)/[A-Za-z0-9_./-]+',l))
    bundles=[]
    for f in inventory('archives_inventory.jsonl'):
        if f['path'].endswith('.bundle'):
            p=subprocess.run(['git','bundle','list-heads',f['path']],capture_output=True,text=True);bundles.append({'path':f['path'],'heads':p.stdout.splitlines(),'returncode':p.returncode})
    result={'additional_roots':roots,'files':files,'errors':errors,'additional_repositories':other,'history_experiment_paths':sorted(set(refs)),'git_bundles':bundles}
    (OUT/'additional_search_scope.json').write_text(json.dumps(result,indent=2));print(json.dumps({'extra_files':len(files),'extra_repos':len(other),'errors':len(errors),'bundles':len(bundles)}))

def refs():
    refs=[l.split()[:2] for l in (OUT/'git_refs.txt').read_text().splitlines()];seen={};out=[];git=['git','--no-optional-locks','-C','/home/gcx/aster-results-publish-20261114']
    pat=re.compile(r'(aster_e678_20261112|aster_e5_gaps_20261112|nli4ct_official5500|medpic_official467|mega_official|aster_cr_final_method_10006)')
    for name,commit in refs:
        if commit in seen:out.append({'ref':name,'commit':commit,'same_commit_as':seen[commit]});continue
        seen[commit]=name;p=subprocess.run(git+['ls-tree','-r','--name-only',commit],capture_output=True,text=True)
        files=[x for x in p.stdout.splitlines() if pat.search(x)]
        out.append({'ref':name,'commit':commit,'matching_files':files,'returncode':p.returncode})
    (OUT/'git_ref_artifact_inventory.json').write_text(json.dumps(out,indent=2));print(json.dumps({'refs':len(refs),'unique_commits':len(seen),'with_matching_files':sum(bool(x.get('matching_files')) for x in out)}))

if __name__=='__main__':{'formats':formats,'scopes':scopes,'refs':refs}[sys.argv[1]]()
