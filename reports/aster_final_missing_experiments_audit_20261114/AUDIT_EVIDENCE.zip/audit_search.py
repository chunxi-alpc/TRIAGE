"""Read-only artifact discovery. Writes only into the separate audit directory."""
import argparse, collections, concurrent.futures, gzip, hashlib, io, json, os, pathlib, re, subprocess, tarfile, zipfile

OUT = pathlib.Path('/home/gcx/aster-final-missing-audit-20261114')

def inventory(name='inventory.jsonl'):
    with (OUT / name).open() as f:
        for line in f:
            yield json.loads(line)

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def classify(r):
    if not isinstance(r, dict): return None
    if 'case_id' in r and any(k in r for k in ('predicted_path', 'path', 'pred_path')) and any(k in r for k in ('correct', 'path_correct', 'success')): return 'paths'
    if any(k in r for k in ('view_id','uid','id')) and any(k in r for k in ('scores','score','ell','raw_score','logit','prediction','predictions')): return 'scores_views'
    if any(k in r for k in ('question_id','item_id')) and any(k in r for k in ('correct','predicted','predicted_options','predictions')): return 'questions'
    if 'pair_id' in r and any(k in r for k in ('scores','left_score','raw_diff','methods','score_left','correct')): return 'pairs'
    return None

def summarize_stream(f, first, kind):
    h=hashlib.sha256(); counts=collections.Counter(); uniques=collections.defaultdict(set); cases=collections.defaultdict(set); sources=collections.defaultdict(set); duplicates=collections.Counter(); correct=collections.Counter(); errs=collections.Counter(); scorekeys=collections.Counter(); bad=0; total=0; keylist=[]
    for line in __import__('itertools').chain([first], f):
        h.update(line)
        if not line.strip(): continue
        try: r=json.loads(line)
        except (ValueError, UnicodeError): bad+=1; continue
        if not isinstance(r,dict): bad+=1; continue
        total+=1
        if len(keylist)==0:keylist=list(r)
        method=str(r.get('method','embedded'));variant=str(r.get('variant',r.get('evaluation_group','unspecified')))
        group=method+'|'+variant
        counts[group]+=1
        rid=str(r.get('case_id',r.get('view_id',r.get('uid',r.get('question_id',r.get('id','row:'+str(total)))))))
        if rid in uniques[group]:duplicates[group]+=1
        uniques[group].add(rid)
        if 'case_id' in r:cases[group].add(str(r['case_id']))
        if 'source_id' in r:sources[group].add(str(r['source_id']))
        correct[group]+=int(r.get('correct',r.get('path_correct',False)) is True)
        if r.get('error') or r.get('status') in ('failed','error','unavailable'):errs[group]+=1
        if isinstance(r.get('scores'),dict):
            for m,v in r['scores'].items():
                if v is not None:scorekeys[m]+=1
    out={'kind':kind,'content_sha256':h.hexdigest(),'rows':total,'parse_errors':bad,'keys':keylist,'groups':{k:{'rows':v,'unique_ids':len(uniques[k]),'unique_cases':len(cases[k]),'sources':len(sources[k]),'duplicate_rows':duplicates[k],'correct_flags':correct[k],'errors':errs[k]} for k,v in counts.items()},'embedded_method_counts':dict(scorekeys)}
    if kind=='paths':out['path_ids']={k:sorted(v) for k,v in uniques.items()}
    return out

def inspect_file(f):
    p=f['path']
    try:
        opener=gzip.open if p.endswith('.gz') else open
        with opener(p,'rb') as stream:
            first=stream.readline()
            if not first.strip(): return None
            kind=classify(json.loads(first))
            if kind is None:return None
            result=summarize_stream(stream,first,kind)
        result.update(path=p,size=f['size'],mtime=f['mtime'],sha256=sha(p) if p.endswith('.gz') else result['content_sha256'])
        return result
    except Exception as e:return {'path':p,'error':type(e).__name__+': '+str(e)}

def scan_predictions():
    candidates=[f for f in inventory() if f['path'].endswith(('.jsonl','.jsonl.gz','.ndjson','.ndjson.gz')) and '/.git/' not in f['path'] and not any(s in f['path'] for s in ['/nltk_data/','/.cache/pip/'])]
    counts=collections.Counter()
    with (OUT/'all_prediction_files.jsonl').open('w') as w:
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            for r in pool.map(inspect_file,candidates):
                if r is not None:
                    w.write(json.dumps(r)+'\n');w.flush();counts[r.get('kind','error')]+=1
    (OUT/'prediction_scan_summary.json').write_text(json.dumps({'candidates':len(candidates),'counts':dict(counts)},indent=2))
    print(json.dumps({'prediction_scan':dict(counts),'candidates':len(candidates)}),flush=True)

def archives():
    seen={};summary=[]
    with (OUT/'archive_members.jsonl').open('w') as members, (OUT/'archive_predictions.jsonl').open('w') as predictions:
        for f in inventory('archives_inventory.jsonl'):
            p=f['path'];rec=dict(f)
            try:
                rec['sha256']=sha(p)
                if rec['sha256'] in seen:
                    rec['duplicate_of']=seen[rec['sha256']];summary.append(rec);continue
                seen[rec['sha256']]=p
                if p.endswith('.zip'):
                    arc=zipfile.ZipFile(p);entries=[(m.filename,m.file_size,m) for m in arc.infolist() if not m.is_dir()];get=lambda m:arc.open(m)
                elif p.endswith(('.tar','.tar.gz','.tgz','.tar.bz2','.tar.xz')):
                    arc=tarfile.open(p);entries=[(m.name,m.size,m) for m in arc.getmembers() if m.isfile()];get=lambda m:arc.extractfile(m)
                else:rec['format_note']='Git bundle or unsupported archive; listed separately';summary.append(rec);continue
                rec['members']=len(entries);rec['prediction_members']=0
                for name,size,member in entries:
                    members.write(json.dumps({'archive':p,'member':name,'size':size})+'\n')
                    if not name.endswith(('.jsonl','.jsonl.gz','.ndjson','.ndjson.gz')):continue
                    stream=get(member)
                    if name.endswith('.gz'):stream=gzip.GzipFile(fileobj=stream)
                    try:
                        first=stream.readline();kind=classify(json.loads(first)) if first.strip() else None
                        if kind:
                            x=summarize_stream(stream,first,kind);x.update(archive=p,member=name,size=size,archive_sha256=rec['sha256']);predictions.write(json.dumps(x)+'\n');rec['prediction_members']+=1
                    except Exception as e:predictions.write(json.dumps({'archive':p,'member':name,'error':str(e)})+'\n')
                    finally:stream.close()
                arc.close()
            except Exception as e:rec['error']=str(e)
            summary.append(rec)
    (OUT/'archive_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({'archives':len(summary),'unique':len(seen),'members':sum(r.get('members',0) for r in summary),'errors':sum('error' in r for r in summary)}),flush=True)

def metadata():
    terms=['E1-balanced-2540','0.2923349','2540','2,540','7458','7,458','5079','5,079','2379','2,379','2418','2,418','loreft','lofit','strong_evidence','sea_adaptation','qwen3-8b','gemma-3-27b','medgemma','nli4ct_official5500','medpic_official467','revision','sha256']
    seen={};count=0;hits=0
    with (OUT/'metadata_hits.jsonl').open('w') as w:
        for f in inventory('metadata_code_logs_inventory.jsonl'):
            p=f['path']
            try:
                data=pathlib.Path(p).read_bytes();digest=hashlib.sha256(data).hexdigest();count+=1
                if digest in seen:
                    found=seen[digest]
                else:
                    low=data.lower();found=[t for t in terms if t.encode() in low];seen[digest]=found
                if found:w.write(json.dumps(dict(f,sha256=digest,terms=found))+'\n');hits+=1
            except OSError as e:w.write(json.dumps({'path':p,'error':str(e)})+'\n')
    print(json.dumps({'metadata_files':count,'content_unique':len(seen),'hits':hits}),flush=True)

def worktrees():
    wt=json.loads((OUT/'worktrees_initial.json').read_text())['stdout'];paths=[line[9:] for line in wt.splitlines() if line.startswith('worktree ')]
    out=[]
    for p in paths:
        if not os.path.isdir(p):out.append({'path':p,'missing':True});continue
        q=subprocess.run(['git','--no-optional-locks','-C',p,'status','--porcelain=v1','--untracked-files=all'],text=True,capture_output=True)
        out.append({'path':p,'status':q.stdout.splitlines(),'error':q.stderr,'returncode':q.returncode})
    (OUT/'worktree_status.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'worktrees':len(out),'dirty':sum(bool(v.get('status')) for v in out)}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['predictions','archives','metadata','worktrees']);a=p.parse_args()
    {'predictions':scan_predictions,'archives':archives,'metadata':metadata,'worktrees':worktrees}[a.mode]()
