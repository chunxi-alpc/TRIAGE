"""CPU-only resumable download of the manuscript Gemma-2-9B-IT checkpoint."""
import json,os,time,traceback
from pathlib import Path
from modelscope import snapshot_download
ROOT=Path(__file__).resolve().parent
out=Path('/home/gcx/models/gemma-2-9b-it')
status=ROOT/'gemma2_download.json'
def write(value):
 status.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':
 os.environ['CUDA_VISIBLE_DEVICES']=''
 started=time.time();write(dict(state='downloading',model='google/gemma-2-9b-it',path=str(out),started=started))
 try:
  path=snapshot_download('google/gemma-2-9b-it',local_dir=str(out),ignore_file_pattern=['*.gguf','*.bin','*.pth','*.pt','original/*'])
  write(dict(state='complete',model='google/gemma-2-9b-it',path=path,seconds=time.time()-started))
 except BaseException as exc:
  write(dict(state='failed',error=str(exc),seconds=time.time()-started));traceback.print_exc();raise
