"""Two-GPU sequential job workers; stop using a GPU when its queue is empty."""
import argparse,json,os,subprocess,sys,time,fcntl
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ORDER=[('qwen','mega'),('llama31','mega'),('qwen','nli4ct'),('gemma2','mega'),('qwen','syllogism'),('llama31','nli4ct'),('llama31','syllogism'),('gemma3','mega'),('medgemma','mega'),('gemma2','nli4ct'),('gemma2','syllogism'),('gemma3','nli4ct'),('medgemma','nli4ct'),('gemma3','syllogism'),('medgemma','syllogism')]
def read(path):
 try:return json.loads(Path(path).read_text())
 except (FileNotFoundError,json.JSONDecodeError):return {}
def dump(path,value):
 p=Path(path);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');t.replace(p)
def ready(model,task):
 if not (ROOT/'data'/task/'views.jsonl').exists() or not (ROOT/'data'/task/'pairs.jsonl').exists():return False
 if task!='mega' and not (ROOT/'data'/task/'READY.json').exists():return False
 if model=='gemma2' and read(ROOT/'gemma2_download.json').get('state')!='complete':return False
 return (ROOT/'fit_evaluate.py').exists() and (ROOT/'engine.py').exists()
def summary(jobs):
 records=[]
 for m,t in ORDER:
  out=ROOT/'results'/m/t;s=read(out/'status.json');done=read(out/'done.json')
  r=dict(model=m,task=t,state=done.get('state',s.get('state','queued')),stage=s.get('stage'),selected_heads=None)
  sel=read(out/'selection.json')
  if sel:r['selected_heads']=len(sel.get('heads',[]))
  met=read(out/'metrics.json')
  if met:
   test=met.get('methods',{}).get('aster_cr',{}).get('splits',{}).get('test',{})
   r.update(test_AP=test.get('AP'),test_CF=test.get('CF'),test_natural=test.get('natural'))
  if (m,t) in jobs:r['state']=jobs[(m,t)]['state']
  records.append(r)
 dump(ROOT/'summary.json',dict(updated_utc=time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime()),jobs=records))

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--gpus',default='0,1');args=parser.parse_args();gpus=[int(x) for x in args.gpus.split(',')]
 lock=(ROOT/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 pending=[(m,t) for m,t in ORDER if read(ROOT/'results'/m/t/'done.json').get('state')!='complete']
 running={};states={};started=time.time();last_summary=0
 (ROOT/'logs').mkdir(exist_ok=True)
 dump(ROOT/'controller_pid.json',dict(pid=os.getpid(),gpus=gpus,started_utc=time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime())))
 while pending or running:
  for gpu,(process,job,log) in list(running.items()):
   code=process.poll()
   if code is None:continue
   log.close();states[job]=dict(state='complete' if code==0 else 'failed',returncode=code,gpu=gpu)
   del running[gpu]
  for gpu in gpus:
   if gpu in running:continue
   if gpu==1 and not read(ROOT/'smoke'/'gpu1_released.json').get('released'):continue
   candidate=next((j for j in pending if ready(*j)),None)
   if candidate is None:continue
   pending.remove(candidate);model,task=candidate
   log=(ROOT/'logs'/(model+'_'+task+'.log')).open('a')
   env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True')
   process=subprocess.Popen([sys.executable,'-u',str(ROOT/'run.py'),'--model',model,'--task',task],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   running[gpu]=(process,candidate,log);states[candidate]=dict(state='running',gpu=gpu,pid=process.pid)
  state='running' if running else 'waiting_for_data_or_download' if pending else 'complete'
  dump(ROOT/'status.json',dict(state=state,gpus=gpus,seconds=time.time()-started,pending=[dict(model=m,task=t) for m,t in pending],running=[dict(gpu=gpu,model=j[0],task=j[1],pid=p.pid) for gpu,(p,j,l) in running.items()],finished=[dict(model=m,task=t,**s) for (m,t),s in states.items() if s['state']!='running']))
  if time.time()-last_summary>=60:summary(states);last_summary=time.time()
  if pending or running:time.sleep(5)
 failures=[dict(model=m,task=t,**s) for (m,t),s in states.items() if s['state']=='failed']
 summary(states)
 dump(ROOT/'status.json',dict(state='complete_with_failures' if failures else 'complete',seconds=time.time()-started,gpus=gpus,failures=failures,completed=sum(s['state']=='complete' for s in states.values())))
if __name__=='__main__':main()
