import argparse,json,time,traceback
from pathlib import Path
import torch
from engine import Engine
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--device',default='cuda:1');a=p.parse_args()
 out=ROOT/'smoke';out.mkdir(exist_ok=True);started=time.time();result=dict(model=a.model,device=a.device,state='running')
 try:
  torch.cuda.set_device(a.device)
  e=Engine(a.model,device=a.device,metadata_path=out/(a.model+'_metadata.json'))
  text='Rule: age >= 65. Patient age: 70. Is the condition satisfied? Answer with YES (\u662f) or NO (\u5426).'
  value=e.score(text,capture=True,grad=True)
  context=e.prepare(text)
  head=int(value['grads'].reshape(e.num_heads,e.head_dim).norm(dim=-1).argmax())
  donor=torch.zeros_like(value['heads'].reshape(e.num_heads,e.head_dim)[head])
  patched=e.run(context,replacements={head:donor},capture=False)
  result.update(state='complete',ell=value['ell'],patched_ell=patched['ell'],patched_head=head,heads_shape=list(value['heads'].shape),
    grads_shape=list(value['grads'].shape),finite=bool(torch.isfinite(value['grads']).all()),
    peak_gib=torch.cuda.max_memory_allocated(a.device)/2**30,seconds=time.time()-started,counts=e.counts)
 except BaseException as exc:
  result.update(state='failed',error=str(exc),seconds=time.time()-started);traceback.print_exc()
 finally:
  (out/(a.model+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result))
 if result['state']!='complete':raise SystemExit(1)
