# Manuscript: five models and three tasks

Started on GPUs 0 and 1. plan.json contains the fixed protocol and exact dataset sizes; status.json contains active jobs; summary.json aggregates measured progress. Results and frozen predictors are under results/<model>/<task>/.

MEGA: existing repair-v2 inputs, matching Qwen/MedGemma score caches and head selections. Other model/task combinations localize their own heads. NLI4CT: released native label-preserving and label-changing variants, split by clinical-trial groups. Syllogisms: program-generated inputs with formal validity labels; all prediction scores come from actual backbone forwards. No preset simulation scores enter this run.

The run reconstructs fit-only rank16 supports under one shared protocol, fits AP differences with per-CF constraints at tau=0.1, and calibrates bias on natural fit examples. It reports raw/calibration controls and core CPU ablations. MEGA also executes each method on its own actual controller path. New real results stay separate from historical/simulated manuscript tables.

Controller runs detached and moves through the 15 jobs automatically. Detailed logs are under logs/. Native model context limits and available pair counts are reported without truncating task inputs.
