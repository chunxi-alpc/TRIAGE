"""Resumable real backbone evaluation for each manuscript model/task."""
import argparse,gc,json,os,sys,time,traceback
from pathlib import Path
from collections import defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,'/home/gcx/TRIAGE-worktrees/aster-cr-20261108')
LEGACY=Path('/home/gcx/aster_cr_repair_v2_run_20261108')

def rows(path):
 path=Path(path)
 if not path.exists():return []
 with path.open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def dump(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');tmp.replace(path)
def append(path,value):
 with Path(path).open('a',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,allow_nan=False)+'\n')
def numpy(value):
 return value.detach().float().cpu().numpy() if hasattr(value,'detach') else np.asarray(value)
def save_feature(path,result):
 arrays={k:numpy(result.pop(k)).astype('float16') for k in ('heads','residual','grads') if k in result}
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('wb') as f:np.savez_compressed(f,**arrays)
 return result

class Job:
 def __init__(self,model,task):
  self.model=model;self.task=task;self.data=ROOT/'data'/task;self.out=ROOT/'results'/model/task
  for name in ('scores','features','paths'): (self.out/name).mkdir(parents=True,exist_ok=True)
  self.views=rows(self.data/'views.jsonl');self.pairs=rows(self.data/'pairs.jsonl');self.byid={v['view_id']:v for v in self.views};self.positions={v['view_id']:i for i,v in enumerate(self.views)}
  self.eng=None;self.started=time.time()
 def status(self,stage,**kwargs):
  dump(self.out/'status.json',dict(state='running',model=self.model,task=self.task,stage=stage,seconds=time.time()-self.started,**kwargs))
 def engine(self):
  if self.eng is None:
   from engine import Engine
   self.status('loading_model');self.eng=Engine(self.model,metadata_path=self.out/'model_metadata.json')
  return self.eng
 def release(self):
  if self.eng is not None:
   self.eng=None;gc.collect()
   import torch
   torch.cuda.empty_cache()
 def import_legacy(self):
  if self.task!='mega' or self.model not in ('qwen','medgemma'):return
  target=self.out/'scores'/'legacy.jsonl'
  if not target.exists():
   rr=[r for p in sorted((LEGACY/self.model/'scores').glob('*.jsonl')) for r in rows(p) if r.get('status')=='ok' and r['view_id'] in self.byid and Path(r['feature']).exists()]
   with target.open('w',encoding='utf-8') as f:
    for r in rr:f.write(json.dumps(dict(r,cache_source='repair-v2 canonical identical prompt/template/score'),ensure_ascii=False)+'\n')
  sel=self.out/'selection.json'
  if not sel.exists():
   old=json.loads((LEGACY/self.model/'selection.json').read_text());old['reused_from']=str(LEGACY/self.model/'selection.json');dump(sel,old)
 def records(self):return {r['view_id']:r for p in sorted((self.out/'scores').glob('*.jsonl')) for r in rows(p) if r.get('status')=='ok'}
 def score(self,splits):
  records=self.records();cache={}
  for vid,r in records.items():
   if vid in self.byid:
    v=self.byid[vid];cache[(v['prompt'],tuple(v.get('labels') or ['\u662f','\u5426']))]=r
  selected=[v for v in self.views if v['split'] in splits]
  target=self.out/'scores'/('_'.join(splits)+'.jsonl')
  for i,v in enumerate(selected):
   vid=v['view_id']
   if vid in records:continue
   key=(v['prompt'],tuple(v.get('labels') or ['\u662f','\u5426']))
   rec={k:v.get(k) for k in ('view_id','group_id','source_id','split')}
   if key in cache and (v['split']!='fit' or cache[key].get('has_grads',cache[key].get('split')=='fit')):
    prev=cache[key];rec.update({k:value for k,value in prev.items() if k not in ('view_id','group_id','source_id','split')});rec['reused_from']=prev['view_id']
   else:
    self.status('score_'+v['split'],completed=i,total=len(selected),last_view=vid)
    try:
     result=self.engine().score(v['prompt'],labels=v.get('labels'),capture=True,grad=v['split']=='fit')
     feature=self.out/'features'/(v['split']+'_'+str(self.positions[vid])+'.npz')
     rec.update(save_feature(feature,result),feature=str(feature),status='ok',has_grads=v['split']=='fit')
    except ValueError as exc:
     rec.update(status='unavailable',error=str(exc))
   append(target,rec)
   if rec.get('status')=='ok':records[vid]=rec;cache[key]=rec
  self.status('score_complete',splits=splits,available=len(records))
 def localize(self):
  target=self.out/'selection.json'
  if target.exists():return
  self.status('head_localization');eng=self.engine();rec=self.records();ranks={};exact={};attrs={}
  def feat(vid):
   with np.load(rec[vid]['feature']) as a:return {k:a[k].astype('float32') for k in a.files}
  for kind in ('A','P','C','F'):
   pairs=[p for p in self.pairs if p['split']=='fit' and p['kind']==kind and p['left'] in rec and p['right'] in rec]
   if not pairs:continue
   attr=np.zeros(eng.num_heads);den=0;weighted=[]
   for p in pairs:
    l,r=rec[p['left']],rec[p['right']]
    wrong=int((l['ell']>0)!=bool(p['left_label']) or (r['ell']>0)!=bool(p['right_label']))
    weight=1+wrong+int(min(abs(l['ell']),abs(r['ell']))<1)
    left=feat(p['left']);right=feat(p['right'])
    d=(right['heads']-left['heads'])*left['grads'];attr+=weight*np.abs(d.reshape(eng.num_heads,-1).sum(-1));den+=weight
    weighted.append((p,weight))
   attr/=max(den,1);attrs[kind]=attr.tolist();candidate=np.argsort(-attr)[:64].tolist()
   chosen=[];seen=set()
   for p,weight in sorted(weighted,key=lambda pw:(-pw[1],pw[0]['pair_id'])):
    if p['source_id'] in seen or abs(rec[p['right']]['ell']-rec[p['left']]['ell'])<1e-8:continue
    chosen.append((p,weight));seen.add(p['source_id'])
    if len(chosen)>=12:break
   exact[kind]=[p['pair_id'] for p,w in chosen];sums=defaultdict(float);weights=0
   for j,(p,weight) in enumerate(chosen):
    left=feat(p['left'])['heads'].reshape(eng.num_heads,-1);right=feat(p['right'])['heads'].reshape(eng.num_heads,-1)
    contexts=(eng.prepare(self.byid[p['left']]['prompt']),eng.prepare(self.byid[p['right']]['prompt']))
    for h in candidate:
     a=eng.run(contexts[0],replacements={h:right[h]},capture=False)['ell']-rec[p['left']]['ell']
     b=eng.run(contexts[1],replacements={h:left[h]},capture=False)['ell']-rec[p['right']]['ell']
     sums[h]+=weight*.5*(abs(a)+abs(b))
     append(self.out/'localization_effects.jsonl',dict(pair_id=p['pair_id'],kind=kind,head=h,weight=weight,forward=a,reverse=b))
    weights+=weight;del contexts
    self.status('head_localization',kind=kind,completed=j+1,total=len(chosen))
   ranks[kind]=sorted(candidate,key=lambda h:(-sums[h]/max(weights,1),h))
  def merged(kinds):
   active=[k for k in kinds if k in ranks]
   return sorted(set(h for k in active for h in ranks[k]),key=lambda h:(sum(ranks[k].index(h) if h in ranks[k] else 64 for k in active),h))
  nr=merged(('A','P'));sr=merged(('C','F'));heads=[]
  for i in range(max(len(nr),len(sr))):
   for ranking in (nr,sr):
    if i<len(ranking) and ranking[i] not in heads:heads.append(ranking[i])
   if len(heads)>=51:break
  heads=heads[:51]
  if not heads:raise RuntimeError('No fit pairs available for head localization')
  dump(target,dict(heads=heads,ranks=ranks,exact_fit_pairs=exact,ranking_split='fit',head_budget=51,total_heads=eng.num_heads,weights='1 + original_error + min_abs_margin_below_1',note='Existing localization fallback budget 51; each new model/task localized independently'))
  dump(self.out/'attribution.json',attrs)
 def fit(self):
  self.release();self.status('fit_cpu')
  from fit_evaluate import fit_evaluate
  fit_evaluate(self.out,self.data,evaluate_only=(self.out/'selection-freeze.json').exists())
 def evaluate(self):
  self.release();self.status('evaluate_cpu')
  from fit_evaluate import fit_evaluate
  fit_evaluate(self.out,self.data,evaluate_only=True)
 def run(self):
  self.import_legacy();self.score(['fit','dev']);self.localize();self.fit();self.score(['test']);self.evaluate()
  # True controller paths are evaluated separately for MEGA only.
  if self.task=='mega':self.paths()
  self.release();dump(self.out/'done.json',dict(state='complete',model=self.model,task=self.task,seconds=time.time()-self.started))
  dump(self.out/'status.json',dict(state='complete',model=self.model,task=self.task,seconds=time.time()-self.started))
 def paths(self):
  from experiments.aster_closed_form.data import canonical_guide,prompt
  from fit_evaluate import Predictor
  predictor=Predictor(self.out)
  methods=['raw','bias_only','aster_cr','unconstrained_AP']
  cases=rows(self.data/'path_cases.jsonl');records=self.records()
  bytext={self.byid[vid]['prompt']:r for vid,r in records.items() if vid in self.byid and not self.byid[vid].get('labels')}
  existing={r['id']:r for r in rows(self.out/'paths'/'nodes.jsonl') if r.get('status')=='ok'}
  if self.model in ('qwen','medgemma'):
   for p in sorted((LEGACY/self.model/'paths').glob('features_*.jsonl')):
    for r in rows(p):
     if r.get('status')=='ok' and Path(r['feature']).exists():existing.setdefault(r['id'],r)
  for split in ('dev','test'):
   target=self.out/'paths'/f'{split}.jsonl';done={(r['case_id'],r['method']) for r in rows(target)}
   selected=[c for c in cases if c['split']==split]
   for i,case in enumerate(selected):
    if all((case['case_id'],m) in done for m in methods):continue
    self.status('paths_'+split,completed=i,total=len(selected))
    tree=canonical_guide(case['guideline']);nodes={n['id']:n for n in tree['nodes']};node_scores={}
    def node(gid):
     key=case['case_id']+':'+gid
     if gid in node_scores:return node_scores[gid]
     rec=existing.get(key)
     if rec is None:
      text=prompt(case['guideline'],case['definitions'],case['patient'],gid)
      if text in bytext:rec=dict(bytext[text],id=key,gid=gid,case_id=case['case_id'])
      else:
       result=self.engine().score(text,capture=True)
       feature=self.out/'paths'/('node_'+str(len(existing))+'.npz')
       rec=dict(save_feature(feature,result),id=key,gid=gid,case_id=case['case_id'],feature=str(feature),status='ok')
      append(self.out/'paths'/'nodes.jsonl',rec);existing[key]=rec
     with np.load(rec['feature']) as a:values=predictor.predict(rec['ell'],a['heads'])
     node_scores[gid]=values;return values
    for method in methods:
     if (case['case_id'],method) in done:continue
     gid=tree['nodes'][0]['id'];path=[];error=None
     try:
      while gid in nodes:
       if len(path)>len(nodes):raise ValueError('cycle')
       label=int(node(gid)[method]>0);path.append(dict(gid=gid,label=label));gid=nodes[gid]['yes' if label else 'no']
     except ValueError as exc:error=str(exc)
     append(target,dict(case_id=case['case_id'],source_id=case['source_id'],split=split,method=method,predicted_path=path,predicted_leaf=gid,gold_path=case['gold_path'],gold_leaf=case['gold_leaf'],correct=error is None and path==case['gold_path'] and gid==case['gold_leaf'],error=error))
   rr=rows(target)
   dump(self.out/'paths'/f'{split}_summary.json',{m:dict(n=sum(r['method']==m for r in rr),correct=sum(r['method']==m and r['correct'] for r in rr)) for m in methods})

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--model',required=True);parser.add_argument('--task',required=True);args=parser.parse_args()
 import torch
 torch.set_num_threads(4)
 job=Job(args.model,args.task)
 try:job.run()
 except BaseException as exc:
  dump(job.out/'status.json',dict(state='failed',model=args.model,task=args.task,error=str(exc),traceback=traceback.format_exc()))
  raise
