"""Prepare shared NLI4CT and generated syllogisms; never generate model scores."""
import argparse,itertools,json
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path('/home/gcx/aster_five_models_20261109')
INVENTORY=Path('/home/gcx/aster_next_20261109/inventory')
def read_rows(p):return [json.loads(s) for s in Path(p).read_text().splitlines() if s.strip()]
def write_rows(p,rows):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8') as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=False)+'\n')
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def view(task,vid,gid,sid,split,prompt,label,variant,kind,**meta):
 return dict(id=vid,view_id=vid,case_id=vid,group_id=gid,source_id=sid,dataset=task,task=task,task_type='binary',
  split=split,evaluation_group=task+':'+split,prompt=prompt,prompt_text=prompt,label=int(label),
  original=variant=='full',variant=variant,kind=kind,gid='G0',gold_path=[dict(gid='G0',label=int(label))],
  gold_leaf='L1' if label else 'L0',positive_leaf='L1',negative_leaf='L0',status='ready',**meta)
def pair(l,r,kind,subtype,**meta):
 return dict(pair_id=l['view_id']+'->'+r['view_id'],left=l['view_id'],right=r['view_id'],left_label=l['label'],
  right_label=r['label'],kind=kind,subtype=subtype,task=l['task'],dataset=l['dataset'],split=l['split'],
  group_id=l['group_id'],source_id=l['source_id'],**meta)
def save(task,views,pairs,extra):
 out=ROOT/'data'/task;out.mkdir(parents=True,exist_ok=True);ids={v['view_id']:v for v in views}
 assert len(ids)==len(views)
 for p in pairs:
  l,r=ids[p['left']],ids[p['right']]
  assert l['split']==r['split']==p['split']
  assert p['left_label']==l['label'] and p['right_label']==r['label']
  assert (l['label']==r['label'])==(p['kind'] in {'A','P'})
 write_rows(out/'views.jsonl',views);write_rows(out/'pairs.jsonl',pairs)
 cases=[v for v in views if v['original']];write_rows(out/'cases.jsonl',cases)
 summary=dict(dataset=task,views=len(views),pairs=len(pairs),original_cases=len(cases),splits={},**extra)
 for split in ('fit','dev','test'):
  vv=[v for v in views if v['split']==split];pp=[p for p in pairs if p['split']==split]
  write_rows(out/(split+'.views.jsonl'),vv);write_rows(out/(split+'.pairs.jsonl'),pp)
  write_rows(out/(split+'.cases.jsonl'),[v for v in vv if v['original']])
  summary['splits'][split]=dict(views=len(vv),pairs=len(pp),original_cases=sum(v['original'] for v in vv),
   sources=len({v['source_id'] for v in vv}),pair_kinds=dict(Counter(p['kind'] for p in pp)),
   pair_subtypes=dict(Counter(p['subtype'] for p in pp)),original_labels=dict(Counter(str(v['label']) for v in vv if v['original'])))
 dump(out/'summary.json',summary);return summary
class Components:
 def __init__(self):self.parent={}
 def find(self,x):
  self.parent.setdefault(x,x)
  if self.parent[x]!=x:self.parent[x]=self.find(self.parent[x])
  return self.parent[x]
 def union(self,a,b):
  a,b=self.find(a),self.find(b)
  if a!=b:self.parent[max(a,b)]=min(a,b)
def nli4ct():
 (ROOT/'data'/'nli4ct'/'READY.json').unlink(missing_ok=True)
 rows=read_rows(INVENTORY/'nli4ct_practice_cases.jsonl')+read_rows(INVENTORY/'nli4ct_test_cases.jsonl')
 lookup={r['case_id']:r for r in rows}
 originals=[r for r in rows if r.get('native_intervention') in (None,'original')]
 comp=Components()
 for r in originals:
  ids=r['clinical_trial_ids']
  for t in ids:comp.find(t)
  for t in ids[1:]:comp.union(ids[0],t)
 component_trials=defaultdict(set)
 for t in comp.parent:component_trials[comp.find(t)].add(t)
 pc=defaultdict(list)
 for r in originals:
  if r['dataset_split']=='practice':pc[comp.find(r['clinical_trial_ids'][0])].append(r)
 dev=set();remaining=40
 for cid,rr in sorted(pc.items()):
  if len(rr)<=remaining:dev.add(cid);remaining-=len(rr)
  if remaining==0:break
 assert remaining==0
 def cv(r):
  family=r.get('base_id') or r.get('family') or r['native_id']
  original=r.get('native_intervention') in (None,'original')
  cid=comp.find(r['clinical_trial_ids'][0]);trials=sorted(component_trials[cid])
  variant='full' if original else r['native_intervention']+':'+r['native_id']
  split='test' if r['dataset_split']=='test' else 'dev' if cid in dev else 'fit'
  return view('nli4ct',r['case_id'],'nli4ct:'+r['dataset_split']+':'+family,'nli4ct:trials:'+'|'.join(trials),
   split,r['prompt_text'],r['label'],variant,'original' if original else 'native_variant',
   native_id=r['native_id'],native_split=r['dataset_split'],family=family,
   clinical_trial_ids=r['clinical_trial_ids'],trial_component_ids=trials,section_id=r['section_id'],
   statement=r['statement'],native_label=r['native_label'],native_intervention=r.get('native_intervention'),
   label_source='released NLI4CT-2024 label',source_input_file=r.get('source_input_file'),
   source_gold_file=r.get('source_gold_file'))
 core={r['case_id']:cv(r) for r in originals};pairs=[];aux_pairs=[];aux_views={};excluded=Counter()
 for p in read_rows(INVENTORY/'nli4ct_native_pairs.jsonl'):
  if p['dataset_split'] not in ('practice','test'):continue
  intervention=p['intervention'];changed=p['left_label']!=p['right_label'];l,r=lookup[p['left']],lookup[p['right']]
  if intervention=='Text_appended' and not changed:
   kind='P';semantics='Native irrelevant text is appended to the statement; report evidence and released truth label are unchanged.'
  elif intervention in ('Contradiction','Numerical_contradiction') and changed:
   kind='C';semantics='Native statement changes while clinical-trial report stays fixed; actual released labels flip.'
  elif intervention in ('Paraphrase','Numerical_paraphrase') and not changed:
   lv,rv=cv(l),cv(r);rv['kind']='paraphrase_aux';aux_views[lv['view_id']]=lv;aux_views[rv['view_id']]=rv
   aux_pairs.append(pair(lv,rv,'paraphrase_aux',intervention,native_pair_id=p['pair_id'],
    label_source='released original/variant labels',
    pair_semantics='Auxiliary statement paraphrase; outside core fixed-evidence nuisance supervision.'))
   continue
  else:excluded[intervention+(':same_label' if not changed else ':changed_label')]+=1;continue
  core.setdefault(l['case_id'],cv(l));core.setdefault(r['case_id'],cv(r));core[r['case_id']]['kind']=kind
  pairs.append(pair(core[l['case_id']],core[r['case_id']],kind,intervention,native_pair_id=p['pair_id'],
   native_intervention=intervention,label_source='released original/variant labels; never inferred from intervention name',
   pair_semantics=semantics))
 views=sorted(core.values(),key=lambda v:(('fit','dev','test').index(v['split']),v['group_id'],not v['original'],v['view_id']))
 summary=save('nli4ct',views,pairs,dict(
  provenance='Official NLI4CT-2024 practice families for fit/dev; official test families for test.',
  native_practice_families=200,native_test_families=500,
  split_rule='Keep all native family variants together; assign practice trial connected components to 160 fit/40 dev originals.',
  auxiliary_paraphrase_pairs=len(aux_pairs),excluded_native_pairs=dict(excluded),
  no_f_pairs_reason='Native variants edit statements, not clinical-trial facts; numeric statement edits remain C.'))
 out=ROOT/'data'/'nli4ct'
 write_rows(out/'auxiliary_paraphrase.views.jsonl',sorted(aux_views.values(),key=lambda v:v['view_id']))
 write_rows(out/'auxiliary_paraphrase.pairs.jsonl',aux_pairs)
 candidates=[]
 for r in read_rows(INVENTORY/'nli4ct_train_cases.jsonl'):
  candidates.append(view('nli4ct',r['case_id'],'nli4ct:train:'+r['native_id'],r['source_id'],'unused_official_train',
   r['prompt_text'],r['label'],'full','original',native_id=r['native_id'],native_split='train',statement=r['statement'],
   clinical_trial_ids=r['clinical_trial_ids'],label_source='released NLI4CT-2024 label',not_used_in_primary_experiment=True))
 write_rows(out/'official_train.calibration_candidates.jsonl',candidates)
 (out/'README.md').write_text('''# NLI4CT shared real-model experiment inputs

Source: /home/gcx/aster_next_20261109/inventory/nli4ct_*cases.jsonl and nli4ct_native_pairs.jsonl, derived from released NLI4CT-2024 inputs and labels. Prompts retain the entire dataset-selected report section and original wording; no gold evidence sentence selection.

The 200 official practice base families supply 160 fit and 40 dev originals. All variants stay with their base; clinical-trial connected components keep trial IDs separate between fit/dev. Official test supplies all 500 base families and their selected native variants. Official train 1700 originals are saved separately as optional calibration candidates and are unused by default. No official test input enters fitting.

Core P pairs use native Text_appended: clinical-trial report and base statement stay fixed, and irrelevant native text is appended. Core C pairs use only Contradiction or Numerical_contradiction variants whose actual released labels differ from their base. Numeric statement edits are also C, because report facts are not edited. Same-label contradiction variants are excluded from nuisance supervision because same truth does not establish unchanged evidence. Paraphrase and Numerical_paraphrase are separate auxiliary files, outside core P fitting and primary paired metrics.

Labels are the released Entailment=1 / Contradiction=0 labels, never inferred from an intervention name. This is a task-specific fit/dev/test adaptation of released native pairs, not zero-shot transfer from MEGA.

views.jsonl contains core prompts, cases.jsonl original cases, pairs.jsonl core P/C relations. There are also fit/dev/test files. Five models must share these files. Every prediction must be produced by a real model forward; no preset model scores are included.
''',encoding='utf-8')
 return summary
Q='AEIO'
FIG={1:((2,1),(0,2)),2:((1,2),(0,2)),3:((2,1),(2,0)),4:((1,2),(2,0))}
VOCAB=[
('dogs','mammals','animals'),('sparrows','birds','vertebrates'),('roses','flowers','plants'),
('salmon','fish','swimmers'),('oak trees','trees','organisms'),('poodles','dogs','pets'),
('triangles','polygons','shapes'),('squares','rectangles','quadrilaterals'),('rivers','waterways','geographic features'),
('novels','books','publications'),('physicians','professionals','workers'),('violinists','musicians','artists'),
('buses','vehicles','machines'),('apples','fruits','foods'),('carrots','vegetables','crops'),
('eagles','raptors','predators'),('bees','insects','pollinators'),('whales','cetaceans','creatures'),
('diamonds','gemstones','minerals'),('chairs','furniture items','objects'),
('dolphins','marine mammals','sea creatures'),('tulips','garden flowers','living things'),
('poets','writers','people'),('bicycles','wheeled vehicles','transport devices'),('lemons','citrus fruits','edible things'),
('penguins','seabirds','wildlife'),('potatoes','root vegetables','farm products'),('librarians','employees','adults'),
('tigers','big cats','carnivores'),('guitars','string instruments','sound makers'),('sofas','seats','household items'),
('rubies','crystals','stones'),('helicopters','aircraft','flying machines'),('cottages','houses','buildings'),
('turtles','reptiles','land animals')]
def prop(q,x,y,m):
 regions=[t for t in range(8) if (m>>t)&1]
 inter=any(((t>>x)&1) and ((t>>y)&1) for t in regions)
 diff=any(((t>>x)&1) and not ((t>>y)&1) for t in regions)
 return {'A':not diff,'E':not inter,'I':inter,'O':diff}[q]
def validity(f):
 a,b,c,fig=f;(x,y),(u,v)=FIG[fig];prem=[];counter=[]
 for m in range(1,256):
  if prop(a,x,y,m) and prop(b,u,v,m):
   prem.append(m)
   if not prop(c,0,1,m):counter.append(m)
 assert prem
 return dict(valid=int(not counter),semantics='Modern first-order logic; nonempty domain; predicate extensions may be empty.',
  occupancy_regions=8,occupancy_interpretations_checked=255,premise_model_count=len(prem),
  countermodel_count=len(counter),first_countermodel=counter[0] if counter else None,
  region_encoding='Bit t indicates inhabited region; within t, bits 0/1/2 encode S/P/M membership.')
def formdict(f):
 return dict(major_quantifier=f[0],minor_quantifier=f[1],conclusion_quantifier=f[2],figure=f[3],
  major_terms=list(FIG[f[3]][0]),minor_terms=list(FIG[f[3]][1]),conclusion_terms=[0,1])
def sentence(q,x,y):
 return {'A':f'All {x} are {y}.','E':f'No {x} are {y}.','I':f'Some {x} are {y}.','O':f'Some {x} are not {y}.'}[q]
def prompt(f,words):
 a,b,c,fig=f;(x,y),(u,v)=FIG[fig]
 return ('\u5224\u65ad\u4e0b\u5217\u4e09\u6bb5\u8bba\u7684\u7ed3\u8bba\u662f\u5426\u4ece\u4e24\u4e2a\u524d\u63d0\u5fc5\u7136\u63a8\u51fa\u3002\u53ea\u6309\u5f62\u5f0f\u903b\u8f91\u63a8\u7406\uff0c\u5047\u8bbe\u524d\u63d0\u6210\u7acb\uff0c\u4e0d\u4f7f\u7528\u73b0\u5b9e\u4e16\u754c\u77e5\u8bc6\u3002'
  '\u7c7b\u522b\u5141\u8bb8\u4e3a\u7a7a\uff1b\u201c\u6709\u4e9b\u201d\u8868\u793a\u81f3\u5c11\u5b58\u5728\u4e00\u4e2a\u3002\u7ed3\u8bba\u5fc5\u7136\u6210\u7acb\u8f93\u51fa\u201c\u662f\u201d\uff0c\u5426\u5219\u8f93\u51fa\u201c\u5426\u201d\u3002\n\n'
  +'Premise 1: '+sentence(a,words[x],words[y])+'\n'
  +'Premise 2: '+sentence(b,words[u],words[v])+'\n'
  +'Conclusion: '+sentence(c,words[0],words[1])+'\n\n\u53ea\u8f93\u51fa\u201c\u662f\u201d\u6216\u201c\u5426\u201d\u3002\n\u7b54\u6848\uff1a')
def syllogism():
 (ROOT/'data'/'syllogism'/'READY.json').unlink(missing_ok=True)
 forms=list(itertools.product(Q,Q,Q,range(1,5)));labels={f:validity(f) for f in forms};neighbors={}
 for f in forms:
  cc=[f[:2]+(q,)+f[3:] for q in Q if labels[f[:2]+(q,)+f[3:]]['valid']!=labels[f]['valid']]
  ff=[]
  for i in (0,1):
   for q in Q:
    g=list(f);g[i]=q;g=tuple(g)
    if labels[g]['valid']!=labels[f]['valid']:ff.append((i,g))
  if cc and ff:neighbors[f]=(cc,ff)
 positive=sorted(f for f in neighbors if labels[f]['valid']);negative=sorted(f for f in neighbors if not labels[f]['valid'])
 views=[];pairs=[]
 for vi,words in enumerate(VOCAB):
  split='fit' if vi<20 else 'dev' if vi<25 else 'test';n=8 if split!='test' else 10
  selected=[positive[(vi+j)%len(positive)] for j in range(n)]+[negative[(vi+j)%len(negative)] for j in range(n)]
  sid='syllogism:vocabulary:'+str(vi).zfill(2)
  for fi,f in enumerate(selected):
   gid=sid+':form:'+str(fi).zfill(2)
   def make(variant,kind,g,newwords,**meta):
    v=view('syllogism',gid+':'+variant,gid,sid,split,prompt(g,newwords),labels[g]['valid'],variant,kind,
     input_origin='Program-generated categorical syllogism; real model predictions required',
     label_source='Exact finite-model enumeration over three unary predicates',formal_structure=formdict(g),
     entity_mapping=dict(zip(('S','P','M'),newwords)),validity=labels[g],**meta)
    views.append(v);return v
   base=make('full','original',f,words)
   content=make('content_swap','P',f,(words[1],words[0],words[2]),
    edit_description='Swap S/P vocabulary consistently in both premises and conclusion; formal structure unchanged.')
   pairs.append(pair(base,content,'P','consistent_content_replacement',
    pair_semantics='Bijective consistent predicate renaming preserves exact logical validity.'))
   cc,ff=neighbors[f];g=cc[(vi+fi)%len(cc)]
   conclusion=make('conclusion_change','C',g,words,edit_description='Change only conclusion quantifier; exact validity flips.')
   pairs.append(pair(base,conclusion,'C','conclusion_quantifier_flip',
    pair_semantics='Premises and vocabulary fixed; changed conclusion flips exact validity.'))
   pi,g=ff[(vi+fi)%len(ff)]
   fact=make('premise_change','F',g,words,changed_premise=pi+1,edit_description='Change one premise quantifier; exact validity flips.')
   pairs.append(pair(base,fact,'F','premise_quantifier_flip',
    pair_semantics='Change one premise with the conclusion and other premise fixed; exact validity flips.'))
 summary=save('syllogism',views,pairs,dict(
  data_origin='Program-generated questions; finite-model labels. No model scores generated.',
  all_categorical_forms=256,valid_categorical_forms=sum(r['valid'] for r in labels.values()),
  included_base_forms=len(neighbors),included_valid_forms=len(positive),included_invalid_forms=len(negative),
  base_form_selection='Require both conclusion-only and one-premise-only validity-flipping neighbors; balance base truth.',
  split_rule='Disjoint vocabulary triples: 20 fit, 5 dev, 10 test; 16/16/20 original forms per source.',
  generated_inputs_are_not_a_published_human_dataset=True))
 out=ROOT/'data'/'syllogism'
 dump(out/'all_form_labels.json',[dict(form=formdict(f),**labels[f]) for f in forms])
 (out/'README.md').write_text('''# Program-generated categorical syllogism questions

These are program-generated input questions, not a published natural-language benchmark or preset simulated model scores. Every reported prediction must come from an actual model run.

We enumerate 256 forms (A/E/I/O for two premises and conclusion, four figures) under modern first-order semantics. The domain is nonempty; predicate extensions may be empty. Exact validity uses all 255 nonempty occupancy assignments to the eight S/P/M regions: 15 forms are valid. Each view saves form, predicate mapping, premise-model count, and a countermodel occupancy mask for invalid arguments.

Uniform evidence pairs require a conclusion-quantifier change and a single-premise-quantifier change that each flip validity. This selects 31 base forms (15 valid,16 invalid), an explicitly restricted formal test suite. Original truth is balanced per vocabulary source. No label or pair is selected by model predictions.

20 disjoint vocabulary triples contribute 16 originals each to fit (320); 5 contribute 16 each to dev (80); 10 contribute 20 each to test (200). Formal structures recur across splits to test held-out vocabulary generalization; argument forms are not held out.

Each original has P (consistent S/P vocabulary swap in both premises and conclusion), C (only conclusion quantifier changes), and F (only one premise quantifier changes). P preserves validity, C/F flip exact validity. World plausibility can change under P; the prompt explicitly assumes the premises and permits empty categories. Labels are 1 for necessary conclusion and 0 otherwise. Five models share these exact inputs. No model or GPU is loaded during preparation.
''',encoding='utf-8')
 return summary
def main():
 p=argparse.ArgumentParser();p.add_argument('--task',choices=('all','nli4ct','syllogism'),default='all');a=p.parse_args();ss={}
 if a.task in ('all','nli4ct'):ss['nli4ct']=nli4ct()
 if a.task in ('all','syllogism'):ss['syllogism']=syllogism()
 for task,summary in ss.items():
  out=ROOT/'data'/task
  ready=dict(state='ready',views=summary['views'],pairs=summary['pairs'],original_cases=summary['original_cases'],
   splits=summary['splits'],generation_description=summary.get('data_origin',summary.get('provenance')),
   preparation_script=str(ROOT/'data_prepare.py'),model_predictions_generated=False)
  temp=out/'READY.json.tmp';dump(temp,ready);temp.replace(out/'READY.json')
 print(json.dumps({k:{n:v[n] for n in ('views','pairs','original_cases','splits')} for k,v in ss.items()},ensure_ascii=False))
if __name__=='__main__':main()

