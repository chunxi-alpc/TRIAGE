# Program-generated categorical syllogism questions

These are program-generated input questions, not a published natural-language benchmark or preset simulated model scores. Every reported prediction must come from an actual model run.

We enumerate 256 forms (A/E/I/O for two premises and conclusion, four figures) under modern first-order semantics. The domain is nonempty; predicate extensions may be empty. Exact validity uses all 255 nonempty occupancy assignments to the eight S/P/M regions: 15 forms are valid. Each view saves form, predicate mapping, premise-model count, and a countermodel occupancy mask for invalid arguments.

Uniform evidence pairs require a conclusion-quantifier change and a single-premise-quantifier change that each flip validity. This selects 31 base forms (15 valid,16 invalid), an explicitly restricted formal test suite. Original truth is balanced per vocabulary source. No label or pair is selected by model predictions.

20 disjoint vocabulary triples contribute 16 originals each to fit (320); 5 contribute 16 each to dev (80); 10 contribute 20 each to test (200). Formal structures recur across splits to test held-out vocabulary generalization; argument forms are not held out.

Each original has P (consistent S/P vocabulary swap in both premises and conclusion), C (only conclusion quantifier changes), and F (only one premise quantifier changes). P preserves validity, C/F flip exact validity. World plausibility can change under P; the prompt explicitly assumes the premises and permits empty categories. Labels are 1 for necessary conclusion and 0 otherwise. Five models share these exact inputs. No model or GPU is loaded during preparation.

## Exact generated core counts

| split | originals | views | pairs | P | C | F | sources |
|---|---:|---:|---:|---:|---:|---:|---:|
| fit | 320 | 1280 | 960 | 320 | 320 | 320 | 20 |
| dev | 80 | 320 | 240 | 80 | 80 | 80 | 5 |
| test | 200 | 800 | 600 | 200 | 200 | 200 | 10 |

READY.json is written after core files are complete. Preparation: source /home/gcx/gcx261014/bin/activate; python /home/gcx/aster_five_models_20261109/data_prepare.py --task syllogism
