# NLI4CT shared real-model experiment inputs

Source: /home/gcx/aster_next_20261109/inventory/nli4ct_*cases.jsonl and nli4ct_native_pairs.jsonl, derived from released NLI4CT-2024 inputs and labels. Prompts retain the entire dataset-selected report section and original wording; no gold evidence sentence selection.

The 200 official practice base families supply 160 fit and 40 dev originals. All variants stay with their base; clinical-trial connected components keep trial IDs separate between fit/dev. Official test supplies all 500 base families and their selected native variants. Official train 1700 originals are saved separately as optional calibration candidates and are unused by default. No official test input enters fitting.

Core P pairs use native Text_appended: clinical-trial report and base statement stay fixed, and irrelevant native text is appended. Core C pairs use only Contradiction or Numerical_contradiction variants whose actual released labels differ from their base. Numeric statement edits are also C, because report facts are not edited. Same-label contradiction variants are excluded from nuisance supervision because same truth does not establish unchanged evidence. Paraphrase and Numerical_paraphrase are separate auxiliary files, outside core P fitting and primary paired metrics.

Labels are the released Entailment=1 / Contradiction=0 labels, never inferred from an intervention name. This is a task-specific fit/dev/test adaptation of released native pairs, not zero-shot transfer from MEGA.

views.jsonl contains core prompts, cases.jsonl original cases, pairs.jsonl core P/C relations. There are also fit/dev/test files. Five models must share these files. Every prediction must be produced by a real model forward; no preset model scores are included.

## Exact generated core counts

| split | originals | views | pairs | P | C | F | sources |
|---|---:|---:|---:|---:|---:|---:|---:|
| fit | 160 | 910 | 750 | 480 | 270 | 0 | 58 |
| dev | 40 | 226 | 186 | 120 | 66 | 0 | 12 |
| test | 500 | 2864 | 2364 | 1500 | 864 | 0 | 113 |

READY.json is written after core files are complete. Preparation: source /home/gcx/gcx261014/bin/activate; python /home/gcx/aster_five_models_20261109/data_prepare.py --task nli4ct
