"""Cross-task data preparation and reusable IO. All execution is server-side."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
from pathlib import Path
import sys,json,random,collections
import numpy as np
ROOT=Path('/home/gcx/aster_cross_task_transfer_20261109')
FIVE=Path('/home/gcx/aster_five_models_20261109')
MED=Path('/home/gcx/aster_medpic_20261109')
SOURCE=Path('/home/gcx/aster_hard_optimization_20261109')
REPO='/home/gcx/TRIAGE-worktrees/aster-cr-20261108'
sys.path.insert(0,str(FIVE));sys.path.insert(0,REPO)
def rows(p):
 p=Path(p)
 return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()] if p.exists() else []
def dump(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp')
 q.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');q.replace(p)
def lines(p,rr):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8') as f:
  for r in rr:f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
def append(p,r):
 with Path(p).open('a',encoding='utf-8') as f:f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n');f.flush()
def rms(x):return float(np.sqrt(np.mean(np.square(x)))) if len(x) else None
def prepare():
 for task in ('nli4ct','medpic'):(ROOT/task/'features').mkdir(parents=True,exist_ok=True)
 out=ROOT/'nli4ct'
 for name in ('views.jsonl','pairs.jsonl'): (out/name).write_text((FIVE/'data/nli4ct'/name).read_text(),encoding='utf-8')
 records={r['view_id']:r for f in sorted((FIVE/'results/qwen/nli4ct/scores').glob('*.jsonl')) for r in rows(f) if r.get('status')=='ok'}
 vv=rows(out/'views.jsonl');assert all(v['view_id'] in records for v in vv)
 lines(out/'scores.jsonl',[records[v['view_id']] for v in vv]);dump(out/'selection.json',json.loads((FIVE/'results/qwen/nli4ct/selection.json').read_text()))
 data=Path('/home/gcx/aster_cr_repair_v2_run_20261108/external/medpic')
 items=rows(data/'items.jsonl');groups=rows(data/'groups.jsonl')
 dev=set(json.loads((MED/'intercept_adaptation/split.json').read_text())['development_item_ids']);assert len(dev)==93
 membership={i:g['group_id'] for g in groups for i in g['members']}
 units=collections.defaultdict(list)
 for i in items:units[membership.get(i['id'],'singleton:'+i['id'])].append(i['id'])
 assert all(not(set(u)&dev) or set(u)<=dev for u in units.values())
 available=[(k,u) for k,u in sorted(units.items()) if not set(u)&dev];random.Random(20261109).shuffle(available)
 # Seeded whole-group subset sum to obtain exactly 186 fit questions.
 reached={0:[]}
 for k,u in available:
  for n,chosen in sorted(list(reached.items()),reverse=True):
   if n+len(u)<=186 and n+len(u) not in reached:reached[n+len(u)]=chosen+[k]
  if 186 in reached:break
 fitgroups=set(reached[186]);fit={i for k,u in available if k in fitgroups for i in u};test={i['id'] for i in items}-fit-dev
 assert (len(fit),len(dev),len(test))==(186,93,188)
 split={i:('fit' if i in fit else 'dev' if i in dev else 'test') for i in fit|dev|test}
 dump(ROOT/'medpic/split.json',dict(seed=20261109,fit_item_ids=sorted(fit),development_item_ids=sorted(dev),test_item_ids=sorted(test),
  policy='Existing 93-question dev retained. Seeded whole-case-group subset sum to 186 fit; remaining 188 test. Exploratory re-split of previously evaluated data.',groups=dict(units)))
 nuisance={'geography':'The Andes run along western South America. The Pacific Ocean lies west of the Andes. The Sahara is in northern Africa.',
 'astronomy':'Jupiter is a gas giant. Saturn has rings made largely of ice particles. Neptune orbits the Sun beyond Uranus.'}
 base={r['id']:r for r in rows(MED/'cases.jsonl')};views=[];pairs=[]
 for item in items:
  for letter in item['options']:
   c=base[item['id']+':'+letter];sid=membership.get(item['id'],'singleton:'+item['id'])
   v=dict(view_id=c['id'],id=c['id'],item_id=item['id'],option_letter=letter,label=c['label'],prompt=c['prompt'],split=split[item['id']],source_id=sid,group_id=sid,original=True,variant='full',kind='original')
   views.append(v)
   for topic,extra in nuisance.items():
    vid=c['id']+'|'+topic
    text=c['prompt'].replace('\nAnswer:','\n\nIrrelevant text (unrelated to the medical question):\n'+extra+'\nEnd of irrelevant text.\n\nAnswer:')
    views.append(dict(v,view_id=vid,id=vid,prompt=text,original=False,variant=topic,kind='P'))
    pairs.append(dict(pair_id=vid+'|pair',left=c['id'],right=vid,left_label=c['label'],right_label=c['label'],kind='P',subtype=topic,split=v['split'],source_id=sid,group_id=sid))
 for p in rows(MED/'option_pairs.jsonl'):
  l=next(v for v in views if v['view_id']==p['left']);r=next(v for v in views if v['view_id']==p['right']);assert l['split']==r['split']
  pairs.append(dict(p,kind='F' if p['relation']=='changing' else 'F0',subtype='native_patient_change',split=l['split'],source_id=l['source_id']))
 lines(ROOT/'medpic/views.jsonl',views);lines(ROOT/'medpic/pairs.jsonl',pairs);lines(ROOT/'medpic/items.jsonl',items)
 for task in ('nli4ct','medpic'):
  vv=rows(ROOT/task/'views.jsonl');pp=rows(ROOT/task/'pairs.jsonl')
  dump(ROOT/task/'inventory.json',{s:dict(views=sum(v['split']==s for v in vv),natural_options_or_cases=sum(v['split']==s and v['original'] for v in vv),pairs=dict(collections.Counter(p['kind'] for p in pp if p['split']==s))) for s in ('fit','dev','test')})
 dump(ROOT/'plan.json',dict(gpu=6,expected_peak_gib=[18,35],reserved_gib=40,expected_hours=[1,3],tasks=['nli4ct','medpic'],configurations=['A','C','B'],schemes=['tail_pair','tail_robust'],seeds=[11,22,33],initial_steps=1600,tail_steps=1200,small_network_runs=36,bootstrap=2000,
  source_manifest=str(SOURCE/'protected_frozen_methods.json'),feature_dimension=99,width=128,head_count=51,
  target_ce='Initial phase: natural fit BCE as source. Tail phase: source-group-balanced natural fit BCE; source-only extra gold-node augmentation has no target equivalent and is not synthesized.',
  p_sampling='NLI/MedPIC contain P and no A: initial 116 AP draws plus 12 P draws retain source sampler.',
  monitoring='Check initial healthy progress only; automatic pipeline writes results and failures without ongoing manual polling.'))
if __name__=='__main__':prepare()
