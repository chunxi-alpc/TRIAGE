from pathlib import Path
import json,sys
r=Path('/home/gcx/aster_cross_task_transfer_20261109')
text=['# Qwen3-8B 跨任务机制与修正方法迁移实验','','全部完成，仅使用物理GPU 6，总耗时21.4分钟。A完整冻结MEGA参数；C固定MEGA头并适配下游参数；B重新选头，训练流程与C相同。两个优化版本均报告。','','共享头在两个任务上都保留了预测干扰分数变化的信息。完整冻结方法降低了干扰方差，但没有提高最终准确率。目标适配主要改善干扰降低率，重新选头未带来稳定的准确率收益。','','## 机制结果','','| 数据集 | 头集合 | R² | 相关系数 | RMSE |','|---|---|---:|---:|---:|']
for task in ('nli4ct','medpic'):
 m=json.loads((r/task/'mechanism_metrics.json').read_text())
 for k,v in m.items():text.append(f"| {task} | {k} | {v['r2']:.3f} | {v['correlation']:.3f} | {v['rmse']:.3f} |")
text+=['','MEGA头均优于三组匹配层分布的随机头，R²差值95%区间均大于零。NLI4CT目标头略优于MEGA头；MedPIC的MEGA头反而优于目标头。NLI4CT随机头也有较高预测能力，因此结果不能证明该信息仅存在于MEGA选出的头中。','','## 方法结果','','NLI4CT为500个原始案例准确率；MedPIC为188题整题全对率。所有MedPIC方法统一使用既有合法答案集合解码。','','| 数据集 | 方法 | 干扰降低率 | 证据响应保留率 | 证据修正RMS | 准确率 | 无关对全对率 | 标签改变对全对率 |','|---|---|---:|---:|---:|---:|---:|---:|']
for task in ('nli4ct','medpic'):
 for name,v in json.loads((r/task/'metrics.json').read_text())['methods'].items():
  m=v['metrics'];text.append(f"| {task} | {name} | {100*m['variance_reduction']:.3f}% | {100*m['evidence_retention']:.3f}% | {m['CF_correction_rms']:.3f} | {100*m['accuracy']:.3f}% | {100*m['AP_paired_accuracy']:.3f}% | {100*m['CF_paired_accuracy']:.3f}% |")
text+=['','## 配对差值与95%区间','','按临床试验组或病例组进行2000次配对bootstrap，差值单位为百分点。','','| 数据集 | 比较 | 准确率差值 | 95%区间 | 干扰降低率差值 | 95%区间 |','|---|---|---:|---|---:|---|']
for task in ('nli4ct','medpic'):
 for name,v in json.loads((r/task/'metrics.json').read_text())['paired_differences'].items():
  a=v['accuracy'];b=v['variance_reduction'];text.append(f"| {task} | {name} | {100*a['difference']:.3f} | [{100*a['ci95']['low']:.3f}, {100*a['ci95']['high']:.3f}] | {100*b['difference']:.3f} | [{100*b['ci95']['low']:.3f}, {100*b['ci95']['high']:.3f}] |")
text+=['','A相对原模型的准确率差值区间均触及或跨过零，不能声称获得准确率提升。C相对A明显改善干扰降低率；B相对C的收益有限。NLI4CT的B_tail_robust准确率比C低1.00个百分点，95%区间为−1.78至−0.24。','','MedPIC标签改变对两侧同时正确率：原模型14.55%，A为30.00%，B/C均为10.00%。响应保留率接近100%不能替代正确性评价。','','## 数据与实现','','NLI4CT沿用160个拟合、40个开发、500个测试原始案例，保留病例变体分组。测试含1500个无关文本对和864个标签改变对。数值陈述变化仍归为陈述变化。','','MedPIC保留已有93题开发集，按病例组及种子20261109划分其余186题拟合、188题测试，属于既有数据重新划分后的探索性实验。每题增加地理和天文两种固定非医学无关文本，置于独立区域。测试含1880个选项级无关对、110个标签改变患者变化对、85个同标签患者变化对；后者在metrics.json单列，不作为无关干扰。','','B/C共同使用目标拟合集估计的残差投影、99维输入、宽度128、种子11/22/33等权集成。初始化1600步，两个优化版本各1200步，共36次小网络训练。增益按既有开发集公式确定，截距仅用自然拟合样本校准。目标数据没有MEGA新增金标准节点增强池，tail阶段使用按病例组均衡的自然拟合样本交叉熵；其余优化损失和预算沿用源方法。','','A冻结接口、零修正、保存后A/B/C接口均通过一致性验证。测试不参与拟合或选头。机制预测器仅使用头特征差，拟合集标准化、降至16维、岭系数0.01。完整指标、原始响应幅度、置信区间、逐例预测和参数位于各任务子目录。','']
(r/'REPORT.zh.md').write_text('\n'.join(text),encoding='utf-8')
(r/'README.zh.md').write_text('实验已完成，结果见REPORT.zh.md，指标与参数位于nli4ct和medpic子目录。物理GPU为6，环境为gcx261014。\n',encoding='utf-8')
status=json.loads((r/'pipeline_status.json').read_text());(r/'status.json').write_text(json.dumps(status,indent=2)+'\n')
# Keep report regeneration reproducible, without changing measured results.
p=r/'evaluate.py';s=p.read_text();a=s.index('def report():');s=s[:a]+"def report():\n import runpy\n runpy.run_path(str(ROOT/'repair_report.py'))\nif __name__=='__main__':report()\n";p.write_text(s)
assert '机制结果' in (r/'REPORT.zh.md').read_text()
print('Report encoding repaired; all results complete.')