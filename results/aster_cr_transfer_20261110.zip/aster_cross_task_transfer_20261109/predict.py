"""Saved A/B/C single-input evaluation entry: complete head array plus residual."""
from common import *
import torch
from fit import Editor
class Predictor:
 def __init__(self,task):
  self.task=task;self.root=ROOT/task;self.methods={};self.models={};self.supports={};self.rb={}
  source=json.loads((self.root/'A_parameters.json').read_text())
  self.supports['A']=dict(np.load('/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz'));self.rb['A']=dict(np.load('/home/gcx/aster_optimization_20261109/shared/residual_basis.npz'))
  for name,p in source.items():self.methods[name]=dict(config='A',**p['entry'])
  for config in ('B','C'):
   self.supports[config]=dict(np.load(self.root/(config+'_support.npz')));self.rb[config]=dict(np.load(self.root/'target_residual_basis.npz'))
   for name,e in json.loads((self.root/config/'parameters.json').read_text())['methods'].items():self.methods[name]=dict(config=config,**e)
  for e in self.methods.values():
   for member in e['members']:
    path=member['model_file']
    if path in self.models:continue
    s=torch.load(path,map_location='cpu',weights_only=False);m=Editor();m.load_state_dict(s['state_dict']);m.eval();self.models[path]=(m,s['mu'],s['scale'])
 def predict(self,ell,heads,residual):
  full=np.asarray(heads,dtype='float32').reshape(-1,128);res=np.asarray(residual,dtype='float32').reshape(-1);q=np.array([ell/10,abs(ell)/10,np.tanh(ell/4)],dtype='float32');xs={}
  for config,sup in self.supports.items():
   raw=full[sup['heads'].astype(int)].reshape(-1);z=(raw-sup['mu'])/sup['scale'];rb=self.rb[config]
   xs[config]=np.concatenate([z@sup['N'],z@sup['S'],((res-rb['mu'])/rb['scale'])@rb['R'],q]).astype('float32')
  result={'raw':float(ell)}
  for name,e in self.methods.items():
   delta=0.
   for member in e['members']:
    model,mu,scale=self.models[member['model_file']];z=((xs[e['config']]-mu)/scale).astype('float32')
    with torch.no_grad():delta+=member['coefficient']*float(model(torch.from_numpy(z[None]))[0])
   result[name]=float(ell+e['gain']*delta+e['b'])
  return result
 def save_manifest(self):
  dump(self.root/'frozen_methods.json',dict(task=self.task,score='ell + gain * equal_seed_mean_delta + natural_fit_intercept',methods=self.methods,head_order={c:s['heads'].tolist() for c,s in self.supports.items()},source_manifest=str(SOURCE/'protected_frozen_methods.json')))
