实验已完成，结果见REPORT.zh.md，指标与参数位于nli4ct和medpic子目录。物理GPU为6，环境为gcx261014。
