"""A fully frozen; C target coordinates at MEGA heads; B same fit at target heads."""
from common import *
import torch,math
from torch import nn
from scipy.special import expit
from scipy.optimize import brentq
from sklearn.utils.extmath import randomized_svd
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score
class Editor(nn.Module):
 def __init__(self,d=99):
  super().__init__();self.net=nn.Sequential(nn.Linear(d,128),nn.GELU(),nn.Linear(128,1,bias=False))
 def forward(self,x):return self.net(x)[:,0]
def calibrate(e,y):
 f=lambda b:float(np.mean(expit(e+b)-y));lo,hi=-200.,200.
 while f(lo)>0:lo*=2
 while f(hi)<0:hi*=2
 return float(brentq(f,lo,hi))
def basis(x,k):
 return randomized_svd(x,n_components=min(k,*x.shape),random_state=20261109)[2].T.astype('float32')
def tail(x):return x.topk(max(1,math.ceil(len(x)*.2)),sorted=False).values.mean()
def load(task):
 out=ROOT/task;vv=rows(out/'views.jsonl');pp=rows(out/'pairs.jsonl');rr={r['view_id']:r for r in rows(out/'scores.jsonl')};ix={v['view_id']:i for i,v in enumerate(vv)}
 assert len(rr)==len(vv)
 return vv,pp,rr,ix,np.array([rr[v['view_id']]['ell'] for v in vv]),np.array([v['label'] for v in vv])
def pidx(pp,ix,split,kinds):
 p=[p for p in pp if p['split']==split and p['kind'] in kinds]
 return np.array([ix[p['left']] for p in p],int),np.array([ix[p['right']] for p in p],int)
def natural(vv,split):return np.array([i for i,v in enumerate(vv) if v['split']==split and v['original']],int)
def feature_matrices(vv,rr,heads):
 h=np.empty((len(vv),len(heads)*128),np.float32);r=None
 for i,v in enumerate(vv):
  with np.load(rr[v['view_id']]['feature']) as a:
   h[i]=a['heads'].reshape(-1,128)[heads].reshape(-1)
   if r is None:r=np.empty((len(vv),len(a['residual'])),np.float32)
   r[i]=a['residual']
 return h,r
def coordinates(h,r,ell,ni,al,ar,cl,cr,resbasis=None):
 mu=h[ni].mean(0);scale=np.maximum(h[ni].std(0),1e-5)
 S=basis((h[cr]-h[cl])/scale,16);N=basis((h[ar]-h[al])/scale,16).astype('float64')
 N-=S@(S.T@N);N-=S@(S.T@N);N=np.linalg.svd(N,full_matrices=False)[0][:,:16].astype('float32')
 if resbasis is None:
  rm=r[ni].mean(0);rs=np.maximum(r[ni].std(0),1e-5);R=basis((r[ni]-rm)/rs,64);resbasis=dict(mu=rm,scale=rs,R=R)
 x=np.concatenate([((h-mu)/scale)@N,((h-mu)/scale)@S,((r-resbasis['mu'])/resbasis['scale'])@resbasis['R'],np.column_stack([ell/10,np.abs(ell)/10,np.tanh(ell/4)])],axis=1).astype('float32')
 assert x.shape[1]==99
 return x,dict(mu=mu,scale=scale,N=N,S=S),resbasis

def frozen(task,vv,rr,ell,heads):
 out=ROOT/task;sup=dict(np.load('/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz'));rb=dict(np.load('/home/gcx/aster_optimization_20261109/shared/residual_basis.npz'))
 h,r=feature_matrices(vv,rr,heads)
 z=(h-sup['mu'])/sup['scale'];x=np.concatenate([z@sup['N'],z@sup['S'],((r-rb['mu'])/rb['scale'])@rb['R'],np.column_stack([ell/10,np.abs(ell)/10,np.tanh(ell/4)])],axis=1).astype('float32')
 manifest=json.loads((SOURCE/'protected_frozen_methods.json').read_text());entries={k:e for k,e in manifest['methods'].items() if k.startswith('hard_tail_')}
 scores={};provenance={};checks={}
 for name,e in entries.items():
  values=[]
  for member in e['members']:
   s=torch.load(member['model_file'],map_location='cpu',weights_only=False);m=Editor();m.load_state_dict(s['state_dict']);m.eval();zz=((x-s['mu'])/s['scale']).astype('float32')
   with torch.no_grad():values.append(np.concatenate([m(torch.from_numpy(zz[j:j+1024])).numpy() for j in range(0,len(zz),1024)]).astype('float64'))
  scheme=e['scheme'];scores['A_'+scheme]=ell+e['gain']*sum(v*member['coefficient'] for v,member in zip(values,e['members']))+e['b']
  provenance['A_'+scheme]=dict(source_entry=name,entry=e,heads=heads.tolist(),support_file='/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz',residual_basis='/home/gcx/aster_optimization_20261109/shared/residual_basis.npz',frozen='All source standardization, projections, network weights, member coefficients, gain and intercept')
 # Use the prior frozen interface on two complete head/residual records.
 sys.path.insert(0,'/home/gcx/aster_next_20261109/inference')
 from frozen import FrozenMethods
 minimal=dict(manifest,methods=entries,frozen_before_expanded_evaluation=True)
 dump(out/'source_frozen_interface.json',minimal);adapter=FrozenMethods(out/'source_frozen_interface.json')
 for i in (0,len(vv)-1):
  old=adapter.predict(ell[i],h[i],r[i])
  for name,e in entries.items():checks[str(i)+':'+e['scheme']]=abs(scores['A_'+e['scheme']][i]-old[name])
 # Float32 BLAS/GEMV order differences are allowed at numerical precision.
 maxerr=max(checks.values());assert maxerr<1e-3,checks
 dump(out/'verification.json',dict(frozen_interface_max_abs_error=maxerr,zero_correction_max_abs_error=float(np.max(np.abs(ell+np.zeros_like(ell)-ell))),head_order=bool(np.array_equal(heads,sup['heads'])),all_passed=True))
 dump(out/'A_parameters.json',provenance)
 return scores,h,r

def fit_config(task,config,x,vv,pp,ix,ell,y,heads):
 out=ROOT/task/config;out.mkdir(exist_ok=True);ni=natural(vv,'fit');al,ar=pidx(pp,ix,'fit',('A','P'));cl,cr=pidx(pp,ix,'fit',('C','F'))
 da,db=pidx(pp,ix,'dev',('A','P'));dc,dd=pidx(pp,ix,'dev',('C','F'));budget=.1*rms(ell[ar]-ell[al]);devap=rms(ell[db]-ell[da])
 mu=x[ni].mean(0);scale=np.maximum(x[ni].std(0),1e-4);z=((x-mu)/scale).astype('float32')
 fit=np.unique(np.concatenate([al,ar,cl,cr,ni]));local=np.full(len(vv),-1,int);local[fit]=np.arange(len(fit));device='cuda:0'
 a,b,c,d,n=[torch.tensor(local[q],device=device) for q in (al,ar,cl,cr,ni)]
 zz=torch.tensor(z[fit],device=device);ee=torch.tensor(ell[fit],dtype=torch.float32,device=device);yy=torch.tensor(y[ni],dtype=torch.float32,device=device)
 sources=[vv[i]['source_id'] for i in ni];cnt=collections.Counter(sources);weights=torch.tensor([1/len(cnt)/cnt[s] for s in sources],device=device)
 b0=calibrate(ell[ni],y[ni]);base=[];provenance={'heads':heads.tolist(),'head_order':'Explicit saved array order','input_dimension':99,'width':128,'seeds':[11,22,33],'source_manifest':str(SOURCE/'protected_frozen_methods.json'),'natural_fit_count':len(ni),'fit_pair_counts':{'AP':len(al),'CF':len(cl)},'initial_steps':1600,'tail_steps':1200,'initial_lr':.001,'tail_lr':.0003,'weight_decay':.001,'target_ce':'source-group-balanced natural fit only; target has no source extra-gold-node augmentation'}
 def all_delta(model):
  with torch.no_grad():return np.concatenate([model(torch.tensor(z[j:j+1024],device=device)).cpu().numpy() for j in range(0,len(z),1024)]).astype('float64')
 # Initial training reproduces strong_0031 (beta=10000,jitter=.1,BCE=1).
 for seed in (11,22,33):
  torch.manual_seed(seed);model=Editor().to(device);nn.init.zeros_(model.net[-1].weight);opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.001)
  for step in range(1600):
   pick=torch.cat([torch.randint(len(al),(116,),device=device),torch.randint(len(al),(12,),device=device)])
   left,right=a[pick],b[pick];sel=torch.cat([left,right,c,d,n]);val=model(zz[sel]);vl,vr,vc,vd,vn=val.split([128,128,len(c),len(c),len(n)])
   noise=torch.randn((len(c),99),device=device)*.1;cd=model(zz[d]+noise)-model(zz[c]+noise)
   loss=(ee[right]-ee[left]+vr-vl).square().mean()+10000*cd.square().mean()+nn.functional.binary_cross_entropy_with_logits(ee[n]+vn+b0,yy)+1e-5*vn.square().mean()
   opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),10.);opt.step()
  delta=all_delta(model);base.append((seed,{k:v.detach().cpu().clone() for k,v in model.state_dict().items()},delta))
  torch.save(dict(state_dict=base[-1][1],mu=mu,scale=scale,seed=seed,cfg={'width':128,'steps':1600,'lr':.001,'beta':10000,'jitter':.1}),out/f'initial_seed{seed}.pt')
  dump(ROOT/'status.json',dict(state='running',stage='initial_training',task=task,config=config,completed_seed=seed))
 mean=np.mean([b[2] for b in base],axis=0);g0=min(1.,.1*devap/max(rms(mean[dd]-mean[dc]),1e-12))
 result={};entries={}
 for scheme in ('tail_pair','tail_robust'):
  deltas=[];members=[]
  for seed,state,_ in base:
   torch.manual_seed(seed);model=Editor().to(device);model.load_state_dict(state)
   with torch.no_grad():model.net[-1].weight.mul_(g0);initial=model(zz).detach()
   initial_b=calibrate(ell[ni]+initial[n].cpu().numpy(),y[ni]);bias=torch.tensor(initial_b,device=device,requires_grad=True)
   opt=torch.optim.AdamW(list(model.parameters())+[bias],lr=.0003,weight_decay=.001)
   for step in range(1200):
    corr=model(zz);ap=ee[b]-ee[a]+corr[b]-corr[a];cd=corr[d]-corr[c]
    ap_loss=ap.square().mean()+tail(ap.square())
    if scheme=='tail_pair':cf=1000*cd.square().mean()+1000*torch.relu(cd.abs()-budget).square().mean()
    else:
     noise=torch.randn((len(c),99),device=device)*.1;locald=model(zz[d]+noise)-model(zz[c]+noise)
     cf=500*(tail(cd.square())+tail(locald.square()))+1000*torch.relu(cd.abs()-budget).square().max()
    ce=(nn.functional.binary_cross_entropy_with_logits(ee[n]+corr[n]+bias,yy,reduction='none')*weights).sum()
    loss=ap_loss+cf+ce+.01*(corr[n]-initial[n]).square().mean()
    opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),10.);opt.step()
   with torch.no_grad():
    corr=model(zz);factor=min(1.,budget/max(float((corr[d]-corr[c]).abs().max()),1e-12));model.net[-1].weight.mul_(factor)
   delta=all_delta(model);deltas.append(delta);path=out/f'{scheme}_seed{seed}.pt'
   torch.save(dict(state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},mu=mu,scale=scale,seed=seed,fit_scale=factor,initial_gain=g0,cfg={'width':128,'steps':1200,'lr':.0003,'scheme':scheme}),path)
   members.append(dict(model_file=str(path),coefficient=1/3,seed=seed,fit_scale=factor))
   dump(ROOT/'status.json',dict(state='running',stage='tail_training',task=task,config=config,scheme=scheme,completed_seed=seed))
  delta=np.mean(deltas,axis=0);gain=min(1.,.1*devap/max(rms(delta[dd]-delta[dc]),1e-12));delta*=gain;bias=calibrate(ell[ni]+delta[ni],y[ni]);name=config+'_'+scheme;result[name]=ell+delta+bias
  entries[name]=dict(members=members,gain=gain,b=bias,initial_gain=g0,fit_budget=budget,dev_formula='min(1,.1*raw_dev_AP_RMS/dev_CF_correction_RMS)',natural_fit_intercept=True)
 provenance['methods']=entries;dump(out/'parameters.json',provenance);np.savez_compressed(out/'normalization.npz',mu=mu,scale=scale)
 return result

def mechanism(task,vv,pp,rr,ix,ell,sets):
 out=ROOT/task;al,ar=pidx(pp,ix,'fit',('A','P'));tl,tr=pidx(pp,ix,'test',('A','P'));y=ell[ar]-ell[al];yt=ell[tr]-ell[tl];ni=natural(vv,'fit');result={};pred={}
 for name,heads in sets.items():
  dump(ROOT/'status.json',dict(state='running',stage='mechanism_predictors',task=task,head_set=name))
  h,_=feature_matrices(vv,rr,heads);mu=h[ni].mean(0);scale=np.maximum(h[ni].std(0),1e-5);d=(h[ar]-h[al])/scale;dt=(h[tr]-h[tl])/scale;proj=basis(d,16);model=Ridge(alpha=.01).fit(d@proj,y);yp=model.predict(dt@proj)
  result[name]=dict(heads=heads.tolist(),r2=float(r2_score(yt,yp)),correlation=float(np.corrcoef(yt,yp)[0,1]),rmse=rms(yt-yp),fit_pairs=len(y),test_pairs=len(yt),rank=16,ridge_alpha=.01)
  pred[name]=yp;np.savez_compressed(out/f'mechanism_{name}.npz',heads=heads,mu=mu,scale=scale,projection=proj,coef=model.coef_,intercept=model.intercept_)
 lines(out/'mechanism_predictions.jsonl',[dict(pair_id=p['pair_id'],source_id=p['source_id'],target=float(yt[j]),predictions={k:float(v[j]) for k,v in pred.items()}) for j,p in enumerate([p for p in pp if p['split']=='test' and p['kind'] in ('A','P')])]);dump(out/'mechanism_metrics.json',result)
 return result

def run(task):
 torch.set_num_threads(2);vv,pp,rr,ix,ell,y=load(task);mega=np.load('/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz')['heads'].astype(int);target=np.array(json.loads((ROOT/task/'selection.json').read_text())['heads'],int);assert len(target)==51
 scores,h,r=frozen(task,vv,rr,ell,mega);ni=natural(vv,'fit');scores={'raw':ell,'bias_only':ell+calibrate(ell[ni],y[ni]),**scores}
 sets={'MEGA':mega,'target':target}
 for seed in (11,22,33):
  rng=np.random.default_rng(seed);heads=[]
  for layer,n in sorted(collections.Counter(mega//32).items()):heads.extend((layer*32+rng.choice(32,n,replace=False)).tolist())
  sets['random_'+str(seed)]=np.array(heads,int)
 mechanism(task,vv,pp,rr,ix,ell,sets)
 al,ar=pidx(pp,ix,'fit',('A','P'));cl,cr=pidx(pp,ix,'fit',('C','F'));resbasis=None
 for config,heads in [('C',mega),('B',target)]:
  if config=='B':h,r=feature_matrices(vv,rr,heads)
  x,sup,resbasis=coordinates(h,r,ell,ni,al,ar,cl,cr,resbasis)
  np.savez_compressed(ROOT/task/f'{config}_support.npz',heads=heads,**sup)
  if config=='C':np.savez_compressed(ROOT/task/'target_residual_basis.npz',**resbasis)
  scores.update(fit_config(task,config,x,vv,pp,ix,ell,y,heads))
 np.savez_compressed(ROOT/task/'scores_final.npz',ids=np.array([v['view_id'] for v in vv]),**scores)
 from evaluate import evaluate
 evaluate(task,vv,pp,ix,ell,y,scores)
 dump(ROOT/task/'done.json',dict(state='complete',methods=list(scores)))
if __name__=='__main__':run(sys.argv[1])
