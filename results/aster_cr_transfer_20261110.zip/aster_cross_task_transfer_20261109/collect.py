"""Resumable full-head collection and existing bidirectional patch localization."""
from common import *
import time,traceback
from run import Job,save_feature
from engine import Engine
import torch
class TargetJob(Job):
 def __init__(self):
  self.model='qwen';self.task='medpic';self.data=ROOT/'medpic';self.out=self.data;self.started=time.time();self.eng=None
  self.views=rows(self.data/'views.jsonl');self.pairs=rows(self.data/'pairs.jsonl');self.byid={v['view_id']:v for v in self.views}
 def records(self):return {r['view_id']:r for r in rows(self.out/'scores.jsonl')}
 def status(self,stage,**kw):dump(ROOT/'status.json',dict(state='running',stage=stage,task=self.task,seconds=time.time()-self.started,**kw))
 def engine(self):
  if self.eng is None:self.eng=Engine('qwen',device='cuda:0',metadata_path=self.out/'model_metadata.json')
  return self.eng
 def collect(self,limit=None):
  done=self.records();old={r['id']:r for r in rows(MED/'option_results.jsonl')};eng=self.engine();canonical_checks=[]
  for j,v in enumerate(self.views):
   if v['view_id'] in done:continue
   result=eng.score(v['prompt'],capture=True,grad=v['split']=='fit')
   if len(canonical_checks)<2 and v['original']:
    prior=old[v['view_id']];err=abs(prior['ell']-result['ell']);assert err<1e-4,(err,v['view_id'])
    with np.load(prior['feature']) as a:
     mega=np.load('/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz')['heads'].astype(int)
     he=float(np.max(np.abs(result['heads'].float().cpu().numpy().reshape(-1,128)[mega].reshape(-1).astype('float16').astype('float32')-a['selected_heads'].astype('float32'))));re=float(np.max(np.abs(result['residual'].float().cpu().numpy().astype('float16').astype('float32')-a['residual'].astype('float32'))))
    assert he<1e-5 and re<1e-5,(he,re)
    canonical_checks.append(dict(view_id=v['view_id'],ell_error=err,head_error=he,residual_error=re))
    dump(self.out/'backbone_verification.json',dict(passed=True,checks=canonical_checks))
   feature=self.out/'features'/f'{j}.npz';rec=dict(view_id=v['view_id'],split=v['split'],source_id=v['source_id'],group_id=v['group_id'],feature=str(feature),status='ok',has_grads=v['split']=='fit',**save_feature(feature,result))
   append(self.out/'scores.jsonl',rec);done[v['view_id']]=rec
   if len(done)%25==0:self.status('collect_full_heads',completed=len(done),total=len(self.views),peak_gib=torch.cuda.max_memory_allocated()/2**30)
   if limit is not None and len(done)>=limit:return
  self.localize();dump(self.out/'feature_done.json',dict(state='complete',views=len(done),peak_gib=torch.cuda.max_memory_allocated()/2**30,seconds=time.time()-self.started))
if __name__=='__main__':
 torch.set_num_threads(2)
 try:TargetJob().collect(int(sys.argv[1]) if len(sys.argv)>1 else None)
 except Exception as e:dump(ROOT/'failed.json',dict(stage='medpic_features',error=str(e),traceback=traceback.format_exc()));raise
