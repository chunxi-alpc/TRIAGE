"""Full test evaluation, paired group bootstrap and final Chinese tables."""
from common import *
import itertools,csv

def decode(item,scores):
 letters=list(item['options']);none=[k for k in letters if 'none of' in item['options'][k].lower()]
 if not none:return [k for k in letters if scores[k]>0]
 others=[k for k in letters if k not in none];candidates=[none]+[list(c) for n in range(1,len(others)+1) for c in itertools.combinations(others,n)]
 return max(candidates,key=lambda c:sum(scores[k] for k in c))
def safe_ratio(a,b):
 a,b=np.broadcast_arrays(a,b);out=np.full(a.shape,np.nan,dtype=float);np.divide(a,b,out=out,where=np.abs(b)>1e-12);return out

def evaluate(task,vv,pp,ix,ell,y,scores):
 out=ROOT/task
 from predict import Predictor
 predictor=Predictor(task);predictor.save_manifest();errors=[]
 records={r['view_id']:r for r in rows(out/'scores.jsonl')}
 for i in (0,len(vv)-1):
  with np.load(records[vv[i]['view_id']]['feature']) as a:restored=predictor.predict(ell[i],a['heads'],a['residual'])
  errors.extend(abs(restored[k]-scores[k][i]) for k in restored)
 assert max(errors)<1e-3, max(errors)
 verification=json.loads((out/'verification.json').read_text());verification.update(saved_ABC_interface_max_abs_error=max(errors),head_feature_selection='Full head array indexed by each saved support heads array in order',target_head_order=predictor.supports['B']['heads'].tolist())
 dump(out/'verification.json',verification)
 test=[i for i,v in enumerate(vv) if v['split']=='test'];naturaltest=[i for i in test if vv[i]['original']]
 groups=sorted({vv[i]['source_id'] for i in test});gi={s:i for i,s in enumerate(groups)};ng=len(groups)
 rng=np.random.default_rng(20261109);W=rng.multinomial(ng,np.ones(ng)/ng,size=2000).astype(float);weights=np.vstack([np.ones(ng),W]);names=list(scores)
 items={i['id']:i for i in rows(out/'items.jsonl')} if task=='medpic' else {}
 question_rows=[];decision={};natural_correct={};natural_groups={};testq={vv[i]['item_id'] for i in naturaltest} if items else set()
 for name,ss in scores.items():
  dec=(ss>0).astype(int)
  if items:
   correct=[];qgroups=[]
   # Decode every variant, using the same legal-set decoder for all methods.
   for qid,item in items.items():
    for variant in ('full','geography','astronomy'):
     suffix='' if variant=='full' else '|'+variant
     pos={k:ix[qid+':'+k+suffix] for k in item['options']};pr=decode(item,{k:ss[i] for k,i in pos.items()})
     for k,i in pos.items():dec[i]=int(k in pr)
     if qid in testq:
      ok=set(pr)==set(item['answer']);question_rows.append(dict(item_id=qid,variant=variant,method=name,source_id=vv[next(iter(pos.values()))]['source_id'],predicted=pr,gold=item['answer'],correct=ok))
      if variant=='full':correct.append(ok);qgroups.append(vv[next(iter(pos.values()))]['source_id'])
   natural_correct[name]=np.array(correct,float);natural_groups[name]=qgroups
  else:natural_correct[name]=(dec[naturaltest]==y[naturaltest]).astype(float);natural_groups[name]=[vv[i]['source_id'] for i in naturaltest]
  decision[name]=dec
 def group_sum(values,ids):return np.bincount([gi[s] for s in ids],weights=values,minlength=ng)
 def weighted_mean(values,ids):return safe_ratio(weights@group_sum(values,ids),weights@group_sum(np.ones(len(values)),ids))
 allstats={};boot={};pairrows=[]
 for name,ss in scores.items():
  stats={'accuracy':weighted_mean(natural_correct[name],natural_groups[name]),'option_accuracy':weighted_mean((decision[name][naturaltest]==y[naturaltest]).astype(float),[vv[i]['source_id'] for i in naturaltest])}
  groups_result={}
  for group,kinds in [('AP',('A','P')),('CF',('C','F')),('F0',('F0',))]:
   ps=[p for p in pp if p['split']=='test' and p['kind'] in kinds]
   if not ps:continue
   l=np.array([ix[p['left']] for p in ps]);r=np.array([ix[p['right']] for p in ps]);sg=[p['source_id'] for p in ps]
   d=ell[r]-ell[l];dp=ss[r]-ss[l];dc=dp-d;dy=y[r]-y[l];paired=(decision[name][l]==y[l])&(decision[name][r]==y[r])
   dmean=weighted_mean(d,sg);pmean=weighted_mean(dp,sg);dvar=weighted_mean(d*d,sg)-dmean*dmean;pvar=weighted_mean(dp*dp,sg)-pmean*pmean
   stats[group+'_paired_accuracy']=weighted_mean(paired.astype(float),sg);stats[group+'_correction_rms']=np.sqrt(weighted_mean(dc*dc,sg))
   stats[group+'_raw_rms']=np.sqrt(weighted_mean(d*d,sg));stats[group+'_response_rms']=np.sqrt(weighted_mean(dp*dp,sg))
   if group=='AP':stats['variance_reduction']=1-safe_ratio(pvar,dvar)
   if group=='CF':
    stats['evidence_retention']=safe_ratio(weighted_mean(dy*dp,sg),weighted_mean(dy*d,sg));stats['raw_signed_response']=weighted_mean(dy*d,sg)
   groups_result[group]=dict(n=len(ps),paired_correct=int(paired.sum()),raw_response_rms=rms(d),response_rms=rms(dp),correction_rms=rms(dc))
   if group=='CF':groups_result[group]['raw_signed_response_sum']=float(dy@d)
   for j,p in enumerate(ps):pairrows.append(dict(pair_id=p['pair_id'],method=name,group=group,source_id=p['source_id'],left=p['left'],right=p['right'],left_label=int(y[l[j]]),right_label=int(y[r[j]]),left_score=float(ss[l[j]]),right_score=float(ss[r[j]]),raw_difference=float(d[j]),difference=float(dp[j]),paired_correct=bool(paired[j])))
  boot[name]=stats
  allstats[name]=dict(metrics={k:float(v[0]) if np.isfinite(v[0]) else None for k,v in stats.items()},ci95={k:interval(v[1:]) for k,v in stats.items()},groups=groups_result,natural_count=len(natural_correct[name]),natural_correct=int(natural_correct[name].sum()))
 comparisons=[('bias_only','raw')]
 for scheme in ('tail_pair','tail_robust'):comparisons += [('A_'+scheme,'raw'),('C_'+scheme,'A_'+scheme),('B_'+scheme,'C_'+scheme)]
 diffs={}
 for lhs,rhs in comparisons:
  diffs[lhs+' minus '+rhs]={}
  for metric in boot[lhs].keys()&boot[rhs].keys():
   d=boot[lhs][metric]-boot[rhs][metric];diffs[lhs+' minus '+rhs][metric]=dict(difference=float(d[0]) if np.isfinite(d[0]) else None,ci95=interval(d[1:]))
 dump(out/'metrics.json',dict(dataset=task,scope='Exploratory prior-data re-split' if task=='medpic' else 'Existing 160 fit/40 dev/500 test original split',test_groups=ng,bootstrap_samples=2000,methods=allstats,paired_differences=diffs,undefined_policy='Zero ratio denominator reported null; raw response amplitudes retained.'))
 lines(out/'predictions.jsonl',[dict(view_id=v['view_id'],split=v['split'],source_id=v['source_id'],label=v['label'],original=v['original'],scores={k:float(ss[i]) for k,ss in scores.items()},predictions={k:int(d[i]) for k,d in decision.items()}) for i,v in enumerate(vv)])
 lines(out/'pair_predictions.jsonl',pairrows)
 if question_rows:lines(out/'question_predictions.jsonl',question_rows)
 # Bootstrap information predictors independently of correction-network success.
 mech=rows(out/'mechanism_predictions.jsonl');mr=json.loads((out/'mechanism_metrics.json').read_text());mt=np.array([r['target'] for r in mech]);mg=[r['source_id'] for r in mech];ma=weighted_mean(mt,mg);mv=weighted_mean(mt*mt,mg)-ma*ma;mp={}
 for name in mr:
  yp=np.array([r['predictions'][name] for r in mech]);pm=weighted_mean(yp,mg);pv=weighted_mean(yp*yp,mg)-pm*pm;mse=weighted_mean((mt-yp)**2,mg)
  vals=dict(r2=1-safe_ratio(mse,mv),correlation=safe_ratio(weighted_mean(mt*yp,mg)-ma*pm,np.sqrt(np.maximum(mv*pv,0))),rmse=np.sqrt(mse));mp[name]=vals;mr[name]['ci95']={k:interval(v[1:]) for k,v in vals.items()}
 md={}
 for lhs,rhs in [('MEGA','target')]+[('MEGA','random_'+str(s)) for s in (11,22,33)]:
  md[lhs+' minus '+rhs]={k:dict(difference=float(mp[lhs][k][0]-mp[rhs][k][0]),ci95=interval((mp[lhs][k]-mp[rhs][k])[1:])) for k in ('r2','correlation','rmse')}
 dump(out/'mechanism_metrics.json',mr);dump(out/'mechanism_differences.json',md)
 table=[]
 for name,v in allstats.items():table.append(dict(dataset=task,method=name,**v['metrics']))
 write_csv(out/'method_table.csv',table);write_csv(out/'mechanism_table.csv',[dict(dataset=task,head_set=k,r2=v['r2'],correlation=v['correlation'],rmse=v['rmse']) for k,v in mr.items()])
 report()
def interval(v):
 v=np.asarray(v);f=v[np.isfinite(v)]
 return dict(low=float(np.quantile(f,.025)) if len(f) else None,high=float(np.quantile(f,.975)) if len(f) else None,defined_samples=len(f))
def write_csv(p,rr):
 with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rr for k in r)));w.writeheader();w.writerows(rr)
def fmt(v,pct=False):return '???' if v is None else f'{v*(100 if pct else 1):.3f}'+('%' if pct else '')
def report():
 import runpy
 runpy.run_path(str(ROOT/'repair_report.py'))
if __name__=='__main__':report()
