from common import *
import subprocess,time,traceback

def main():
 started=time.time();env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='6',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
 stages=[('nli4ct', ['fit.py','nli4ct']),('medpic_features',['collect.py']),('medpic',['fit.py','medpic'])]
 done=[]
 for name,args in stages:
  marker=ROOT/('medpic/feature_done.json' if name=='medpic_features' else name+'/done.json')
  if marker.exists():done.append(name);continue
  dump(ROOT/'pipeline_status.json',dict(state='running',stage=name,completed=done,seconds=time.time()-started))
  with (ROOT/(name+'.log')).open('a') as log:
   p=subprocess.Popen([sys.executable]+args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
   dump(ROOT/'worker_pid.json',dict(stage=name,pid=p.pid,gpu=6));code=p.wait()
  if code:raise RuntimeError(name+' failed with return code '+str(code)+'; see '+str(ROOT/(name+'.log')))
  done.append(name)
 from evaluate import report
 report();dump(ROOT/'done.json',dict(state='complete',stages=done,seconds=time.time()-started,gpu=6));dump(ROOT/'pipeline_status.json',dict(state='complete',completed=done,seconds=time.time()-started))
if __name__=='__main__':
 try:main()
 except Exception as e:dump(ROOT/'failed.json',dict(error=str(e),traceback=traceback.format_exc()));dump(ROOT/'pipeline_status.json',dict(state='failed',error=str(e)));raise
