from pathlib import Path
import shutil
root=Path('/home/gcx/aster_medpic_20261109')
p=root/'run_medpic.py'
s=p.read_text().replace('Answer only ? (Yes) or ? (No).','Answer only 是 (Yes) or 否 (No).')
a=s.index('def document(result):');b=s.index('def pipeline():',a)
replacement='''def document(result):
 labels=['原始 Qwen3-8B','原16维受约束方法','已有平衡版本','已有严格保护版本']
 lines=['### MedPIC-Bench：冻结方法的探索性迁移试测','','官方数据共467题、2,335个选项；现有90组含92个病例对，按选项文本映射得到244个标签翻转对和216个标签保持对。每个选项独立作是／否判断，再还原多选答案集合。全部复用既有权重、幅度和截距，无新增训练或校准。','','| 方法 | 翻转对响应保留率 | 修正RMS（logit） | 方向退化 | 翻转对全对 | 选项准确率 | 整题全对 |','|---|---:|---:|---:|---:|---:|---:|']
 for m,label in zip(METHODS,labels):
  x=result['groups']['changing'][m];o=result['option_metrics'][m];q=result['question_metrics'][m]
  er='未定义' if x['mean_evidence_retention'] is None else f"{100*x['mean_evidence_retention']:.2f}%"
  lines.append(f"| {label} | {er} | {x['correction_rms']:.4f} | {x['response_direction_degraded']} | {x['paired_correct']}/{x['n']} | {100*o['accuracy']:.2f}% | {q['correct']}/{q['n']}（{100*q['accuracy']:.2f}%） |")
 lines+=['','标签保持的216对单列如下；患者信息仍有变化，不能直接视为无关信息扰动。','','| 方法 | 原响应RMS | 修正后响应RMS | 修正RMS | 配对全对 |','|---|---:|---:|---:|---:|']
 for m,label in zip(METHODS,labels):
  x=result['groups']['same_label_patient_change'][m]
  lines.append(f"| {label} | {x['raw_difference_rms']:.4f} | {x['difference_rms']:.4f} | {x['correction_rms']:.4f} | {x['paired_correct']}/{x['n']} |")
 e=result['old_linear_error_counts']
 lines+=['','响应保留率沿用既有计分接口，为标签方向加权后的平均响应相对原模型的比值；修正RMS计算配对分数差的改变量，方向退化计原本沿正确标签方向的响应变为非正的对数。响应保留率接近100%只说明接近原响应，需结合配对全对率判断。','',f"全部选项和460个选项对均有结果。两个分片均通过原计分接口的一致性验证，零修正还原原始分数及预测。原16维方法固定保存{e['options']}个错选项、{e['questions']}个错题和{e['pairs']}个错误选项对，后续优化仅复测这些错例。",'','结果目录：`/home/gcx/aster_medpic_20261109`；逐例结果为 `option_results.jsonl`、`question_results.jsonl`、`pair_results.jsonl`，指标为 `metrics.json`，固定错例位于 `fixed_old_linear_errors/`。','']
 body='\\n'.join(lines);(ROOT/'REPORT.zh.md').write_text(body)
 start='<!-- medpic-frozen-transfer:start -->';end='<!-- medpic-frozen-transfer:end -->';block=start+'\\n'+body+end+'\\n'
 destinations=[]
 for base in [Path('/home/gcx/aster_cancel_story_20261109'),Path('/home/gcx/aster-real-completion-publish-20261109/reports/aster_cancel_story_20261109')]:
  for rel in ['paper_story_latest.zh.md','meeting/meeting_brief.zh.md']:
   p=base/rel
   if not p.exists():continue
   text=p.read_text()
   if start in text:
    a=text.index(start);b=text.index(end,a)+len(end);text=text[:a]+block+text[b:]
   else:
    if rel.startswith('paper') and '\\n## 9.' in text:
     a=text.index('\\n## 9.');text=text[:a]+'\\n\\n'+block+text[a:]
    else:text=text.rstrip()+'\\n\\n'+block
   p.write_text(text);destinations.append(str(p))
 dump(ROOT/'document_updates.json',dict(files=destinations))
'''
s=s[:a]+replacement+s[b:];p.write_text(s)
archive=root/'encoding_attempt_excluded';archive.mkdir(exist_ok=True)
for f in list(root.iterdir()):
 if f.name not in ['run_medpic.py','check_zero.py','fix_encoding.py','encoding_attempt_excluded']:
  shutil.move(str(f),str(archive/f.name))
(root/'encoding_correction.json').write_text('{"excluded_directory":"encoding_attempt_excluded","reason":"Chinese answer labels were replaced by question marks during initial PowerShell stdin transfer. Correct UTF-8 transfer, regenerate prompts, rerun all options."}\n')
