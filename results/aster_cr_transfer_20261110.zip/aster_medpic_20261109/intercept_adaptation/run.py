
"""Target-task scalar intercept fit; frozen weights; fixed-error retest."""
from pathlib import Path
import json,random,itertools,sys
import numpy as np
from scipy.special import expit
from scipy.optimize import brentq
ROOT=Path('/home/gcx/aster_medpic_20261109')
OUT=ROOT/'intercept_adaptation'
DATA=Path('/home/gcx/aster_cr_repair_v2_run_20261108/external/medpic')
METHODS=['raw','old_linear','optimized_balanced_fit_calibration','optimized_strict_fit_calibration']
LABELS=['原模型','原16维','平衡版','严格保护版']
VARIANTS=['original_independent','legal_only','calibrated_legal']
def rows(p):return [json.loads(s) for s in Path(p).read_text().splitlines() if s.strip()]
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def write_rows(p,v):Path(p).write_text(''.join(json.dumps(x,ensure_ascii=False,allow_nan=False)+'\n' for x in v),encoding='utf-8')
def source_biases():
 m=json.loads((ROOT/'frozen_methods.json').read_text());w=np.load(m['original_linear_weights'])
 return dict(raw=0.,old_linear=float(w[m['original_linear_key']+'_b']),**{k:float(v['b']) for k,v in m['methods'].items()})
def prepare():
 items=rows(DATA/'items.jsonl');groups=rows(DATA/'groups.jsonl')
 grouped={i for g in groups for i in g['members']}
 singles=sorted(i['id'] for i in items if i['id'] not in grouped)
 rng=random.Random(20261109);selected=rng.sample(sorted(groups,key=lambda g:g['group_id']),18)
 selected_singles=rng.sample(singles,57)
 dev=set(selected_singles)|{i for g in selected for i in g['members']}
 oldq={q['item_id'] for q in rows(ROOT/'fixed_old_linear_errors/questions.jsonl')}
 evalids=oldq-dev
 dump(OUT/'split.json',dict(seed=20261109,development_groups=[g['group_id'] for g in selected],
  development_singletons=selected_singles,development_item_ids=sorted(dev),
  evaluation_fixed_error_item_ids=sorted(evalids),excluded_development_old_error_item_ids=sorted(oldq&dev),
  development_questions=len(dev),evaluation_fixed_error_questions=len(evalids),
  split_policy='18 of 90 existing case groups plus 57 unpaired items, sampling ignores labels and scores.',
  evaluation_scope='Original fixed old_linear errors outside development only; exploratory adaptation.',
  same_group_never_crosses_split=True))
 dump(OUT/'plan.json',dict(methods=METHODS,trainable_parameters_per_method=1,
  fit_objective='Mean independent-option Bernoulli cross entropy on development options',
  score_formula='saved_score - source_intercept + fitted_intercept',
  decoder='None alone or nonempty other-option subsets, maximize selected logits sum; no-None retain independent selection.',
  evaluation='Only fixed old_linear error questions/options/pairs outside development.',
  development_questions=len(dev),evaluation_fixed_error_questions=len(evalids),
  weights_and_gains_frozen=True,gpus=[],expected_runtime_seconds=30))
def fit():
 dev=set(json.loads((OUT/'split.json').read_text())['development_item_ids'])
 rr=[r for r in rows(ROOT/'option_results.jsonl') if r['item_id'] in dev]
 y=np.array([r['label'] for r in rr]);biases=source_biases();entries={}
 for m in METHODS:
  z=np.array([r['scores'][m]-biases[m] for r in rr])
  gradient=lambda b:float(np.mean(expit(z+b)-y))
  lo,hi=-64.,64.
  while gradient(lo)>0:lo*=2
  while gradient(hi)<0:hi*=2
  b=float(brentq(gradient,lo,hi,xtol=1e-12))
  ce=lambda s:float(np.mean(np.logaddexp(0,s)-y*s))
  entries[m]=dict(source_intercept=biases[m],replacement_intercept=b,added_offset=b-biases[m],
   development_options=len(rr),development_positive_options=int(y.sum()),
   development_ce_before=ce(z+biases[m]),development_ce_after=ce(z+b),gradient_at_solution=gradient(b))
 dump(OUT/'frozen_intercepts.json',dict(fit_only_development=True,methods=entries,
  no_model_weight_or_gain_changes=True,fit_objective='Option-level mean BCE, one scalar intercept per method'))
def decode(item,scores):
 letters=list(item['options']);none=[k for k in letters if 'none of' in item['options'][k].lower()]
 if not none:return [k for k in letters if scores[k]>0]
 others=[k for k in letters if k not in none]
 candidates=[none]+[list(c) for n in range(1,len(others)+1) for c in itertools.combinations(others,n)]
 return max(candidates,key=lambda c:sum(scores[k] for k in c))
def evaluate():
 split=json.loads((OUT/'split.json').read_text());dev=set(split['development_item_ids'])
 fitdata=json.loads((OUT/'frozen_intercepts.json').read_text())['methods']
 evalq=set(split['evaluation_fixed_error_item_ids'])
 items={i['id']:i for i in rows(DATA/'items.jsonl')};rr={r['id']:r for r in rows(ROOT/'option_results.jsonl')}
 qresults=[];decisions={};methods={}
 def score(m,v,key):return rr[key]['scores'][m]+(fitdata[m]['added_offset'] if v=='calibrated_legal' else 0.)
 def predict(m,v,qid):
  item=items[qid];s={k:score(m,v,qid+':'+k) for k in item['options']}
  pred=[k for k in s if s[k]>0] if v=='original_independent' else decode(item,s)
  for k in s:decisions[m,v,qid+':'+k]=int(k in pred)
  return pred
 def decision(m,v,key):
  if (m,v,key) not in decisions:predict(m,v,rr[key]['item_id'])
  return decisions[m,v,key]
 for m in METHODS:
  methods[m]={}
  for v in VARIANTS:
   correct=0;optioncorrect=0;totaloptions=0;contradictions=0
   for qid in sorted(evalq):
    item=items[qid];pred=predict(m,v,qid);ok=set(pred)==set(item['answer']);correct+=ok
    contradictions+=int(len(pred)>1 and any('none of' in item['options'][k].lower() for k in pred))
    for k in item['options']:
     optioncorrect+=int((k in pred)==bool(rr[qid+':'+k]['label']));totaloptions+=1
    qresults.append(dict(item_id=qid,method=m,variant=v,predicted_answer=pred,gold_answer=item['answer'],correct=ok))
   methods[m][v]=dict(questions=len(evalq),correct_questions=int(correct),question_accuracy=correct/len(evalq),
    evaluated_options_in_error_questions=totaloptions,correct_options_in_error_questions=optioncorrect,
    option_accuracy_in_error_questions=optioncorrect/totaloptions,none_plus_other_sets=contradictions)
 byq={(r['method'],r['variant'],r['item_id']):r for r in qresults}
 for m in METHODS:
  before=np.array([byq[m,'legal_only',q]['correct'] for q in sorted(evalq)])
  after=np.array([byq[m,'calibrated_legal',q]['correct'] for q in sorted(evalq)])
  ref=np.array([byq['raw','calibrated_legal',q]['correct'] for q in sorted(evalq)])
  methods[m]['calibration_changes_vs_legal_only']=dict(fixed=int(np.sum(~before&after)),
   regressed=int(np.sum(before&~after)),net_correct_change=int(after.sum()-before.sum()))
  methods[m]['calibrated_vs_calibrated_raw']=dict(net_correct_change=int(after.sum()-ref.sum()),
   correct_only_this_method=int(np.sum(after&~ref)),correct_only_raw=int(np.sum(ref&~after)))
 oldopts=[o for o in rows(ROOT/'fixed_old_linear_errors/options.jsonl') if o['item_id'] not in dev]
 for m in METHODS:
  methods[m]['fixed_wrong_option_pool']={v:dict(n=len(oldopts),
   correct=sum(decision(m,v,o['id'])==o['label'] for o in oldopts)) for v in VARIANTS}
 oldpairs=rows(ROOT/'fixed_old_linear_errors/pairs.jsonl')
 pp=[p for p in oldpairs if rr[p['left']]['item_id'] not in dev and rr[p['right']]['item_id'] not in dev]
 pairresults=[];pairmetrics={}
 for rel in ['changing','same_label_patient_change']:
  subset=[p for p in pp if p['relation']==rel];point={}
  if not subset:pairmetrics[rel]={};continue
  rawdy=np.array([rr[p['right']]['ell']-rr[p['left']]['ell'] for p in subset])
  direction=np.array([p['right_label']-p['left_label'] for p in subset]);original=direction*rawdy
  for m in METHODS:
   variants={};before_dy=None
   for v in VARIANTS:
    dy=np.array([score(m,v,p['right'])-score(m,v,p['left']) for p in subset]);paired=[]
    for p in subset:
     dl=decision(m,v,p['left']);dr=decision(m,v,p['right']);ok=dl==p['left_label'] and dr==p['right_label'];paired.append(ok)
     pairresults.append(dict(pair_id=p['pair_id'],relation=rel,method=m,variant=v,left_prediction=dl,right_prediction=dr,
      left_label=p['left_label'],right_label=p['right_label'],left_score=score(m,v,p['left']),right_score=score(m,v,p['right']),paired_correct=bool(ok)))
    stat=dict(n=len(subset),paired_correct=int(np.sum(paired)),paired_accuracy=float(np.mean(paired)),
     raw_difference_rms=float(np.sqrt(np.mean(rawdy**2))),difference_rms=float(np.sqrt(np.mean(dy**2))),
     correction_rms=float(np.sqrt(np.mean((dy-rawdy)**2))))
    if rel=='changing':
     changed=direction*dy
     stat.update(mean_evidence_retention=float(np.mean(changed)/np.mean(original)) if np.mean(original) else None,
      response_direction_degraded=int(np.sum((original>0)&(changed<=0))))
    if v=='legal_only':before_dy=dy
    if v=='calibrated_legal':stat['difference_max_change_from_intercept_fit']=float(np.max(np.abs(dy-before_dy)))
    variants[v]=stat
   point[m]=variants
  pairmetrics[rel]=point
 result=dict(scope='Exploratory intercept adaptation; only original fixed errors outside development evaluated.',
  counts=dict(development_questions=len(dev),development_options=len(dev)*5,evaluation_fixed_error_questions=len(evalq),
   evaluation_fixed_wrong_options=len(oldopts),evaluation_fixed_wrong_option_pairs=len(pp),
   changing_pairs=sum(p['relation']=='changing' for p in pp),same_label_pairs=sum(p['relation']!='changing' for p in pp)),
  methods=methods,pairs=pairmetrics,intercepts=fitdata,
  interpretation='Error-conditioned retest, not overall benchmark accuracy. All methods share decoder and calibration.',
  score_response_note='ER/RMS/direction use continuous scores; set-decoded predictions separately determine paired correctness.',
  verification=dict(development_eval_item_overlap=len(dev&evalq),
   development_pair_endpoint_overlap=sum(rr[p['left']]['item_id'] in dev or rr[p['right']]['item_id'] in dev for p in pp),
   no_gpu=True,weights_and_gains_unchanged=True))
 write_rows(OUT/'question_results.jsonl',qresults);write_rows(OUT/'pair_results.jsonl',pairresults)
 dump(OUT/'metrics.json',result);report(result);dump(OUT/'done.json',dict(state='complete',**result['counts']))
 print(json.dumps(dict(counts=result['counts'],methods={m:dict(original=methods[m]['original_independent']['correct_questions'],
  legal=methods[m]['legal_only']['correct_questions'],calibrated=methods[m]['calibrated_legal']['correct_questions'],
  changes=methods[m]['calibration_changes_vs_legal_only'],b=fitdata[m]['replacement_intercept']) for m in METHODS}),ensure_ascii=False))
def report(r):
 c=r['counts'];n=c['evaluation_fixed_error_questions']
 lines=['### MedPIC-Bench：合法答案集合解码与单参数截距适配','',
  f"按既有病例组抽取18组及57个单例，得到{c['development_questions']}个开发病例（{c['development_options']}个选项）。随机种子20261109，同组不跨集合。四种方法各自仅用开发选项交叉熵拟合一个截距，替换旧截距，权重和修正幅度不变。",
  '',f"复测仅包含开发集以外、事先固定的原16维错题，共{n}题。另复测{c['evaluation_fixed_wrong_options']}个固定错选项及{c['evaluation_fixed_wrong_option_pairs']}个固定错误选项对，其中翻转{c['changing_pairs']}对、标签保持{c['same_label_pairs']}对。以下均为错误子集结果，不代表完整467题准确率。",
  '','合法集合解码只允许“以上皆非”单选，或不含该项的其他选项非空子集，按已有logit选择最大独立二分类似然；无此选项的题沿用原独立判断。原模型也使用相同解码和校准。',
  '','| 方法 | 原独立判断全对 | 合法解码全对 | 加截距适配后全对 | 校准修复／退化 | 新截距 |','|---|---:|---:|---:|---:|---:|']
 for m,label in zip(METHODS,LABELS):
  d=r['methods'][m];chg=d['calibration_changes_vs_legal_only']
  lines.append(f"| {label} | {d['original_independent']['correct_questions']}/{n} | {d['legal_only']['correct_questions']}/{n} | {d['calibrated_legal']['correct_questions']}/{n} | {chg['fixed']}／{chg['regressed']} | {r['intercepts'][m]['replacement_intercept']:.4f} |")
 lines+=['','| 方法 | 固定翻转错对：仅合法解码全对 | 加校准后全对 | ER | 修正RMS | 方向退化 |','|---|---:|---:|---:|---:|---:|']
 for m,label in zip(METHODS,LABELS):
  p=r['pairs']['changing'].get(m)
  if not p:continue
  a=p['legal_only'];b=p['calibrated_legal'];er='未定义' if b['mean_evidence_retention'] is None else f"{100*b['mean_evidence_retention']:.2f}%"
  lines.append(f"| {label} | {a['paired_correct']}/{a['n']} | {b['paired_correct']}/{b['n']} | {er} | {b['correction_rms']:.4f} | {b['response_direction_degraded']} |")
 raw=r['methods']['raw']['calibrated_legal']['correct_questions']
 best=max(r['methods'][m]['calibrated_legal']['correct_questions'] for m in METHODS if m!='raw')
 lines+=['',f"相同解码和校准后，原模型在固定复测错题中全对{raw}题，三个修正版本中最好为{best}题。"+
  ('本轮未显示修正权重相对同条件原模型的准确率收益。' if best<=raw else '修正版本在该固定错题子集上存在数值收益，不能据此推断全数据收益。'),
  '','本轮校准对整题的收益较小，同时损害了固定翻转错对的配对判断：原模型由28/177降至21/177，三个修正版本均由37/177降至21/177。因此下一步保留合法集合解码作为统一读出方式，这次以独立选项交叉熵拟合的截距暂不作为最终配置。',
  '','截距在配对连续分数差中抵消，校准前后的ER、修正RMS及方向退化不变；合法集合的二值配对全对率另行统计。标签保持对仍是患者信息变化，不视作无关扰动。原16维在固定错例上的原准确率为零来自选集定义。',
  '','这是已看过整体结果后的探索性适配，开发拟合与本轮复测病例分开，没有根据复测结果选择截距或修改权重。原冻结迁移结果保留。全部复用缓存，没有GPU推理。',
  '','结果目录：/home/gcx/aster_medpic_20261109/intercept_adaptation/。split.json保存划分，frozen_intercepts.json保存参数，metrics.json与逐例JSONL保存结果。','']
 body='\n'.join(lines);(OUT/'REPORT.zh.md').write_text(body,encoding='utf-8')
 updates=json.loads((ROOT/'document_updates.json').read_text())['files']
 start='<!-- medpic-intercept-adaptation:start -->';end='<!-- medpic-intercept-adaptation:end -->';block=start+'\n'+body+end+'\n'
 for filename in updates:
  p=Path(filename);s=p.read_text()
  if start in s:
   a=s.index(start);b=s.index(end,a)+len(end);s=s[:a]+block+s[b:]
  elif '<!-- medpic-frozen-transfer:end -->' in s:
   a=s.index('<!-- medpic-frozen-transfer:end -->')+len('<!-- medpic-frozen-transfer:end -->');s=s[:a]+'\n\n'+block+s[a:]
  else:s=s.rstrip()+'\n\n'+block
  p.write_text(s,encoding='utf-8')
 dump(OUT/'document_updates.json',dict(files=updates))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='fit':fit()
 elif sys.argv[1]=='evaluate':evaluate()

