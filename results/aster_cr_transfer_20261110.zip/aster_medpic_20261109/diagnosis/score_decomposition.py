from pathlib import Path
import json,numpy as np
root=Path('/home/gcx/aster_medpic_20261109')
manifest=json.loads((root/'frozen_methods.json').read_text());w=np.load(manifest['original_linear_weights']);b={m:float(e['b']) for m,e in manifest['methods'].items()};b['old_linear']=float(w[manifest['original_linear_key']+'_b'])
records=[json.loads(s) for s in (root/'option_results.jsonl').read_text().splitlines()];pairs=[json.loads(s) for s in (root/'option_pairs.jsonl').read_text().splitlines()];questions=[json.loads(s) for s in (root/'question_results.jsonl').read_text().splitlines()]
y=np.array([r['label'] for r in records]);raw=np.array([r['ell'] for r in records]);ix={r['id']:i for i,r in enumerate(records)}
old=np.array([r['scores']['old_linear'] for r in records]);old_errors=(old>0)!=y
out=dict(source_intercepts=b,overall_label_prevalence=float(y.mean()),raw_prediction_positive=float(np.mean(raw>0)),raw_false_positive=int(np.sum((raw>0)&(y==0))),raw_false_negative=int(np.sum((raw<=0)&(y==1))),methods={},scope='Read-only score decomposition; no training or threshold search. Counterfactual predictions restricted to fixed old_linear error options/questions/pairs.')
oldq={q['item_id'] for q in questions if q['method']=='old_linear' and not q['correct']};oldpair={p['pair_id'] for p in pairs if not (((old[ix[p['left']]]>0)==p['left_label']) and ((old[ix[p['right']]]>0)==p['right_label']))}
qix={qid:[i for i,r in enumerate(records) if r['item_id']==qid] for qid in oldq}
for m,bias in b.items():
 score=np.array([r['scores'][m] for r in records]);delta=score-raw-bias
 errors=(score>0)!=y;new=errors&((raw>0)==y);fixed=(~errors)&((raw>0)!=y)
 part=dict(intercept=bias,delta_mean=float(np.mean(delta)),delta_rms=float(np.sqrt(np.mean(delta**2))),delta_percentiles=np.percentile(delta,[0,25,50,75,100]).tolist(),false_positive=int(np.sum((score>0)&(y==0))),false_negative=int(np.sum((score<=0)&(y==1))),saved_method_new_errors_vs_raw=int(new.sum()),saved_method_fixed_errors_vs_raw=int(fixed.sum()),new_errors_attributable_to_intercept_alone=int(np.sum(new&(((raw+bias)>0)!=y))),new_errors_present_without_intercept=int(np.sum(new&(((score-bias)>0)!=y))),fixed_old_error_pool={})
 for tag,s in [('raw',raw),('saved_score',score),('no_source_intercept',score-bias),('source_intercept_only',raw+bias)]:
  n=int(np.sum(old_errors&((s>0)==y)));q=sum(np.all((s[ii]>0)==y[ii]) for ii in qix.values());pp=[p for p in pairs if p['pair_id'] in oldpair]
  paircorrect=sum(((s[ix[p['left']]]>0)==p['left_label']) and ((s[ix[p['right']]]>0)==p['right_label']) for p in pp)
  part['fixed_old_error_pool'][tag]=dict(correct_options=n,total_options=int(old_errors.sum()),correct_question_sets=int(q),total_questions=len(qix),correct_option_pairs=int(paircorrect),total_option_pairs=len(pp))
 out['methods'][m]=part
flip=[p for p in pairs if p['relation']=='changing'];dy=np.array([(p['right_label']-p['left_label'])*(raw[ix[p['right']]]-raw[ix[p['left']]]) for p in flip])
out['raw_flip_pair_diagnostic']=dict(total=len(flip),gold_direction_positive=int(np.sum(dy>0)),gold_direction_wrong_or_zero=int(np.sum(dy<=0)),both_predict_no=sum((raw[ix[p['left']]]<=0) and (raw[ix[p['right']]]<=0) for p in flip),both_predict_yes=sum((raw[ix[p['left']]]>0) and (raw[ix[p['right']]]>0) for p in flip))
(root/'diagnosis').mkdir(exist_ok=True)
text=json.dumps(out,ensure_ascii=False,indent=2,default=lambda v:v.item())+'\n'
(root/'diagnosis/score_decomposition.json').write_text(text);print(text)
