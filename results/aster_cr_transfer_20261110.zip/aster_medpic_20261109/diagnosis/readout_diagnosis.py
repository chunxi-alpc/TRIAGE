"""CPU-only legal-set decoding on the frozen old_linear question error pool."""
from pathlib import Path
import json,itertools
ROOT=Path('/home/gcx/aster_medpic_20261109')
OUT=ROOT/'diagnosis'
DATA=Path('/home/gcx/aster_cr_repair_v2_run_20261108/external/medpic/items.jsonl')
METHODS=['raw','old_linear','optimized_balanced_fit_calibration','optimized_strict_fit_calibration']
def rows(p):return [json.loads(s) for s in Path(p).read_text().splitlines() if s.strip()]
def main():
 OUT.mkdir(exist_ok=True)
 items={r['id']:r for r in rows(DATA)}
 pool=rows(ROOT/'fixed_old_linear_errors/questions.jsonl')
 ids=[r['item_id'] for r in pool]
 records={r['id']:r for r in rows(ROOT/'option_results.jsonl')}
 result=dict(scope='Only the fixed 397 old_linear incorrect question sets; no full-dataset re-evaluation.',
  pool_source=str(ROOT/'fixed_old_linear_errors/questions.jsonl'),questions=len(ids),methods={},
  decoder='Enumerate None-alone and all nonempty subsets of other options. Maximize sum of selected saved logits, equivalent to independent Bernoulli log-likelihood; no fitting, threshold changes, or gold-based selection.',
  tie_policy='First maximum in deterministic option order: None alone first, then increasing subset size with source option order.',
  no_none_policy='Keep existing independent option predictions.',gpu_used=False)
 details=[]
 for method in METHODS:
  counts=dict(n=len(ids),correct_before=0,correct_after=0,fixed=0,regressed=0,unchanged_correct=0,still_wrong=0,
   none_plus_other_before=0,none_plus_other_after=0,empty_before=0,empty_after=0,changed_sets=0,no_none_questions=0,maximizer_ties=0)
  for item_id in ids:
   item=items[item_id];letters=list(item['options']);gold=set(item['answer'])
   scores={k:records[item_id+':'+k]['scores'][method] for k in letters}
   before=[k for k in letters if scores[k]>0]
   none=[k for k in letters if 'none of' in item['options'][k].lower()]
   if none:
    if len(none)!=1:raise ValueError('Expected exactly one None option')
    others=[k for k in letters if k not in none]
    candidates=[none]+[list(c) for size in range(1,len(others)+1) for c in itertools.combinations(others,size)]
    values=[sum(scores[k] for k in c) for c in candidates]
    maximum=max(values);chosen=values.index(maximum);after=candidates[chosen]
    tied=sum(v==maximum for v in values)>1
   else:
    counts['no_none_questions']+=1;after=before;tied=False
   correct_before=set(before)==gold;correct_after=set(after)==gold
   c_before=bool(len(before)>1 and any(k in none for k in before))
   c_after=bool(len(after)>1 and any(k in none for k in after))
   counts['correct_before']+=correct_before;counts['correct_after']+=correct_after
   counts['fixed']+=not correct_before and correct_after
   counts['regressed']+=correct_before and not correct_after
   counts['unchanged_correct']+=correct_before and correct_after
   counts['still_wrong']+=not correct_before and not correct_after
   counts['none_plus_other_before']+=c_before;counts['none_plus_other_after']+=c_after
   counts['empty_before']+=not before;counts['empty_after']+=not after
   counts['changed_sets']+=set(before)!=set(after);counts['maximizer_ties']+=tied
   details.append(dict(item_id=item_id,method=method,gold_answer=item['answer'],before=before,after=after,
    correct_before=correct_before,correct_after=correct_after,scores=scores,none_letters=none,maximum_tie=tied))
  result['methods'][method]=counts
 (OUT/'readout_metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 (OUT/'readout_cases.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in details))
 labels=['原模型','原16维','平衡版','严格保护版']
 lines=['# 固定错题内的合法答案集合解码诊断','','只在原16维方法固定的397个错题中复用已有logit。允许“以上皆非”单选，或其他选项的任意非空子集；最大化独立二分类对数似然，不改变分数、阈值和权重，不按金标选策略。不含“以上皆非”的题保持原输出。','','| 方法 | 原全对 | 解码后全对 | 修复 | 新增错误 | 矛盾集合前→后 |','|---|---:|---:|---:|---:|---:|']
 for m,label in zip(METHODS,labels):
  c=result['methods'][m]
  lines.append(f"| {label} | {c['correct_before']} | {c['correct_after']} | {c['fixed']} | {c['regressed']} | {c['none_plus_other_before']}→{c['none_plus_other_after']} |")
 lines+=['','本结果仅描述已固定的错误子集，不能据此计算完整467题的改进或证明整体泛化收益。原16维在该子集上原全对为0是选集定义导致。该诊断使用逻辑约束，不使用医学金标决定输出；金标仅用于最后计分。','']
 (OUT/'readout_report.zh.md').write_text('\n'.join(lines))
 print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
