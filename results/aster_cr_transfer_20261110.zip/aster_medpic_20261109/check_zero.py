from pathlib import Path
import json,sys,numpy as np
sys.path.insert(0,'/home/gcx/aster_next_20261109/inference')
from frozen import FrozenMethods
root=Path('/home/gcx/aster_medpic_20261109')
a=FrozenMethods(root/'frozen_methods.json')
a.w=np.zeros_like(a.w);a.linear_b=0.;a.bias=0.
for e in a.manifest['methods'].values():e['gain']=0.;e['b']=0.
records=[]
for g in [0,1]:
 p=root/('shard'+str(g))/'scores.jsonl'
 if p.exists():
  lines=p.read_text().splitlines()
  if lines:records.append(json.loads(lines[0]))
if len(records)!=2:raise RuntimeError('Wait until both workers have first saved result')
err=[]
for r in records:
 with np.load(r['feature']) as f:
  pred=a.predict(r['ell'],f['selected_heads'],f['residual'])
 err.extend(abs(v-r['ell']) for v in pred.values())
result=dict(passed=max(err)==0,max_score_error=max(err),records=len(records),
 policy='Set existing correction weights/gains and intercepts to zero in memory, reuse actual saved features through FrozenMethods.predict; no stored parameters modified.')
(root/'zero_correction_check.json').write_text(json.dumps(result,indent=2)+'\n')
