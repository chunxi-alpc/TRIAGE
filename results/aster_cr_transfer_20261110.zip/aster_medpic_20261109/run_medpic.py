from pathlib import Path
import sys,json,time,argparse,traceback,subprocess,os
import numpy as np
ROOT=Path('/home/gcx/aster_medpic_20261109')
DATA=Path('/home/gcx/aster_cr_repair_v2_run_20261108/external/medpic')
sys.path.insert(0,'/home/gcx/aster_next_20261109/inference')
from frozen import FrozenMethods
from run import score_selected,Engine
sys.path.insert(0,'/home/gcx/aster_next_20261109/analysis')
from summarize_error_pairs import stats
METHODS=['raw','old_linear','optimized_balanced_fit_calibration','optimized_strict_fit_calibration']
def rows(p):return [json.loads(s) for s in Path(p).read_text().splitlines() if s.strip()] if Path(p).exists() else []
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def write_rows(p,x):Path(p).write_text(''.join(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n' for r in x))
def append(p,r):
 with Path(p).open('a') as f:f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
def prepare():
 import copy
 manifest=json.loads(Path('/home/gcx/aster_next_20261109/frozen_methods.json').read_text())
 manifest['methods']={k:v for k,v in manifest['methods'].items() if k in METHODS}
 manifest['dataset']='MedPIC-Bench';manifest['training']='none; all weights, gains and intercepts copied unchanged'
 dump(ROOT/'frozen_methods.json',manifest)
 cases=[]
 for item in rows(DATA/'items.jsonl'):
  choices='\n'.join(k+'. '+v for k,v in item['options'].items())
  for letter,option in item['options'].items():
   text=('Patient:\n'+item['patient_vignette']+'\n\nQuestion:\n'+item['question']+'\n\nOptions:\n'+choices+
    '\n\nCurrent option: '+letter+'. '+option+'\nDoes this option belong in the correct answer set for the question above? '
    'Judge this option independently. Answer only 是 (Yes) or 否 (No).\nAnswer:')
   cases.append(dict(id=item['id']+':'+letter,item_id=item['id'],option_letter=letter,option_text=option,
    label=int(letter in item['answer']),prompt=text))
 write_rows(ROOT/'cases.jsonl',cases);ix={c['id']:c for c in cases};pairs=[]
 for p in rows(DATA/'pairs.jsonl'):
  for left,right in p['option_map'].items():
   l=p['left']+':'+left;r=p['right']+':'+right
   yl=ix[l]['label'];yr=ix[r]['label']
   pairs.append(dict(pair_id=p['pair_id']+':'+left+'-'+right,case_pair_id=p['pair_id'],group_id=p['group_id'],
    left=l,right=r,left_label=yl,right_label=yr,relation='changing' if yl!=yr else 'same_label_patient_change'))
 write_rows(ROOT/'option_pairs.jsonl',pairs)
 dump(ROOT/'plan.json',dict(gpus=[0,1],expected_memory_gib_per_gpu=[18,22],expected_minutes=[15,30],
  items=len(rows(DATA/'items.jsonl')),options=len(cases),case_pairs=len(rows(DATA/'pairs.jsonl')),
  flip_pairs=sum(p['relation']=='changing' for p in pairs),same_label_pairs=sum(p['relation']!='changing' for p in pairs),
  methods=METHODS,new_training=False,source_data=str(DATA),prompt_policy='Full vignette, question and all choices; independently judge each option; same existing Chinese Yes/No token projection.',
  error_policy='Freeze old_linear incorrect options, incorrect question sets and incorrect option pairs; later optimization only retests these saved pools.'))
def worker(gpu):
 import torch
 torch.set_num_threads(2);torch.cuda.set_device(gpu)
 out=ROOT/('shard'+str(gpu));out.mkdir(exist_ok=True);(out/'features').mkdir(exist_ok=True)
 cases=rows(ROOT/'cases.jsonl')[gpu::2];done={r['id'] for r in rows(out/'scores.jsonl')}
 adapter=FrozenMethods(ROOT/'frozen_methods.json');start=time.time();engine=Engine('qwen',device='cuda:'+str(gpu))
 for c in cases:
  if c['id'] in done:continue
  result=score_selected(engine,c['prompt'],adapter.heads)
  if not (out/'interface_check.json').exists():
   canonical=engine.score(c['prompt'],capture=True)
   fullheads=canonical['heads'].numpy().reshape(-1,engine.head_dim)[adapter.heads].reshape(-1)
   checks=dict(ell_abs_error=abs(result['ell']-canonical['ell']),
    heads_max_abs_error=float(np.max(np.abs(fullheads-result['selected_heads'].astype('float32')))),
    residual_max_abs_error=float(np.max(np.abs(canonical['residual'].numpy()-result['residual'].astype('float32')))))
   checks['passed']=max(checks.values())<=1e-5;dump(out/'interface_check.json',checks)
   if not checks['passed']:raise RuntimeError('Existing scoring interface mismatch')
  feature=out/'features'/(c['id']+'.npz')
  np.savez_compressed(feature,selected_heads=result.pop('selected_heads'),residual=result.pop('residual'))
  with np.load(feature) as a:scores=adapter.predict(result['ell'],a['selected_heads'],a['residual'])
  record=dict(id=c['id'],item_id=c['item_id'],option_letter=c['option_letter'],label=c['label'],feature=str(feature),
   ell=result['ell'],scores={m:scores[m] for m in METHODS},tokens=result['tokens'])
  append(out/'scores.jsonl',record);done.add(c['id'])
  if len(done)%25==0:dump(out/'status.json',dict(state='running',completed=len(done),total=len(cases),seconds=time.time()-start,peak_gib=torch.cuda.max_memory_allocated(gpu)/2**30))
 dump(out/'done.json',dict(state='complete',completed=len(done),total=len(cases),seconds=time.time()-start,peak_gib=torch.cuda.max_memory_allocated(gpu)/2**30))
def summarize():
 cases=rows(ROOT/'cases.jsonl');pairs=rows(ROOT/'option_pairs.jsonl');items=rows(DATA/'items.jsonl')
 records=rows(ROOT/'shard0/scores.jsonl')+rows(ROOT/'shard1/scores.jsonl');ix={r['id']:r for r in records}
 if len(ix)!=len(cases):raise RuntimeError('Incomplete option scores: '+str(len(ix)))
 metadata={p['pair_id']:p for p in pairs};scoremap={};pair_results=[]
 for p in pairs:
  for m in METHODS:
   l=ix[p['left']]['scores'][m];r=ix[p['right']]['scores'][m]
   row=dict(pair_id=p['pair_id'],method=m,left_score=l,right_score=r,
    paired_correct=bool(int(l>0)==p['left_label'] and int(r>0)==p['right_label']),
    raw_difference=ix[p['right']]['ell']-ix[p['left']]['ell'],difference=r-l,relation=p['relation'])
   row['correction_difference']=row['difference']-row['raw_difference']
   scoremap[m,p['pair_id']]=row;pair_results.append(row)
 groups={}
 for rel in ['changing','same_label_patient_change']:
  ids=[p['pair_id'] for p in pairs if p['relation']==rel];groups[rel]={}
  for m in METHODS:
   point=stats(ids,metadata,scoremap,m,'changing' if rel=='changing' else 'same_label_patient_change')
   if rel=='changing':point['mean_evidence_retention']=point['signed_response_retention']
   else:point.pop('variance_reduction',None)
   groups[rel][m]=point
 questions=[];option_metrics={};question_metrics={}
 for m in METHODS:
  correct=sum(int(r['scores'][m]>0)==r['label'] for r in records)
  option_metrics[m]=dict(n=len(records),correct=correct,accuracy=correct/len(records))
  qcorrect=0
  for item in items:
   pred=[k for k in item['options'] if ix[item['id']+':'+k]['scores'][m]>0];ok=set(pred)==set(item['answer']);qcorrect+=ok
   questions.append(dict(item_id=item['id'],method=m,predicted_answer=pred,gold_answer=item['answer'],correct=ok))
  question_metrics[m]=dict(n=len(items),correct=qcorrect,accuracy=qcorrect/len(items))
 old_options=[dict(c,score=ix[c['id']]['scores']['old_linear']) for c in cases if int(ix[c['id']]['scores']['old_linear']>0)!=c['label']]
 old_questions=[q for q in questions if q['method']=='old_linear' and not q['correct']]
 old_pair_ids={r['pair_id'] for r in pair_results if r['method']=='old_linear' and not r['paired_correct']}
 (ROOT/'fixed_old_linear_errors').mkdir(exist_ok=True)
 write_rows(ROOT/'fixed_old_linear_errors/options.jsonl',old_options)
 write_rows(ROOT/'fixed_old_linear_errors/questions.jsonl',old_questions)
 write_rows(ROOT/'fixed_old_linear_errors/pairs.jsonl',[p for p in pairs if p['pair_id'] in old_pair_ids])
 write_rows(ROOT/'option_results.jsonl',sorted(records,key=lambda r:r['id']));write_rows(ROOT/'question_results.jsonl',questions)
 write_rows(ROOT/'pair_results.jsonl',pair_results)
 raw=np.array([r['ell'] for r in records]);zero=raw+np.zeros_like(raw)
 verification=dict(expected_options=len(cases),scored_options=len(ix),missing_options=[],
  expected_option_pairs=len(pairs),scored_option_pairs=len(pair_results)//len(METHODS),
  zero_correction_raw_max_error=float(np.max(np.abs(zero-raw))),zero_correction_prediction_equal=bool(np.array_equal(zero>0,raw>0)),
  scorer='Existing run.score_selected and FrozenMethods.predict; checked against Engine.score on first option of each shard',
  metric_interface='Existing summarize_error_pairs.stats; same-label VR omitted because patient information changes.',
  interface_checks=[json.loads((ROOT/('shard'+str(g))/'interface_check.json').read_text()) for g in [0,1]])
 result=dict(dataset='MedPIC-Bench',scope='Exploratory frozen transfer; no fitting or recalibration',
  coverage=json.loads((ROOT/'plan.json').read_text()),groups=groups,option_metrics=option_metrics,question_metrics=question_metrics,
  old_linear_error_counts=dict(options=len(old_options),questions=len(old_questions),pairs=len(old_pair_ids)),verification=verification,
  interpretation='Same-label pairs remain patient-information changes, not nuisance perturbations. Evidence retention is ratio of mean label-signed responses relative to raw; 1 does not imply correct answers.')
 dump(ROOT/'metrics.json',result);dump(ROOT/'verification.json',verification)
 document(result)
 dump(ROOT/'done.json',dict(state='complete',options=len(ix),questions=len(items),option_pairs=len(pairs),methods=METHODS))
def document(result):
 labels=['原始 Qwen3-8B','原16维受约束方法','已有平衡版本','已有严格保护版本']
 lines=['### MedPIC-Bench：冻结方法的探索性迁移试测','','官方数据共467题、2,335个选项；现有90组含92个病例对，按选项文本映射得到244个标签翻转对和216个标签保持对。每个选项独立作是／否判断，再还原多选答案集合。全部复用既有权重、幅度和截距，无新增训练或校准。','','| 方法 | 翻转对响应保留率 | 修正RMS（logit） | 方向退化 | 翻转对全对 | 选项准确率 | 整题全对 |','|---|---:|---:|---:|---:|---:|---:|']
 for m,label in zip(METHODS,labels):
  x=result['groups']['changing'][m];o=result['option_metrics'][m];q=result['question_metrics'][m]
  er='未定义' if x['mean_evidence_retention'] is None else f"{100*x['mean_evidence_retention']:.2f}%"
  lines.append(f"| {label} | {er} | {x['correction_rms']:.4f} | {x['response_direction_degraded']} | {x['paired_correct']}/{x['n']} | {100*o['accuracy']:.2f}% | {q['correct']}/{q['n']}（{100*q['accuracy']:.2f}%） |")
 lines+=['','标签保持的216对单列如下；患者信息仍有变化，不能直接视为无关信息扰动。','','| 方法 | 原响应RMS | 修正后响应RMS | 修正RMS | 配对全对 |','|---|---:|---:|---:|---:|']
 for m,label in zip(METHODS,labels):
  x=result['groups']['same_label_patient_change'][m]
  lines.append(f"| {label} | {x['raw_difference_rms']:.4f} | {x['difference_rms']:.4f} | {x['correction_rms']:.4f} | {x['paired_correct']}/{x['n']} |")
 e=result['old_linear_error_counts']
 lines+=['','响应保留率沿用既有计分接口，为标签方向加权后的平均响应相对原模型的比值；修正RMS计算配对分数差的改变量，方向退化计原本沿正确标签方向的响应变为非正的对数。响应保留率接近100%只说明接近原响应，需结合配对全对率判断。','',f"全部选项和460个选项对均有结果。两个分片均通过原计分接口的一致性验证，零修正还原原始分数及预测。原16维方法固定保存{e['options']}个错选项、{e['questions']}个错题和{e['pairs']}个错误选项对，后续优化仅复测这些错例。",'','结果目录：`/home/gcx/aster_medpic_20261109`；逐例结果为 `option_results.jsonl`、`question_results.jsonl`、`pair_results.jsonl`，指标为 `metrics.json`，固定错例位于 `fixed_old_linear_errors/`。','']
 body='\n'.join(lines);(ROOT/'REPORT.zh.md').write_text(body)
 start='<!-- medpic-frozen-transfer:start -->';end='<!-- medpic-frozen-transfer:end -->';block=start+'\n'+body+end+'\n'
 destinations=[]
 for base in [Path('/home/gcx/aster_cancel_story_20261109'),Path('/home/gcx/aster-real-completion-publish-20261109/reports/aster_cancel_story_20261109')]:
  for rel in ['paper_story_latest.zh.md','meeting/meeting_brief.zh.md']:
   p=base/rel
   if not p.exists():continue
   text=p.read_text()
   if start in text:
    a=text.index(start);b=text.index(end,a)+len(end);text=text[:a]+block+text[b:]
   else:
    if rel.startswith('paper') and '\n## 9.' in text:
     a=text.index('\n## 9.');text=text[:a]+'\n\n'+block+text[a:]
    else:text=text.rstrip()+'\n\n'+block
   p.write_text(text);destinations.append(str(p))
 dump(ROOT/'document_updates.json',dict(files=destinations))
def pipeline():
 env=os.environ.copy();env['OMP_NUM_THREADS']='2';env['OPENBLAS_NUM_THREADS']='2'
 jobs=[]
 for g in [0,1]:
  f=(ROOT/('gpu'+str(g)+'.log')).open('a');p=subprocess.Popen([sys.executable,__file__,'worker','--gpu',str(g)],stdout=f,stderr=subprocess.STDOUT,env=env);jobs.append((p,f))
 dump(ROOT/'pids.json',dict(controller=os.getpid(),workers=[p.pid for p,f in jobs]))
 codes=[p.wait() for p,f in jobs]
 for p,f in jobs:f.close()
 if any(codes):raise RuntimeError('Worker failed; exit codes '+str(codes))
 summarize()
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','worker','summarize','pipeline']);ap.add_argument('--gpu',type=int);args=ap.parse_args()
 try:
  if args.mode=='prepare':prepare()
  elif args.mode=='worker':worker(args.gpu)
  elif args.mode=='summarize':summarize()
  else:pipeline()
 except Exception as exc:
  dump(ROOT/('failed_'+args.mode+('_'+str(args.gpu) if args.gpu is not None else '')+'.json'),dict(error=str(exc),traceback=traceback.format_exc()));raise
