# 固定 MEGA 头后续实验

本轮已完成。结论与完整表格见 [REPORT.zh.md](REPORT.zh.md)。

运行环境为服务器 /home/gcx/gcx261014，新增训练使用物理 GPU 6。独立入口 followup.py 支持 diagnose、train、evaluate、all。截距诊断和评价使用 CPU，训练阶段设置 CUDA_VISIBLE_DEVICES=6。report_zh.py 从保存的结果文件生成 UTF-8 中文报告。

G0 复用原 C 网络，仅重选增益和截距；G1 增加标签改变对分类监督；G2 删除原保护项和训练后幅度缩放。模型维持 99 维输入、128 宽度、三种子等权集成；不运行大模型。完整逐例分数、逐题答案集合、配对预测、检查点、开发集候选与日志均保留于本目录。inference.py 继承原单输入推理接口。

本轮是已看过测试结果后的探索性后续实验，所有选参使用开发集。细节及置信区间见各任务 test_metrics.json。
