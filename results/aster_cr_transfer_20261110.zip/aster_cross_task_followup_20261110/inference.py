"""Reuse the original saved single-input inference interface for selected G0/G1/G2."""
import sys,json
from pathlib import Path
import torch
ROOT=Path('/home/gcx/aster_cross_task_followup_20261110')
sys.path.insert(0,'/home/gcx/aster_cross_task_transfer_20261109')
from predict import Predictor
from fit import Editor

class FollowupPredictor(Predictor):
 def __init__(self,task):
  super().__init__(task)
  selected=json.loads((ROOT/task/'selected_parameters.json').read_text())
  self.methods={name:dict(config='C',gain=e['gain'],b=e['b'],members=e['members']) for name,e in selected.items()}
  for e in self.methods.values():
   for member in e['members']:
    path=member['model_file']
    if path not in self.models:
     s=torch.load(path,map_location='cpu',weights_only=False)
     model=Editor();model.load_state_dict(s['state_dict']);model.eval()
     self.models[path]=(model,s['mu'],s['scale'])
 # Inherited predict(ell, full_heads, residual) keeps the original feature order
 # and returns raw plus all six selected follow-up scores. MedPIC uses evaluate.decode.

