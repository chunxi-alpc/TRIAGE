"""Fixed MEGA heads follow-up. Run only in gcx261014 on server.
Stages: diagnose (CPU), train (GPU 6), evaluate (CPU), all.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('MKL_NUM_THREADS','2')
import sys,json,time,csv,collections,traceback,argparse
from pathlib import Path
import numpy as np
import torch
from scipy.special import expit
from scipy.optimize import brentq
OLD=Path('/home/gcx/aster_cross_task_transfer_20261109')
OUT=Path('/home/gcx/aster_cross_task_followup_20261110')
sys.path.insert(0,str(OLD))
from common import rows,dump,lines,rms
from fit import Editor,load,natural,pidx,feature_matrices,tail,calibrate
from evaluate import decode,write_csv,interval,safe_ratio
TASKS=('nli4ct','medpic')
SCHEMES=('tail_pair','tail_robust')
torch.set_num_threads(2)

def status(**kw):
 dump(OUT/'status.json',dict(updated=time.strftime('%Y-%m-%d %H:%M:%S'),**kw))

def balanced(ids):
 cnt=collections.Counter(ids)
 return np.array([1/len(cnt)/cnt[s] for s in ids],float)

class Data:
 def __init__(self,task):
  self.task=task
  self.vv,self.pp,self.rr,self.ix,self.ell,self.y=load(task)
  self.out=OUT/task;self.out.mkdir(exist_ok=True)
  self.cp=json.loads((OLD/task/'C/parameters.json').read_text())['methods']
  self.ap=json.loads((OLD/task/'A_parameters.json').read_text())
  self.items=rows(OLD/task/'items.jsonl') if task=='medpic' else []
  self.n={s:natural(self.vv,s) for s in ('fit','dev','test')}
  self.p={}
  for s in ('fit','dev','test'):
   self.p[s]={}
   for k,kinds in [('AP',('A','P')),('CF',('C','F')),('F0',('F0',))]:
    ps=[p for p in self.pp if p['split']==s and p['kind'] in kinds]
    self.p[s][k]=(np.array([self.ix[p['left']] for p in ps],int),np.array([self.ix[p['right']] for p in ps],int),[p['source_id'] for p in ps],ps)
  self.nw=balanced([self.vv[i]['source_id'] for i in self.n['fit']])
  self.pw=balanced(self.p['fit']['CF'][2])
  self.qs={}
  for split in ('fit','dev','test'):
   self.qs[split]=[]
   if self.items:
    for item in self.items:
     pos={k:self.ix[item['id']+':'+k] for k in item['options']}
     first=next(iter(pos.values()))
     if self.vv[first]['split']==split:
      self.qs[split].append((item,pos,self.vv[first]['source_id']))

 def bias(self,e,mode,scheme):
  ni=self.n['fit'];l,r,_,_=self.p['fit']['CF']
  if mode=='zero':return 0.
  if mode=='source':return float(self.ap['A_'+scheme]['entry']['b'])
  if mode=='natural':return calibrate(e[ni],self.y[ni])
  # Half group-balanced natural BCE, half group-balanced mean of pair-side BCE.
  def f(b):
   n=np.dot(self.nw,expit(e[ni]+b)-self.y[ni])
   p=np.dot(self.pw,((expit(e[l]+b)-self.y[l])+(expit(e[r]+b)-self.y[r]))/2)
   return float((n+p)/2)
  return float(brentq(f,-200,200))

 def decisions(self,score,split):
  dec=(score>0).astype(int);qc=[];qg=[];qrows=[]
  for item,pos,group in self.qs[split]:
   pred=decode(item,{k:score[i] for k,i in pos.items()})
   for k,i in pos.items():dec[i]=int(k in pred)
   ok=set(pred)==set(item['answer'])
   qc.append(ok);qg.append(group)
   qrows.append(dict(item_id=item['id'],source_id=group,predicted=pred,gold=item['answer'],correct=ok,selected_options=len(pred)))
  ni=self.n[split]
  if not self.items:
   qc=(dec[ni]==self.y[ni]);qg=[self.vv[i]['source_id'] for i in ni]
  return dec,np.array(qc,float),qg,qrows

 def metrics(self,score,split):
  dec,qc,qg,qr=self.decisions(score,split);ni=self.n[split]
  al,ar,_,_=self.p[split]['AP'];cl,cr,_,_=self.p[split]['CF']
  raw=self.ell[ar]-self.ell[al];ap=score[ar]-score[al]
  rawc=self.ell[cr]-self.ell[cl];cf=score[cr]-score[cl];dy=self.y[cr]-self.y[cl]
  paired=(dec[cl]==self.y[cl])&(dec[cr]==self.y[cr])
  return dict(correct=int(qc.sum()),questions=len(qc),accuracy=float(qc.mean()),
   cf_correct=int(paired.sum()),cf_pairs=len(cl),cf_paired_accuracy=float(paired.mean()),
   positive_label_fraction=float(dec[ni].mean()),positive_score_fraction=float((score[ni]>0).mean()),
   mean_selected_options=float(np.mean([q['selected_options'] for q in qr])) if qr else None,
   variance_reduction=float(1-np.var(ap)/np.var(raw)),
   evidence_retention=float(np.sum(dy*cf)/np.sum(dy*rawc)),
   correction_rms=rms(score[ni]-self.ell[ni]),
   cf_correction_rms=rms(cf-rawc))

def project(h,r,ell,sup,rb):
 z=(h-sup['mu'])/sup['scale']
 return np.concatenate([z@sup['N'],z@sup['S'],((r-rb['mu'])/rb['scale'])@rb['R'],np.column_stack([ell/10,np.abs(ell)/10,np.tanh(ell/4)])],axis=1).astype('float32')

def model_delta(x,entry):
 result=np.zeros(len(x))
 for member in entry['members']:
  s=torch.load(member['model_file'],map_location='cpu',weights_only=False)
  m=Editor();m.load_state_dict(s['state_dict']);m.eval()
  z=((x-s['mu'])/s['scale']).astype('float32')
  with torch.no_grad():
   result+=member['coefficient']*np.concatenate([m(torch.from_numpy(z[j:j+1024])).numpy() for j in range(0,len(x),1024)])
 return result

def prepare(d):
 cache=d.out/'cache.npz'
 if cache.exists():return dict(np.load(cache))
 status(state='running',stage='cached_feature_projection',task=d.task)
 sup=dict(np.load(OLD/d.task/'C_support.npz'));rb=dict(np.load(OLD/d.task/'target_residual_basis.npz'))
 h,r=feature_matrices(d.vv,d.rr,sup['heads'].astype(int))
 x=project(h,r,d.ell,sup,rb)
 norm=dict(np.load(OLD/d.task/'C/normalization.npz'))
 result={'x':x,'z':((x-norm['mu'])/norm['scale']).astype('float32')}
 ax=project(h,r,d.ell,dict(np.load('/home/gcx/aster_cr_repair_v2_run_20261108/qwen/supports_r16.npz')),dict(np.load('/home/gcx/aster_optimization_20261109/shared/residual_basis.npz')))
 old=dict(np.load(OLD/d.task/'scores_final.npz'));errors={}
 for scheme in SCHEMES:
  for config,xx,entry in [('A',ax,d.ap['A_'+scheme]['entry']),('C',x,d.cp['C_'+scheme])]:
   name=config+'_'+scheme;delta=model_delta(xx,entry);result[name]=delta
   score=d.ell+entry['gain']*delta+entry['b']
   errors[name]=float(np.max(np.abs(score-old[name])))
 assert max(errors.values())<1e-3,errors
 np.savez_compressed(cache,**result)
 dump(d.out/'verification.json',dict(existing_score_max_abs_error=errors,passed=True))
 dump(d.out/'provenance.json',dict(source=str(OLD/d.task),C_support=str(OLD/d.task/'C_support.npz'),residual_basis=str(OLD/d.task/'target_residual_basis.npz'),normalization=str(OLD/d.task/'C/normalization.npz'),heads=sup['heads'].tolist(),dimension=99,width=128))
 return result

def diagnose(d):
 cache=prepare(d);table=[];maxdiff=0.
 for scheme in SCHEMES:
  for config in ('A','C'):
   entry=d.ap['A_'+scheme]['entry'] if config=='A' else d.cp['C_'+scheme]
   e=d.ell+entry['gain']*cache[config+'_'+scheme]
   for mode in ('source','natural','joint','zero'):
    b=d.bias(e,mode,scheme);score=e+b;m=d.metrics(score,'dev')
    # Report correction amplitudes excluding the constant intercept.
    m['network_correction_rms']=rms((e-d.ell)[d.n['dev']])
    table.append(dict(task=d.task,model=config,scheme=scheme,intercept_mode=mode,gain=entry['gain'],b=b,**m))
    for kind in ('AP','CF','F0'):
     l,r,_,_=d.p['dev'][kind]
     if len(l):maxdiff=max(maxdiff,float(np.max(np.abs((score[r]-score[l])-(e[r]-e[l])))))
  # Calibration-only controls, no correction network.
  for mode in ('zero','natural','joint'):
   b=d.bias(d.ell,mode,scheme)
   table.append(dict(task=d.task,model='raw',scheme=scheme,intercept_mode=mode,gain=0.,b=b,**d.metrics(d.ell+b,'dev')))
 raw=d.metrics(d.ell,'dev')
 expected=44 if d.task=='nli4ct' else 11
 assert raw['cf_correct']==expected,(d.task,raw)
 assert maxdiff<1e-10,maxdiff
 zeroerr=float(np.max(np.abs(d.ell+0*cache['C_tail_pair']+0-d.ell)))
 assert zeroerr==0.
 v=json.loads((d.out/'verification.json').read_text())
 v.update(intercept_pair_difference_max_error=maxdiff,zero_gain_zero_intercept_max_error=zeroerr,raw_dev_cf_correct=raw['cf_correct'],raw_dev_cf_pairs=raw['cf_pairs'])
 dump(d.out/'verification.json',v)
 write_csv(d.out/'intercept_diagnostics.csv',table)
 dump(d.out/'intercept_diagnostics.json',table)

def train(d):
 cache=prepare(d);z=cache['z'];ni=d.n['fit'];al,ar,_,_=d.p['fit']['AP'];cl,cr,_,_=d.p['fit']['CF']
 fit=np.unique(np.concatenate([ni,al,ar,cl,cr]));local=np.full(len(z),-1,int);local[fit]=np.arange(len(fit))
 device='cuda:0'
 zz=torch.tensor(z[fit],device=device);ee=torch.tensor(d.ell[fit],dtype=torch.float32,device=device)
 yy=torch.tensor(d.y[fit],dtype=torch.float32,device=device)
 a,b,c,q,n=[torch.tensor(local[v],device=device) for v in (al,ar,cl,cr,ni)]
 nw=torch.tensor(d.nw,dtype=torch.float32,device=device);pw=torch.tensor(d.pw,dtype=torch.float32,device=device)
 entries={};budget=d.cp['C_tail_pair']['fit_budget']
 for scheme in SCHEMES:
  original=d.cp['C_'+scheme]
  for group in ('G1','G2'):
   members=[]
   for seed in (11,22,33):
    path=d.out/(group+'_'+scheme+'_seed'+str(seed)+'.pt')
    if path.exists():
     s=torch.load(path,map_location='cpu',weights_only=False)
     members.append(dict(model_file=str(path),coefficient=1/3,seed=seed,fit_scale=s['fit_scale']))
     continue
    status(state='running',stage='training',task=d.task,group=group,scheme=scheme,seed=seed)
    torch.manual_seed(seed)
    initial_path=OLD/d.task/'C'/('initial_seed'+str(seed)+'.pt')
    init=torch.load(initial_path,map_location='cpu',weights_only=False)
    model=Editor().to(device);model.load_state_dict(init['state_dict'])
    with torch.no_grad():
     model.net[-1].weight.mul_(original['initial_gain']);initial=model(zz).detach()
    bias=torch.tensor(calibrate(d.ell[ni]+initial[n].cpu().numpy(),d.y[ni]),device=device,requires_grad=True)
    opt=torch.optim.AdamW(list(model.parameters())+[bias],lr=.0003,weight_decay=.001)
    for step in range(1200):
     corr=model(zz);ap=ee[b]-ee[a]+corr[b]-corr[a];cd=corr[q]-corr[c]
     loss=ap.square().mean()+tail(ap.square())
     if group=='G1':
      if scheme=='tail_pair':loss=loss+1000*cd.square().mean()+1000*torch.relu(cd.abs()-budget).square().mean()
      else:
       noise=torch.randn((len(c),99),device=device)*.1
       locald=model(zz[q]+noise)-model(zz[c]+noise)
       loss=loss+500*(tail(cd.square())+tail(locald.square()))+1000*torch.relu(cd.abs()-budget).square().max()
     logits=ee+corr+bias
     ce=torch.nn.functional.binary_cross_entropy_with_logits(logits[n],yy[n],reduction='none')
     pair_ce=(torch.nn.functional.binary_cross_entropy_with_logits(logits[c],yy[c],reduction='none')+torch.nn.functional.binary_cross_entropy_with_logits(logits[q],yy[q],reduction='none'))/2
     loss=loss+(ce*nw).sum()+(pair_ce*pw).sum()+.01*(corr[n]-initial[n]).square().mean()
     opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10.);opt.step()
    factor=1.
    if group=='G1':
     with torch.no_grad():
      corr=model(zz);factor=min(1.,budget/max(float((corr[q]-corr[c]).abs().max()),1e-12));model.net[-1].weight.mul_(factor)
    torch.save(dict(state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},mu=init['mu'],scale=init['scale'],seed=seed,fit_scale=factor,initial_gain=original['initial_gain'],training_bias=float(bias.detach()),initial_checkpoint=str(initial_path),cfg=dict(group=group,scheme=scheme,steps=1200,lr=.0003,weight_decay=.001,pair_bce_weight=1.,natural_bce_weight=1.,anchor_weight=.01)),path)
    members.append(dict(model_file=str(path),coefficient=1/3,seed=seed,fit_scale=factor))
    print(json.dumps(dict(completed=d.task,group=group,scheme=scheme,seed=seed,loss=float(loss.detach()),peak_gpu_mib=torch.cuda.max_memory_allocated()/2**20)),flush=True)
   entries[group+'_'+scheme]=dict(members=members,initial_gain=original['initial_gain'],fit_budget=budget)
 dump(d.out/'trained_parameters.json',entries)

def choose(d,delta,scheme,group):
 original=d.cp['C_'+scheme];candidates=[]
 for gain in sorted(set([0.,.25,.5,.75,1.,original['gain']])):
  e=d.ell+gain*delta
  for mode in ('source','natural','joint','zero'):
   b=d.bias(e,mode,scheme);m=d.metrics(e+b,'dev')
   m['network_correction_rms']=rms(gain*delta[d.n['dev']])
   candidates.append(dict(task=d.task,group=group,scheme=scheme,gain=gain,b=b,intercept_mode=mode,**m))
 floor=44 if d.task=='nli4ct' else 11
 eligible=[r for r in candidates if r['cf_correct']>=floor]
 best=max(eligible,key=lambda r:(r['correct'],r['cf_correct'],round(r['variance_reduction'],12),-r['gain'],-abs(r['b'])))
 return best,candidates

def bootstrap(d,scores):
 split='test';groups=sorted({v['source_id'] for v in d.vv if v['split']==split})
 gi={s:i for i,s in enumerate(groups)};ng=len(groups)
 W=np.vstack([np.ones(ng),np.random.default_rng(20261110).multinomial(ng,np.ones(ng)/ng,size=2000)])
 def mean(v,ids):
  num=np.bincount([gi[s] for s in ids],weights=np.asarray(v,float),minlength=ng)
  den=np.bincount([gi[s] for s in ids],minlength=ng)
  return safe_ratio(W@num,W@den)
 boot={};summaries={};predictions={};questions=[]
 ni=d.n[split];nsg=[d.vv[i]['source_id'] for i in ni]
 for name,score in scores.items():
  dec,qc,qg,qr=d.decisions(score,split);predictions[name]=dec
  for r in qr:questions.append(dict(method=name,**r))
  st=dict(accuracy=mean(qc,qg),option_accuracy=mean(dec[ni]==d.y[ni],nsg),positive_label_fraction=mean(dec[ni],nsg),
   correction_rms=np.sqrt(mean((score[ni]-d.ell[ni])**2,nsg)))
  if qr:st['mean_selected_options']=mean([r['selected_options'] for r in qr],qg)
  counts={}
  for kind,(l,r,sg,ps) in d.p[split].items():
   if not len(l):continue
   raw=d.ell[r]-d.ell[l];diff=score[r]-score[l];dy=d.y[r]-d.y[l]
   pair=(dec[l]==d.y[l])&(dec[r]==d.y[r])
   st[kind+'_paired_accuracy']=mean(pair,sg)
   st[kind+'_correction_rms']=np.sqrt(mean((diff-raw)**2,sg))
   st[kind+'_response_rms']=np.sqrt(mean(diff**2,sg))
   if kind=='AP':
    st['variance_reduction']=1-safe_ratio(mean(diff**2,sg)-mean(diff,sg)**2,mean(raw**2,sg)-mean(raw,sg)**2)
   if kind=='CF':st['evidence_retention']=safe_ratio(mean(dy*diff,sg),mean(dy*raw,sg))
   counts[kind]=dict(correct=int(pair.sum()),total=len(pair))
  boot[name]=st
  summaries[name]=dict(correct=int(qc.sum()),questions=len(qc),pair_counts=counts,metrics={k:float(v[0]) if np.isfinite(v[0]) else None for k,v in st.items()},ci95={k:interval(v[1:]) for k,v in st.items()})
 comparisons=[]
 for scheme in SCHEMES:
  for group in ('G0','G1','G2'):
   lhs=group+'_'+scheme
   comparisons.extend((lhs,rhs) for rhs in ('raw','calibration_natural','calibration_joint','original_C_'+scheme,'original_A_'+scheme))
  comparisons += [('G1_'+scheme,'G0_'+scheme),('G2_'+scheme,'G1_'+scheme),('G0_'+scheme,'original_C_'+scheme)]
 diffs={}
 for lhs,rhs in dict.fromkeys(comparisons):
  diffs[lhs+' minus '+rhs]={}
  for metric in boot[lhs].keys()&boot[rhs].keys():
   dd=boot[lhs][metric]-boot[rhs][metric]
   diffs[lhs+' minus '+rhs][metric]=dict(difference=float(dd[0]) if np.isfinite(dd[0]) else None,ci95=interval(dd[1:]))
 dump(d.out/'test_metrics.json',dict(exploratory=True,bootstrap_samples=2000,bootstrap_group='source_id (existing clinical-trial/case grouping)',test_groups=ng,methods=summaries,paired_differences=diffs))
 all_decisions={name:{split:d.decisions(score,split)[0] for split in ('fit','dev','test')} for name,score in scores.items()}
 lines(d.out/'predictions.jsonl',[dict(view_id=v['view_id'],split=v['split'],source_id=v['source_id'],label=int(d.y[i]),original=v['original'],scores={k:float(s[i]) for k,s in scores.items()},predictions={k:int(all_decisions[k][v['split']][i]) for k,s in scores.items()}) for i,v in enumerate(d.vv)])
 if questions:lines(d.out/'question_predictions.jsonl',questions)
 lines(d.out/'pair_predictions.jsonl',[dict(pair_id=p['pair_id'],source_id=p['source_id'],kind=kind,left=p['left'],right=p['right'],method=name,left_score=float(score[l[j]]),right_score=float(score[r[j]]),difference=float(score[r[j]]-score[l[j]]),paired_correct=bool(predictions[name][l[j]]==d.y[l[j]] and predictions[name][r[j]]==d.y[r[j]])) for kind,(l,r,sg,ps) in d.p[split].items() for j,p in enumerate(ps) for name,score in scores.items()])
 write_csv(d.out/'training_comparison.csv',[dict(task=d.task,method=k,correct=v['correct'],questions=v['questions'],cf_correct=v['pair_counts']['CF']['correct'],cf_pairs=v['pair_counts']['CF']['total'],**v['metrics']) for k,v in summaries.items()])

def evaluate(d):
 cache=prepare(d);trained=json.loads((d.out/'trained_parameters.json').read_text())
 scores={'raw':d.ell}
 selected={};candidates=[]
 for mode in ('natural','joint'):
  scores['calibration_'+mode]=d.ell+d.bias(d.ell,mode,'tail_pair')
 for scheme in SCHEMES:
  for config in ('A','C'):
   entry=d.ap['A_'+scheme]['entry'] if config=='A' else d.cp['C_'+scheme]
   scores['original_'+config+'_'+scheme]=d.ell+entry['gain']*cache[config+'_'+scheme]+entry['b']
  for group in ('G0','G1','G2'):
   name=group+'_'+scheme
   entry=d.cp['C_'+scheme] if group=='G0' else trained[name]
   delta=cache['C_'+scheme] if group=='G0' else model_delta(cache['x'],entry)
   best,cc=choose(d,delta,scheme,group);candidates+=cc
   selected[name]=dict(**best,members=entry['members'],C_support=str(OLD/d.task/'C_support.npz'),residual_basis=str(OLD/d.task/'target_residual_basis.npz'))
   scores[name]=d.ell+best['gain']*delta+best['b']
 dump(d.out/'selected_parameters.json',selected);write_csv(d.out/'development_candidates.csv',candidates)
 np.savez_compressed(d.out/'scores_selected.npz',ids=np.array([v['view_id'] for v in d.vv]),**scores)
 bootstrap(d,scores)

def report():
 from report_zh import report as write_report
 write_report()

def main():
 parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['diagnose','train','evaluate','all']);args=parser.parse_args()
 started=time.time()
 dump(OUT/'plan.json',dict(gpu=6,expected_gpu_gib=2,expected_minutes=[15,30],runs=24,seeds=[11,22,33],steps=1200,learning_rate=.0003,weight_decay=.001,exploratory=True,natural_intercept='Existing unweighted natural-fit BCE',joint_intercept='Half group-balanced natural BCE plus half group-balanced pair BCE',source=str(OLD)))
 try:
  stages=['diagnose','train','evaluate'] if args.stage=='all' else [args.stage]
  for stage in stages:
   if stage=='train':
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='6','Training requires physical GPU 6'
   for task in TASKS:
    status(state='running',stage=stage,task=task)
    globals()[stage](Data(task))
  if args.stage in ('all','evaluate'):report()
  status(state='complete',stage=args.stage,elapsed_minutes=(time.time()-started)/60,peak_gpu_mib=torch.cuda.max_memory_allocated()/2**20 if torch.cuda.is_initialized() else 0)
 except Exception as e:
  status(state='failed',stage=args.stage,error=str(e));traceback.print_exc();raise
if __name__=='__main__':main()
