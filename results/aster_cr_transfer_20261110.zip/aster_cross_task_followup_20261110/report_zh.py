"""UTF-8 Chinese report generated from saved results. CPU only."""
import json
from pathlib import Path
P=Path('/home/gcx/aster_cross_task_followup_20261110')
TASKS=('nli4ct','medpic')
SCHEMES=('tail_pair','tail_robust')
def read(task,name):
 return json.loads((P/task/name).read_text(encoding='utf-8'))
def report():
 state=json.loads((P/'status.json').read_text())
 elapsed=state.get('elapsed_minutes',1.773)
 out=['# 固定 MEGA 头：截距诊断与修正训练结果','',
 '本轮为已看过既有测试结果后的探索性后续实验。结论与参数均按保存的结果文件整理；没有按测试集成绩重新选参。','',
 '## 主要结论','',
 '- 截距解释了部分配对正确性下降。MedPIC 开发集原模型为 11/44，原 C 的自然截距下两个版本均为 8/44。tail_pair 换源任务截距或零截距可恢复至 11/44；tail_robust 四种截距中最高为 9/44，因此不能把全部下降归因于截距。',
 '- 增加标签改变对分类监督（G1）没有带来稳定准确率提升。MedPIC tail_pair 相对 G0 提高 1.06 个百分点，95% 区间为 [−1.55, 3.65]；其他 G1 对 G0 比较持平或下降。',
 '- 删除标签改变对修正惩罚及训练后幅度缩放（G2）后，整体准确率没有改善。NLI4CT 的干扰降低率达到 92.01%，但证据响应保留率降至 35.13%，测试正确数从原模型的 378/500 降至 366/500。',
 '- MedPIC tail_robust 的 G0、G1 均选中增益 0、源任务截距 0.140；其 71/188 来自截距调整，没有获得网络修正收益。',
 '- 保留负结果：NLI4CT G1 tail_pair 相对原模型下降 2.20 个百分点，95% 区间 [−4.47, −0.21]；G2 两版本均下降 2.40 个百分点，区间 [−4.85, −0.22]。这些下降的区间完全低于零，不能表述成“所有差值区间都跨零”。','',
 '## 实验设置','',
 '保留 NLI4CT、MedPIC 的既有划分、51 个 MEGA 头、99 维输入、128 宽度、既有特征投影、标准化和解码。三个种子为 11、22、33，等权集成。每个新增训练从对应 C 初始化检查点与原初始化增益出发，训练 1,200 步，学习率 0.0003，权重衰减 0.001。','',
 '|组别|训练与选择|','|---|---|',
 '|G0|复用原 C 已训练网络，仅重新选择输出增益和截距|',
 '|G1|原损失增加权重为 1 的标签改变对 BCE，保留原保护项与训练后幅度缩放|',
 '|G2|与 G1 相同，但删除标签改变对修正惩罚及训练后幅度缩放|','',
 '新增标签改变对 BCE 按病例组均衡，每对两侧各占一半；不加入同标签患者变化对 F0。MedPIC 两侧已属于自然拟合样本，因此是增加监督权重；NLI4CT 同时补入原自然 BCE 未覆盖的陈述变化样本。其余无关干扰损失、自然 BCE、初始化锚定项保留。G2 删除版本特有保护项后，两版本的训练目标相同，仍分别训练并按各自候选增益选参。','',
 '每个任务、组别和版本独立在开发集选定配置，再评价测试集。增益候选为 0、0.25、0.5、0.75、1，另加入对应原 C 增益；每个增益搭配源任务、自然样本、联合、零截距。源任务截距取对应版本的 MEGA 原截距；自然截距沿用既有自然拟合样本平均 BCE；联合截距的自然样本和标签改变对各占一半，两部分分别按病例组均衡。所有新估计截距只用拟合集。','',
 '开发集标签改变对全对数下限为 NLI4CT 44/66、MedPIC 11/44。合格候选按整体正确题数、标签改变对全对数、干扰降低率、更小增益、更小截距绝对值依次选择。增益 0、截距 0 始终保留为原模型候选。所有选定配置均满足开发集下限；测试集不保证维持该下限。','',
 f'全部在服务器 gcx261014 环境运行。24 次新增训练使用物理 GPU 6，完整运行约 {elapsed:.2f} 分钟；稳定运行时观察到进程显存约 534 MiB。截距诊断与评价使用 CPU；没有重新选头或运行大模型。','',
 '## 截距诊断（开发集）','',
 '以下固定既有修正量和输出增益，仅更换截距。正标签比例按最终决策统计；MedPIC 使用既有合法答案集合解码。','',
 '|任务|模型/版本|截距方案|截距值|整体正确数|标签改变对全对数|正标签比例|平均选择选项数|',
 '|---|---|---|---:|---:|---:|---:|---:|']
 modes={'source':'源任务','natural':'自然样本','joint':'联合','zero':'零'}
 for task in TASKS:
  seen=set()
  for r in read(task,'intercept_diagnostics.json'):
   if r['model']=='raw':
    if r['intercept_mode'] in seen:continue
    seen.add(r['intercept_mode'])
   opt='—' if r['mean_selected_options'] is None else f"{r['mean_selected_options']:.2f}"
   model=r['model'] if r['model']=='raw' else r['model']+'/'+r['scheme']
   out.append(f"|{task}|{model}|{modes[r['intercept_mode']]}|{r['b']:.3f}|{r['correct']}/{r['questions']}|{r['cf_correct']}/{r['cf_pairs']}|{r['positive_label_fraction']:.1%}|{opt}|")
 out+=['','截距不改变配对分数差。仅换截距时全对率改变，来自判定阈值和 MedPIC 答案集合，而非干扰预测能力。MedPIC 原 C 自然截距下平均选项数约为 1.05–1.06，源截距下约为 1.13–1.24，显示自然截距会缩小答案集合。','',
 '## 开发集选定参数','',
 '|任务|方法|增益|截距方案|截距值|整体正确数|标签改变对全对数|','|---|---|---:|---|---:|---:|---:|']
 for task in TASKS:
  for name,r in read(task,'selected_parameters.json').items():
   out.append(f"|{task}|{name}|{r['gain']:.4f}|{modes[r['intercept_mode']]}|{r['b']:.3f}|{r['correct']}/{r['questions']}|{r['cf_correct']}/{r['cf_pairs']}|")
 out+=['','## 测试结果','',
 'NLI4CT 为 500 个原始案例的正确率；MedPIC 为 188 题整题答案集合全对率。标签改变对全对数分别以 864 对和 110 对为分母，MedPIC 配对是选项级标签改变患者变化对。原 A/C 完整既有配置与仅校准对照均列出。','',
 '|任务|方法|整体正确数|准确率|标签改变对全对数|干扰降低率|证据响应保留率|证据修正 RMS|','|---|---|---:|---:|---:|---:|---:|---:|']
 for task in TASKS:
  for name,r in read(task,'test_metrics.json')['methods'].items():
   m=r['metrics'];cf=r['pair_counts']['CF']
   out.append(f"|{task}|{name}|{r['correct']}/{r['questions']}|{m['accuracy']:.2%}|{cf['correct']}/{cf['total']}|{m['variance_reduction']:.2%}|{m['evidence_retention']:.2%}|{m['CF_correction_rms']:.3f}|")
 out+=['','## 主要准确率差值','',
 '按既有临床试验组或病例组（source_id）进行 2,000 次配对 bootstrap。差值和区间单位为百分点。完整主要指标区间、相对原模型和仅校准对照的比较见各任务 test_metrics.json。','',
 '|任务|比较|准确率差值|95%区间|','|---|---|---:|---|']
 for task in TASKS:
  result=read(task,'test_metrics.json')
  for scheme in SCHEMES:
   keys=[f'G0_{scheme} minus original_C_{scheme}',f'G1_{scheme} minus G0_{scheme}',f'G2_{scheme} minus G1_{scheme}']+[f'{g}_{scheme} minus raw' for g in ('G0','G1','G2')]
   for key in keys:
    r=result['paired_differences'][key]['accuracy'];ci=r['ci95']
    out.append(f"|{task}|{key}|{r['difference']*100:.2f}|[{ci['low']*100:.2f}, {ci['high']*100:.2f}]|")
 out+=['','## 指标与验证','',
 '干扰降低率为 1 − 修正后无关对分数差方差 / 原方差；证据响应保留率为按标签改变方向加权的分数差总和之比。证据修正 RMS 是标签改变对上的修正分数差 RMS，不受截距影响；机器结果中的 correction_rms 则包含最终截距。证据响应保留率接近 100% 不代表回答更正确。','',
 '既有 A/C 分数已复现，最大绝对误差小于 4.4×10⁻⁶；仅更换截距的配对分数差误差小于 1.5×10⁻¹⁴；增益和截距均为零时精确还原原模型。保存后的推理接口也与批量分数一致。','',
 '## 结果文件','',
 '- [NLI4CT 测试指标与配对区间](nli4ct/test_metrics.json) · [MedPIC 测试指标与配对区间](medpic/test_metrics.json)',
 '- [NLI4CT 截距诊断表](nli4ct/intercept_diagnostics.csv) · [MedPIC 截距诊断表](medpic/intercept_diagnostics.csv)',
 '- [NLI4CT 训练对照表](nli4ct/training_comparison.csv) · [MedPIC 训练对照表](medpic/training_comparison.csv)',
 '- [NLI4CT 选定参数](nli4ct/selected_parameters.json) · [MedPIC 选定参数](medpic/selected_parameters.json)','',
 '服务器完整目录：/home/gcx/aster_cross_task_followup_20261110/。各任务还保存全部开发候选、逐例分数和决策、逐对预测、验证结果与模型检查点；MedPIC 另有逐题答案集合。独立入口 followup.py 支持 diagnose、train、evaluate、all；inference.py 复用原 Predictor 接口。训练日志见 run.log。本次 GitHub 汇报提交报告、汇总表、选定参数与测试统计，完整运行产物保留在服务器。','']
 (P/'REPORT.zh.md').write_text('\n'.join(out),encoding='utf-8')
if __name__=='__main__':report()

